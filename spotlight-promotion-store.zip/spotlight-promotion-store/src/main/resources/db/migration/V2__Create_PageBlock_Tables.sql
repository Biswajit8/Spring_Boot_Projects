CREATE TABLE activity_page_info (
                                    page_id     VARCHAR PRIMARY KEY,
                                    status      TEXT,
                                    payload     JSONB,
                                    activity_id TEXT
);

CREATE TABLE activity_block_info (
                                     block_id VARCHAR PRIMARY KEY,
                                     page_id  VARCHAR NOT NULL,
                                     payload  JSONB,
                                     status   TEXT,
                                     CONSTRAINT fk_activity_block_page
                                         FOREIGN KEY (page_id)
                                             REFERENCES activity_page_info (page_id)
                                             ON DELETE CASCADE
);

ALTER TABLE activity_associations
ADD COLUMN page_id  VARCHAR,
ADD COLUMN block_id VARCHAR;
