CREATE TABLE IF NOT EXISTS activities
(
    activity_id
    TEXT
    PRIMARY
    KEY,
    payload
    JSONB
    NOT
    NULL,
    created_at
    TIMESTAMPTZ
    NOT
    NULL
    DEFAULT
    NOW,
    status
    text,
    start_date
    timestamp,
    end_date
    timestamp
(
),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW
(
)
    );

-- JSONB index for querying inside payload
CREATE INDEX IF NOT EXISTS idx_activities_payload_gin
    ON activities USING gin (payload jsonb_path_ops);

-- === activity_associations: generic links (offer/campaign/page/block) ========
CREATE TABLE IF NOT EXISTS activity_associations
(
    id
    BIGSERIAL
    PRIMARY
    KEY,
    activity_id
    TEXT
    NOT
    NULL,
    entity_type
    TEXT
    NOT
    NULL, -- 'OFFER' | 'CAMPAIGN' | 'PAGE' | 'BLOCK'
    entity_id
    TEXT
    NOT
    NULL, -- offerId / campaignId / pageId / blockId
    allocation_id
    TEXT
    NULL, -- REQUIRED for OFFER, NULL for CAMPAIGN
    state
    TEXT
    NOT
    NULL, -- 'ADDED' | 'DELETED'
    payload
    JSONB
    NULL, -- snapshot JSON (offer/campaign/etc.)
    created_at
    TIMESTAMPTZ
    NOT
    NULL
    DEFAULT
    NOW
(
),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW
(
),
    CONSTRAINT fk_assoc_activity
    FOREIGN KEY
(
    activity_id
) REFERENCES activities
(
    activity_id
) ON DELETE CASCADE
    );

-- === offers_activities_events: single-row lock status per offer ==============
CREATE TABLE IF NOT EXISTS offers_activities_events
(
    offer_id
    TEXT
    PRIMARY
    KEY,  -- exactly one row per offer
    relation_type
    TEXT
    NOT
    NULL, -- 'LOCKED' | 'UNLOCKED'
    occurred_at
    TIMESTAMPTZ
    NOT
    NULL,
    version
    BIGINT
    NOT
    NULL
    DEFAULT
    0
);

-- Offer rows (allocation_id NOT NULL) are unique on 4 keys
CREATE UNIQUE INDEX IF NOT EXISTS ux_assoc_with_alloc
    ON activity_associations (activity_id, entity_type, entity_id, allocation_id)
    WHERE allocation_id IS NOT NULL;

-- Generic rows (allocation_id NULL) are unique on 3 keys
CREATE UNIQUE INDEX IF NOT EXISTS ux_assoc_null_alloc
    ON activity_associations (activity_id, entity_type, entity_id)
    WHERE allocation_id IS NULL;