package com.lowes.promotionstore.entity.spotlight;

public enum PersistAction {
  OVERWRITE_OR_CREATE, UPSERT_OR_CREATE
}
