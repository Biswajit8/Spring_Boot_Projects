package com.lowes.promotionstore.repository.postgres;

import com.lowes.promotionstore.entity.amplification.BlockEntity;
import com.lowes.promotionstore.entity.amplification.PageBlockState;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface BlockRepository extends JpaRepository<BlockEntity, String> {

  @Modifying
  @Query("UPDATE BlockEntity p SET p.status = :status WHERE p.pageId = :pageId")
  int updateStatusByPageId(String pageId, PageBlockState status);

  List<BlockEntity> findByPageId(String pageId);
}