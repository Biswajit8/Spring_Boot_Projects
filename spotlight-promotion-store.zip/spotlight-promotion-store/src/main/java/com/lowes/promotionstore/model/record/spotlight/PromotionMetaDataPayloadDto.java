package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record PromotionMetaDataPayloadDto(List<Integer> eventIds, List<Integer> divisions,
                                          List<Integer> subDivisions,
                                          String promoTrackerLink) {

  public PromotionMetaDataPayloadDto {
    if (CollectionUtils.isEmpty(eventIds)) {
      eventIds = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(divisions)) {
      divisions = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(subDivisions)) {
      subDivisions = new ArrayList<>();
    }
  }
}
