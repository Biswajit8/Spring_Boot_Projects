package com.lowes.promotionstore.listener;

import com.lowes.generated.model.offerevent.OfferEventPublishDto;
import com.lowes.promotionstore.component.MemoryMonitor;
import com.lowes.promotionstore.component.OfferEventMapper;
import com.lowes.promotionstore.configuration.KafkaConsumerToggleConfig;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import com.lowes.promotionstore.service.SpotlightPromotionStoreService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.lowes.promotionstore.constants.ApplicationConstants.MAX_CHUNK_SIZE;
import static com.lowes.promotionstore.constants.ApplicationConstants.OFFER_EVENT_LISTENER;

@ConditionalOnProperty(
    prefix = "application.kafka.consumer.offerEventsListener",
    name = "enabled",
    havingValue = "true",
    matchIfMissing = true
)
@Component
@Slf4j
@AllArgsConstructor
public class OfferEventsKafkaListener {

  private final KafkaConsumerToggleConfig kafkaConsumerToggleConfig;
  private final SpotlightPromotionStoreService spotlightPromotionStoreService;
  private final OfferEventMapper offerEventMapper;
  private final MemoryMonitor memoryMonitor;

  private int chunkSize() {
    return Math.max(MAX_CHUNK_SIZE, 200);
  }

  /**
   * 3) Offer events — convert + chunk while mapping (no large intermediate list)
   */
  @KafkaListener(
      idIsGroup = false,
      id = OFFER_EVENT_LISTENER,
      topics = "${application.kafka.consumer.offerEventsListener.topic}",
      containerFactory = "offerEventConsumer"
  )
  public void offerEventListener(
      ConsumerRecords<String, OfferEventPublishDto> records,
      Acknowledgment ack
  ) {
    if (!kafkaConsumerToggleConfig.isEnableOfferEventsConsumer() || records.isEmpty()) {
      log.info("Records consumed: 0");
      acknowledgeSafely(ack);
      return;
    }

    // Memory monitoring before processing
    memoryMonitor.checkMemoryUsage("kafka_batch_start", records.count());

    // Check memory status and adjust chunk size if needed
    var memoryStatus = memoryMonitor.getMemoryStatus();
    var adjustedChunkSize = adjustChunkSizeForMemory(memoryStatus);

    var topicBuffers = new HashMap<String, List<SpotlightOfferPayloadDto>>();
    var mappedCount = new int[]{0};

    records.forEach(rec -> processRecord(rec, topicBuffers, adjustedChunkSize, mappedCount));

    // Process remaining records in buffers
    topicBuffers.forEach((topic, buffer) -> {
      if (!buffer.isEmpty()) {
        spotlightPromotionStoreService.process(buffer, topic);
      }
    });

    log.info("OfferEvent mapped={} processedTopics={} memoryStatus={}",
        mappedCount[0], topicBuffers.keySet(), memoryStatus);

    // Memory monitoring after processing
    memoryMonitor.checkMemoryUsage("kafka_batch_complete", records.count());
    acknowledgeSafely(ack);
  }

  private void processRecord(
      ConsumerRecord<String, OfferEventPublishDto> record,
      Map<String, List<SpotlightOfferPayloadDto>> buffers,
      int chunkSize,
      int[] mappedCount
  ) {
    try {
      var mapped = offerEventMapper.toSpotlightOffers(record.value());
      if (mapped == null) {
        return;
      }

      var topic = record.topic();
      var buffer = buffers.computeIfAbsent(topic, t -> new ArrayList<>(chunkSize));
      buffer.add(mapped);
      mappedCount[0]++;

      if (buffer.size() == chunkSize) {
        spotlightPromotionStoreService.process(buffer, topic);
        buffer.clear();
      }
    } catch (Exception e) {
      log.warn("""
          Error mapping event (topic={}, partition={}, offset={}): {}
          """, record.topic(), record.partition(), record.offset(), e.getMessage(), e);
    }
  }

  private void acknowledgeSafely(Acknowledgment ack) {
    if (ack != null) {
      ack.acknowledge();
    }
  }

  private int adjustChunkSizeForMemory(MemoryMonitor.MemoryStatus memoryStatus) {
    int baseChunkSize = chunkSize();

    return switch (memoryStatus) {
      case CRITICAL -> Math.max(baseChunkSize / 4, 25);  // Reduce to 25% of normal, min 25
      case WARNING -> Math.max(baseChunkSize / 2, 50);   // Reduce to 50% of normal, min 50
      case HEALTHY -> baseChunkSize;                     // Use normal chunk size
    };
  }
}
