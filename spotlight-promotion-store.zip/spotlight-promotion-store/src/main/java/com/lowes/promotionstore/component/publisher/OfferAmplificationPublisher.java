package com.lowes.promotionstore.component.publisher;

import com.lowes.generated.model.amplification.OfferAmplifiedPublishDto;
import com.lowes.promotionstore.configuration.properties.KafkaProps;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;


@Slf4j
@Component
public class OfferAmplificationPublisher {

  private static final String PRODUCER_NAME = "amplificationFeedbackProducer";

  private final KafkaTemplate<String, OfferAmplifiedPublishDto> kafkaTemplate;
  private final String topic;

  public OfferAmplificationPublisher(
      KafkaTemplate<String, OfferAmplifiedPublishDto> kafkaTemplate,
      KafkaProps kafkaProps) {

    this.kafkaTemplate = kafkaTemplate;

    var spec = kafkaProps.getProducer().getAmplificationFeedbackProducer();
    if (spec == null || spec.getTopic() == null || spec.getTopic().isBlank()) {
      throw new IllegalStateException(
          "Missing producer/topic for '" + PRODUCER_NAME + "'. " +
              "Check application.kafka.producers." + PRODUCER_NAME + ".topic");
    }
    this.topic = spec.getTopic();
  }

  public void publishMessage(String offerId, boolean isAmplified) {
    var payload = new OfferAmplifiedPublishDto(offerId, isAmplified);

    kafkaTemplate.send(topic, offerId, payload)
        .whenComplete((result, ex) -> {
          if (ex != null) {
            log.error("Publish failed: key={}, topic={}", offerId, topic, ex);
            return;
          }
          var m = result.getRecordMetadata();
          log.info("Published offerAmplification: key={}, topic={}, partition={}, offset={}",
              offerId, m.topic(), m.partition(), m.offset());
        });
  }
}
