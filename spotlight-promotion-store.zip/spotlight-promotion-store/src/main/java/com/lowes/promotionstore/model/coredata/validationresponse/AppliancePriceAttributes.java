package com.lowes.promotionstore.model.coredata.validationresponse;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class AppliancePriceAttributes implements Serializable {

  private static final long serialVersionUID = 1L;

  @JsonProperty("pmap")
  private String pmap;

  @JsonProperty("isoFlag")
  private Boolean isoFlag;

  @JsonProperty("ecpPrice")
  private String ecpPrice;

  @JsonProperty("inOutCart")
  private String inOutCart;

  @JsonProperty("housePromo")
  private String housePromo;

  @JsonProperty("storePrice")
  private String storePrice;

  @JsonProperty("onlineNowPrice")
  private String onlineNowPrice;

  @JsonProperty("futureBasePrice")
  private String futureBasePrice;
}
