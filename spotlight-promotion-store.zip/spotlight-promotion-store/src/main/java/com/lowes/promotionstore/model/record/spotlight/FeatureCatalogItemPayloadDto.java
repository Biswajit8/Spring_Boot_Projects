package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.util.CollectionUtils;

import java.util.HashSet;
import java.util.Set;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record FeatureCatalogItemPayloadDto(String catalogId,
                                           Set<FeatureItemDetailPayloadDto> itemDetails) {

  public FeatureCatalogItemPayloadDto {
    if (CollectionUtils.isEmpty(itemDetails)) {
      itemDetails = new HashSet<>();
    }
  }
}
