package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record ExcludeProductsPayloadDto(PromotionPayloadEnums.ProductTypeEnum productType,
                                        List<ItemDetailsPayloadDto> itemDetails,
                                        List<KeyValuePayloadDto> brands,
                                        List<KeyValuePayloadDto> merchBuckets,
                                        List<DigitalTaxonomyExcludePayloadDto> digitalTaxonomies) {

  public ExcludeProductsPayloadDto {
    if (CollectionUtils.isEmpty(itemDetails)) {
      itemDetails = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(brands)) {
      brands = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(merchBuckets)) {
      merchBuckets = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(digitalTaxonomies)) {
      digitalTaxonomies = new ArrayList<>();
    }
  }
}
