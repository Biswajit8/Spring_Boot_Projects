package com.lowes.promotionstore.listener;

import com.lowes.generated.model.offerevent.OfferEventPublishDto;
import com.lowes.promotionstore.exception.constants.ErrorEnums.ErrorCodeEnum;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.common.serialization.Deserializer;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;
import java.util.zip.GZIPInputStream;

@SuppressWarnings("java:S1135")
@Slf4j
@Component
public class OfferEventDeserializer implements
    Deserializer<OfferEventPublishDto> {

  private KafkaAvroDeserializer avroDeserializer;

  @Override
  public void configure(Map<String, ?> configs, boolean isKey) {
    this.avroDeserializer = new KafkaAvroDeserializer();
    this.avroDeserializer.configure(configs, isKey);
  }

  @Override
  public OfferEventPublishDto deserialize(String topic,
      byte[] data) {
    if (data == null || data.length == 0) {
      return null;
    }

    try (
        ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(data);
        GZIPInputStream gzipInputStream = new GZIPInputStream(byteArrayInputStream);
        ByteArrayOutputStream decompressedStream = new ByteArrayOutputStream()
    ) {
      byte[] buffer = new byte[1024];
      int len;
      while ((len = gzipInputStream.read(buffer)) > 0) {
        decompressedStream.write(buffer, 0, len);
      }
      byte[] avroBytes = decompressedStream.toByteArray();

      Object deserializedObj = avroDeserializer.deserialize(topic, avroBytes);
      OfferEventPublishDto dto =
          (OfferEventPublishDto) deserializedObj;

      log.info("Deserialized OfferEventPublishDto: {}", dto);
      return dto;

    } catch (IOException e) {
      log.error("ERROR:: Failure during Avro+GZIP deserialization", e);
      throw new RuntimeException(ErrorCodeEnum.SERIALIZATION_ERROR.getMessage());
    }
  }

  @Override
  public void close() {
    if (avroDeserializer != null) {
      avroDeserializer.close();
    }
  }
}
