package com.lowes.promotionstore.repository.dao;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowes.promotionstore.entity.amplification.BlockEntity;
import com.lowes.promotionstore.entity.amplification.PageBlockState;
import com.lowes.promotionstore.model.record.feedback.BlockPayloadDto;
import com.lowes.promotionstore.model.record.feedback.OfferEventPayloadDto;
import com.lowes.promotionstore.model.record.feedback.PagePayloadDto;
import com.lowes.promotionstore.repository.postgres.BlockRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Slf4j
@Service
@RequiredArgsConstructor
public class BlockDao {

  private final BlockRepository blockRepository;
  private final ObjectMapper objectMapper;


  @Transactional
  public void upsertBlock(OfferEventPayloadDto payloadDto) {
    if (payloadDto.getBlock() == null) {
      log.debug("No block to upsert (block or block.id is null) for payload: {}", payloadDto);
      return;
    }
    String blockId = req(payloadDto.getBlock().getId());
    BlockEntity entity = null;
    try {
      entity = BlockEntity.builder()
          .blockId(blockId)
          .pageId(payloadDto.getPage().getId())
          .payload(objectMapper.writeValueAsString(payloadDto.getBlock()))
          .status(PageBlockState.ADDED)
          .build();
    } catch (JsonProcessingException e) {
      throw new RuntimeException(e);
    }
    blockRepository.save(entity);
    log.info("block.create and blockId={}", blockId);

  }

  public int updateBlockStatus(String pageId, PageBlockState status) {
    return blockRepository.updateStatusByPageId(pageId, status);
  }

  // -------- helpers --------
  private static <T> T req(T v) {
    if (v == null) {
      throw new IllegalArgumentException("Required value is null");
    }
    return v;
  }

  public void markBlockStatusDeleted(BlockPayloadDto block) {
    String blockId = req(block.getId());
    log.info("block.delete and blockId={}", blockId);

    blockRepository.findById(blockId)
        .ifPresent(entity -> {
          PageBlockState currentStatus = entity.getStatus();
          if (currentStatus == PageBlockState.ADDED) {
            entity.setStatus(PageBlockState.DELETED);
            blockRepository.save(entity);
            log.info("block marked as DELETED for blockId={}", blockId);
          } else {
            log.warn("block not marked as DELETED - current status is {} for blockId={}",
                currentStatus, blockId);
          }
        });

  }

  public void deleteBlockByPageId(PagePayloadDto page) {
    String pageId = req(page.getId());
    log.info("block.delete and pageId={}", pageId);

    blockRepository.findByPageId(pageId).forEach(entity -> {
      PageBlockState currentStatus = entity.getStatus();
      if (currentStatus == PageBlockState.ADDED) {
        entity.setStatus(PageBlockState.DELETED);
        blockRepository.save(entity);
        log.info("block marked as DELETED for blockId={}, pageId={}", entity.getBlockId(), pageId);
      } else {
        log.warn("block not marked as DELETED - current status is {} for blockId={}, pageId={}",
            currentStatus, entity.getBlockId(), pageId);
      }
    });
  }
}
