package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record FundingDetailsPayloadDto(
    Integer subDivId,
    FundingCalcPayloadDto fundingCalc,
    String collectionMethod,
    String remitVbu,
    Boolean partOfAnotherNegotiatedAgreement,
    Boolean fundsSubjectToContigency,
    String fundContigencyDetails,
    Boolean areItemsSoldDirectly,
    String itemSaleDetails,
    List<String> attachmentUrls,
    List<AttachmentsPayloadDto> attachments,
    String additionalNotes
) {

}
