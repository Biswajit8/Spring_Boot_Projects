package com.lowes.promotionstore.repository.postgres;

import com.lowes.promotionstore.entity.amplification.PageBlockState;
import com.lowes.promotionstore.entity.amplification.PageEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

public interface PageRepository extends JpaRepository<PageEntity, String> {

  @Modifying
  @Query("UPDATE PageEntity p SET p.status = :status WHERE p.activityId = :activityId")
  int updateStatusByActivityId(String activityId, PageBlockState status);

}