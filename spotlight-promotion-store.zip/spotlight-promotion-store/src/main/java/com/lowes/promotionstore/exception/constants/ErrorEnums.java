package com.lowes.promotionstore.exception.constants;

public class ErrorEnums {

  public enum ErrorTypeEnum {
    CONNECTION_ERROR,
    DATABASE_ERROR,
    APPLICATION_ERROR
  }

  public enum ErrorCodeEnum {
    INTERNAL_SERVER_ERROR("Internal Server Error"),
    SERIALIZATION_ERROR("Error when deserializing message to Pojo"),
    ELASTIC_EXCEPTION("Failure while connecting to Elastic"),
    PARSING_FAILURE("MESSAGE_PARSING_FAILURE"),
    PROCESSING_FAILURE("MESSAGE_PROCESSING_FAILURE"),
    MISSING_DOCUMENT("DOCUMENT_MISSING_IN_ELASTIC_INDEX"),
    DATABASE_ERROR("Error while fetching data from database");

    private final String message;

    ErrorCodeEnum(String message) {
      this.message = message;
    }

    public String getMessage() {
      return message;
    }
  }
}
