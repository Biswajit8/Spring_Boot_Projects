package com.lowes.promotionstore.entity.amplification;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@SuppressWarnings("java:S1068")
@Entity
@Table(name = "offers_activities_events")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OfferActivityEvent {

  @Id
  @Column(name = "offer_id", nullable = false)
  private String offerId;

  @Enumerated(EnumType.STRING)
  @Column(name = "relation_type", nullable = false, columnDefinition = "text")
  private RelationType relationType;

  @Column(name = "occurred_at", nullable = false, columnDefinition = "timestamptz")
  private LocalDateTime occurredAt;
}
