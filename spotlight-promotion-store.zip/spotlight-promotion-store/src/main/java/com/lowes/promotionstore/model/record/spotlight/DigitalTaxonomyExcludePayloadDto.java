package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record DigitalTaxonomyExcludePayloadDto(String id, String value, List<String> parents) {

  public DigitalTaxonomyExcludePayloadDto {
    if (CollectionUtils.isEmpty(parents)) {
      parents = new ArrayList<>();
    }
  }
}
