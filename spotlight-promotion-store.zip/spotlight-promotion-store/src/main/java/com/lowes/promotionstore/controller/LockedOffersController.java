package com.lowes.promotionstore.controller;

import com.lowes.promotionstore.service.OfferAmplificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/one-time-push/locked-offers")
@RequiredArgsConstructor
public class LockedOffersController {

  private final OfferAmplificationService offerAmplificationService;

  @PostMapping
  public void publishAllLockedOffers() {
    offerAmplificationService.publishLockedOffers();
  }
}