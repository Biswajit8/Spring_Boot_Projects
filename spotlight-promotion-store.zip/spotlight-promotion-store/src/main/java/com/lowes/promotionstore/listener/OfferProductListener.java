package com.lowes.promotionstore.listener;

import com.lowes.model.generated.OfferProductDto;
import com.lowes.promotionstore.service.OfferProductStoreService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.TopicPartition;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.List;

import static com.lowes.promotionstore.constants.ApplicationConstants.OFFER_PRODUCT_LISTENER;

@Slf4j
@Component
@RequiredArgsConstructor
public class OfferProductListener {

  private final OfferProductStoreService offerProductAggregatorService;

  @KafkaListener(
      idIsGroup = false,
      id = OFFER_PRODUCT_LISTENER,
      topics = ("${application.kafka.consumer.offerProductListener.topic}"),
      containerFactory = "offerProductConsumer"
  )
  public void offerProductListener(ConsumerRecords<String, OfferProductDto> consumerRecords,
      Acknowledgment acknowledgment) {
    log.info("Records consumed : {}", consumerRecords.count());

    String topic = "unknown";
    for (TopicPartition partition : consumerRecords.partitions()) {
      List<ConsumerRecord<String, OfferProductDto>> records = consumerRecords.records(partition);
      if (!records.isEmpty()) {
        topic = records.get(0).topic();
        break;
      }
    }

    try {
      offerProductAggregatorService.process(consumerRecords, topic);
    } catch (Exception e) {
      log.warn("Error while parsing the incoming message into OfferProductDto", e);
    } finally {
      acknowledgment.acknowledge();
    }
  }

}
