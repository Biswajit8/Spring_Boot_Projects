package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public record VendorFundingInfoPayloadDto(
    Long vendorNo,
    List<String> fundedItems,
    FundingDetailsPayloadDto fundingDetails,
    List<VendorContactPayloadDto> vendorContacts,
    SignersPayloadDto signers,
    List<CatalogLevelVariancePayloadDto> catalogLevelVariance
) {

}
