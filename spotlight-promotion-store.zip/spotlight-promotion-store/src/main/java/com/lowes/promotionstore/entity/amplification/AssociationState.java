package com.lowes.promotionstore.entity.amplification;


import java.util.Locale;

import static java.util.Objects.requireNonNull;

public enum AssociationState {
  ADDED, DELETED, CANCELED, ON_HOLD;

  static AssociationState of(String s) {
    try {
      return valueOf(requireNonNull(s, "operation").trim().toUpperCase(Locale.ROOT));
    } catch (Exception e) {
      throw new UnsupportedOperationException("Unsupported operation: " + s);
    }
  }
}
