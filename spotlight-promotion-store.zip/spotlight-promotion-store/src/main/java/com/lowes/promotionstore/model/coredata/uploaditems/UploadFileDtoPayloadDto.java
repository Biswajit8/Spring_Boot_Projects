package com.lowes.promotionstore.model.coredata.uploaditems;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@SuppressWarnings("java:S1068")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UploadFileDtoPayloadDto {

  private String fileName;
  private List<RowDetailsPayloadDto> errors;
  private List<RowDetailsPayloadDto> success;
}
