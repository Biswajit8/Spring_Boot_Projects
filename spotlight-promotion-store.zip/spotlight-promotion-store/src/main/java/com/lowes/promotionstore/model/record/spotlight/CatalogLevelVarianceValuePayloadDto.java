package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record CatalogLevelVarianceValuePayloadDto(
    String subCatalogRef,
    String itemNo,
    String vendorNo,
    String modelNo,
    Double value
) {

}
