package com.lowes.promotionstore.model.record.spotlight.enums;

public class PromotionStoreEnums {

  public enum CatalogQualificationTypeEnum {
    CONDITION_REWARD_ITEM,
    CONDITION_ITEM,
    REWARD_ITEM
  }
}
