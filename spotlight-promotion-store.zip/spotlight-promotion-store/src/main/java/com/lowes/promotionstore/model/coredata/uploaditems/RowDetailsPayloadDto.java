package com.lowes.promotionstore.model.coredata.uploaditems;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RowDetailsPayloadDto implements Serializable {

  private static final long serialVersionUID = 9215250887215568287L;

  private String rowId;
  private String itemNumber;
  private String itemDescription;
  private String offerPrice;
  private String locations;
  private String message;
  private String discountType;
  private String discountValue;
}
