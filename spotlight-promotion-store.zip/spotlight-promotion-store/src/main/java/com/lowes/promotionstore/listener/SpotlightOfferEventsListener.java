package com.lowes.promotionstore.listener;

import com.lowes.promotionstore.configuration.KafkaConsumerToggleConfig;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import com.lowes.promotionstore.service.SpotlightPromotionStoreService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.lowes.promotionstore.constants.ApplicationConstants.MAX_CHUNK_SIZE;


@Slf4j
@Component
@AllArgsConstructor
public class SpotlightOfferEventsListener {

  private final KafkaConsumerToggleConfig kafkaConsumerToggleConfig;
  private final SpotlightPromotionStoreService spotlightPromotionStoreService;

  // Utility: small helper to get configured chunk size with a sane default
  private int chunkSize() {
    return MAX_CHUNK_SIZE > 0 ? MAX_CHUNK_SIZE : 200;
  }

  /**
   * 1) Spotlight — now reads ConsumerRecords and chunks per topic
   */
  @KafkaListener(
      topics = "${application.kafka.consumer.spotlightPromotionListener.topic}",
      containerFactory = "spotlightConsumer"
  )
  public void onSpotlight(
      ConsumerRecords<String, SpotlightOfferPayloadDto> records,
      Acknowledgment ack
  ) {
    if (!kafkaConsumerToggleConfig.isEnableAdapterConsumer()) {
      if (ack != null) {
        ack.acknowledge();
      }
      return;
    }

    int chunkSize = chunkSize();
    Map<String, List<SpotlightOfferPayloadDto>> buffers = new HashMap<>();
    int seen = 0;

    for (ConsumerRecord<String, SpotlightOfferPayloadDto> rec : records) {
      seen++;
      if (rec.value() == null) {
        continue;
      }
      String topic = rec.topic();
      List<SpotlightOfferPayloadDto> buf =
          buffers.computeIfAbsent(topic, t -> new ArrayList<>(chunkSize));
      buf.add(rec.value());
      if (buf.size() == chunkSize) {
        spotlightPromotionStoreService.process(buf, topic); // ⬅️ process one chunk
        buf.clear();
      }
    }

    // flush leftovers
    buffers.forEach((topic, buf) -> {
      if (!buf.isEmpty()) {
        spotlightPromotionStoreService.process(buf, topic);
      }
    });

    log.info("Processed spotlight batch: records={}, topics={}", seen, buffers.keySet());
    if (ack != null) {
      ack.acknowledge();
    }
  }

  /**
   * 2) Full-load — same idea: ConsumerRecords + per-topic chunking
   */
  @KafkaListener(
      topics = "${application.kafka.consumer.spotlightPromotionFullLoadListener.topic}",
      containerFactory = "fullLoadConsumer"
  )
  public void onFullLoad(
      ConsumerRecords<String, SpotlightOfferPayloadDto> records,
      Acknowledgment ack
  ) {
    log.info("Full-load enabled? {}", kafkaConsumerToggleConfig.isEnableFullLoadConsumer());
    if (!kafkaConsumerToggleConfig.isEnableFullLoadConsumer()) {
      log.info("Full load consumer disabled");
      if (ack != null) {
        ack.acknowledge();
      }
      return;
    }

    int chunkSize = chunkSize();
    Map<String, List<SpotlightOfferPayloadDto>> buffers = new HashMap<>();
    int seen = 0;

    for (ConsumerRecord<String, SpotlightOfferPayloadDto> rec : records) {
      seen++;
      if (rec.value() == null) {
        continue;
      }
      String topic = rec.topic();
      List<SpotlightOfferPayloadDto> buf =
          buffers.computeIfAbsent(topic, t -> new ArrayList<>(chunkSize));
      buf.add(rec.value());
      if (buf.size() == chunkSize) {
        spotlightPromotionStoreService.process(buf, topic);
        buf.clear();
      }
    }

    buffers.forEach((topic, buf) -> {
      if (!buf.isEmpty()) {
        spotlightPromotionStoreService.process(buf, topic);
      }
    });

    log.info("Processed full-load batch: records={}, topics={}", seen, buffers.keySet());
    if (ack != null) {
      ack.acknowledge();
    }
  }

}
