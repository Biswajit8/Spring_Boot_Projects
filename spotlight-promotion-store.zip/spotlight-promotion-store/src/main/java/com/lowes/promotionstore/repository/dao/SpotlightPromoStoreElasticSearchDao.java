package com.lowes.promotionstore.repository.dao;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch.core.UpdateRequest;
import co.elastic.clients.elasticsearch.core.bulk.BulkOperation;
import com.lowes.promotionstore.entity.spotlight.PromotionJsonField;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.repository.es.SpotlightPromoStoreRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
@RequiredArgsConstructor
@Slf4j
public class SpotlightPromoStoreElasticSearchDao {

  private final SpotlightPromoStoreRepository spotlightPromoStoreRepository;
  private final ElasticsearchClient esClient;

  /* ---------- Full replace (existing behavior) ---------- */
  public void savePromotionStoreDocument(PromotionStore promotionStore) {
    if (promotionStore == null) {
      log.warn("Skip save: null document");
      return;
    }
    log.info("Saving (replace) id={}", promotionStore.getId());
    spotlightPromoStoreRepository.save(promotionStore);
  }

  public void savePromotionStoreDocuments(List<PromotionStore> promotionStores) {
    if (CollectionUtils.isEmpty(promotionStores)) {
      log.warn("Skip saveAll: empty list");
      return;
    }
    log.info("Saving (replace) {} docs", promotionStores.size());
    spotlightPromoStoreRepository.saveAll(promotionStores);
  }

  /* ---------- 1) Simple partial upsert (last-write-wins) ---------- */
  public void upsertPartial(Map<String, Object> doc, String id) {
    if (doc == null || id == null) {
      log.warn("Skip partial upsert: null doc/id");
      return;
    }

    var index = indexName();
    var req = UpdateRequest.of(u -> u
        .index(index)
        .id(id)
        .doc(doc)
        .docAsUpsert(true)
    );

    try {
      var resp = esClient.update(req, PromotionStore.class);
      log.debug("Partial upsert id={} result={}", id, resp.result());
    } catch (IOException e) {
      log.error("""
          Partial upsert failed for id={} (index={}): {}
          """, id, index, e.getMessage(), e);
      throw new RuntimeException(e);
    }
  }

  public void upsertPartial(PromotionStore doc, Map<String, Object> partial) {
    log.info("Partial upsert id={}", doc.getId());
    if (doc == null || doc.getId() == null) {
      log.warn("Skip partial upsert: null doc/id");
      return;
    }

    var index = indexName();
    var req = UpdateRequest.of(u -> u
        .index(index)
        .id(doc.getId())
        .doc(partial)
        .docAsUpsert(true)
    );

    try {
      var resp = esClient.update(req, PromotionStore.class);
      log.debug("Partial upsert id={} result={}", doc.getId(), resp.result());
    } catch (IOException e) {
      log.error("""
          Partial upsert failed for id={} (index={}): {}
          """, doc.getId(), index, e.getMessage(), e);
      throw new RuntimeException(e);
    }
  }

  public void upsertPartialBulkInOrder(List<Map<String, Object>> docs) throws IOException {
    if (CollectionUtils.isEmpty(docs)) {
      return;
    }

    var index = indexName();
    var ops = new ArrayList<BulkOperation>();

    for (var doc : docs) {
      var id = extractDocumentId(doc);
      if (id == null) {
        continue;
      }

      ops.add(BulkOperation.of(b -> b.update(u -> u
          .index(index)
          .id(id)
          .action(a -> a.doc(doc).docAsUpsert(true))
      )));
    }

    if (ops.isEmpty()) {
      return;
    }

    var resp = esClient.bulk(b -> b.operations(ops));
    if (Boolean.TRUE.equals(resp.errors())) {
      handleBulkErrors(resp.items());
      throw new RuntimeException("Bulk write had errors");
    }
  }

  private String extractDocumentId(Map<String, Object> doc) {
    return doc.containsKey(PromotionJsonField.id.name()) &&
        doc.getOrDefault(PromotionJsonField.id.name(), null) != null
        ? doc.get(PromotionJsonField.id.name()).toString()
        : null;
  }

  private void handleBulkErrors(
      List<co.elastic.clients.elasticsearch.core.bulk.BulkResponseItem> items) {
    items.stream()
        .filter(item -> item.error() != null)
        .forEach(item -> log.error("""
            Bulk write error id={} status={} error={}
            """, item.id(), item.status(), item.error().reason()));
  }
  /* ---------- Read operations ---------- */

  public Optional<PromotionStore> getPromotionStoreDataById(String promotionId) {
    if (promotionId == null) {
      log.error("Promotion Id cannot be null");
      return Optional.empty();
    }
    return spotlightPromoStoreRepository.findById(promotionId);
  }

  /* ---------- Utility methods ---------- */

  private String indexName() {
    var doc = PromotionStore.class.getAnnotation(Document.class);
    return (doc != null && doc.indexName() != null && !doc.indexName().isBlank())
        ? doc.indexName()
        : "promotion_store";
  }

  private Map<String, Object> merge(Map<String, Object> base, Map<String, Object> extra) {
    var merged = new HashMap<>(base);
    merged.putAll(extra);
    return merged;
  }
}
