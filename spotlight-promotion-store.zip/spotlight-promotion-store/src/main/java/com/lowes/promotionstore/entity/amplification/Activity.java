package com.lowes.promotionstore.entity.amplification;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDateTime;


@Entity
@Table(name = "activities")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Activity {

  @Id
  @Column(name = "activity_id", nullable = false)
  private String activityId;

  // materialized columns derived from payload
  @Column(name = "status")
  private String status;

  @Column(name = "start_date")
  private LocalDateTime startDate;

  @Column(name = "end_date")
  private LocalDateTime endDate;

  // full activity snapshot (everything else) lives here
  @JdbcTypeCode(SqlTypes.JSON)
  @Column(name = "payload", nullable = false, columnDefinition = "jsonb")
  private ActivityPayloadJson payload;

  @Column(name = "created_at", nullable = false, columnDefinition = "timestamptz")
  private LocalDateTime createdAt;

  @Column(name = "updated_at", nullable = false, columnDefinition = "timestamptz")
  private LocalDateTime updatedAt;
}

