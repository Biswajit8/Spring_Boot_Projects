package com.lowes.promotionstore.repository.postgres;

import com.lowes.promotionstore.entity.amplification.Activity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface ActivityRepository extends JpaRepository<Activity, String> {

  @Query("""
        select (count(a) > 0)
          from Activity a
         where a.activityId = :id
           and upper(a.status) in :blocked
      """)
  boolean existsWithStatusIn(@Param("id") String id,
      @Param("blocked") java.util.Collection<String> blocked);

}