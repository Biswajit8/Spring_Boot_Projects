package com.lowes.promotionstore.listener;

import com.lowes.genie.avro.outboundEvent.OutboundEvent;
import com.lowes.promotionstore.component.OutboundEventMapper;
import com.lowes.promotionstore.configuration.KafkaConsumerToggleConfig;
import com.lowes.promotionstore.model.record.feedback.OfferEventPayloadDto;
import com.lowes.promotionstore.service.OfferAmplificationService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.stereotype.Component;

@Slf4j
@Component
@RequiredArgsConstructor
public class OfferFeedbackListener {

  private final KafkaConsumerToggleConfig toggle;
  private final OfferAmplificationService service;
  private final OutboundEventMapper mapper;

  @KafkaListener(
      id = "offerFeedback",
      topics = "${application.kafka.consumer.offerFeedbackListener.topic}",
      containerFactory = "offerFeedbackConsumer"
  )
  public void onOfferFeedback(ConsumerRecord<String, OutboundEvent> r, Acknowledgment ack) {
    if (!toggle.isEnableFeedback()) {
      log.info("Feedback consumer disabled; skipping and acking record t/p/o={}/{}/{} key={}",
          r.topic(), r.partition(), r.offset(), r.key());
      ack.acknowledge();
      return;
    }

    String traceId = header(r, "TraceId");
    String chanelId = header(r, "Channel");
    String type = header(r, "Type");
    String operation = header(r, "Operation");
    String activityId = r.key();

    try {
      log.info(
          " Message recived from kafka: activityId:{}, traceId, {}, channeId:{}, "
              + "tyoe:{}, Operation:{}, src={} ",
          activityId, traceId, chanelId, type, operation, r.value());
      OfferEventPayloadDto dto = mapper.toDto(r.value());
      log.info(" Message converted to payload: src={} ", dto);
      service.process(dto, r.topic(), traceId);

      ack.acknowledge();

    } catch (BadRequestException e) {
      log.warn(
          "Bad request for t/p/o={}/{}/{} activityId:{}, traceId, {}, channeId:{}, tyoe:{}, "
              + "Operation:{}, src={}, exception={} ",
          r.topic(), r.partition(), r.offset(), activityId, traceId, chanelId, type, operation,
          r.value(), e.getMessage());
      ack.acknowledge();

    } catch (RuntimeException e) {
      log.error("Processing failed t/p/o={}/{}/{} key={} traceId={}",
          r.topic(), r.partition(), r.offset(), r.key(), traceId, e);
      throw e;
    }
  }


  private static String header(ConsumerRecord<?, ?> r, String name) {
    var h = r.headers().lastHeader(name);
    return h == null ? null : new String(h.value(), java.nio.charset.StandardCharsets.UTF_8);
  }
}
