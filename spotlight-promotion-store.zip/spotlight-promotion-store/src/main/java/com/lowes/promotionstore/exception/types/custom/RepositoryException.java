package com.lowes.promotionstore.exception.types.custom;

import com.lowes.promotionstore.exception.constants.ErrorEnums.ErrorCodeEnum;
import com.lowes.promotionstore.exception.constants.ErrorEnums.ErrorTypeEnum;
import com.lowes.promotionstore.exception.types.base.SpotlightRuntimeException;
import org.springframework.http.HttpStatus;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;

import static com.lowes.promotionstore.exception.types.custom.SpotlightApplicationException.SYSTEM_NAME;
import static com.lowes.promotionstore.exception.types.custom.SpotlightApplicationException.ZONE_UTC;


public class RepositoryException extends SpotlightRuntimeException {

  public RepositoryException(ErrorTypeEnum errorType,
      ErrorCodeEnum errorCode,
      HttpStatus exceptionHttpStatus,
      Throwable actualException) {
    super(actualException.getMessage(), errorType, errorCode, SYSTEM_NAME, exceptionHttpStatus,
        Timestamp.valueOf(
            LocalDateTime.now(ZoneId.of(ZONE_UTC))), actualException);
  }

  public RepositoryException(ErrorTypeEnum errorType,
      ErrorCodeEnum errorCode,
      HttpStatus exceptionHttpStatus) {
    super(errorCode.getMessage(), errorType, errorCode, SYSTEM_NAME, exceptionHttpStatus,
        Timestamp.valueOf(
            LocalDateTime.now(ZoneId.of(ZONE_UTC))));
  }

  public RepositoryException(ErrorTypeEnum errorType,
      ErrorCodeEnum errorCode,
      String message,
      HttpStatus exceptionHttpStatus) {
    super(message, errorType, errorCode, SYSTEM_NAME, exceptionHttpStatus, Timestamp.valueOf(
        LocalDateTime.now(ZoneId.of(ZONE_UTC))));
  }
}
