package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record RewardItemAttributesPayloadDto(String catalogRef, PromotionPayloadEnums.UnitEnum unit, Double value) {

}
