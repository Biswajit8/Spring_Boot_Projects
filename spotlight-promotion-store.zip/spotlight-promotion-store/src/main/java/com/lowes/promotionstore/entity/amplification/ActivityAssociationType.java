package com.lowes.promotionstore.entity.amplification;

public enum ActivityAssociationType {
  OFFER, CAMPAIGN, PAGE, BLOCK
}
