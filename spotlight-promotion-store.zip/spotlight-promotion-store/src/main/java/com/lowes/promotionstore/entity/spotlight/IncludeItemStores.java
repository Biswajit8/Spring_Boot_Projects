package com.lowes.promotionstore.entity.spotlight;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.util.HashSet;
import java.util.Set;

@SuppressWarnings("java:S1068")
@Data
public class IncludeItemStores {

  @JsonProperty("item_no")
  @Field(type = FieldType.Keyword, name = "item_no")
  private String itemNo;

  @JsonProperty("model_no")
  @Field(type = FieldType.Keyword, name = "model_no")
  private String modelNo;

  @JsonProperty("service_item")
  @Field(type = FieldType.Boolean, name = "service_item")
  private Boolean serviceItem;

  @JsonProperty("vendor_no")
  @Field(type = FieldType.Keyword, name = "vendor_no")
  private String vendorNo;

  @JsonProperty("default_item")
  @Field(type = FieldType.Boolean, name = "default_item")
  private boolean defaultItem;

  @JsonProperty("offer_price")
  @Field(type = FieldType.Keyword, name = "offer_price")
  private String offerPrice;

  @JsonProperty("discount_type")
  @Field(type = FieldType.Keyword, name = "discount_type")
  private String discountType;

  @JsonProperty("discount_value")
  @Field(type = FieldType.Keyword, name = "discount_value")
  private String discountValue;

  @JsonProperty("stores")
  @Field(type = FieldType.Keyword, name = "stores")
  private Set<String> stores = new HashSet<>();

  @JsonProperty("patches")
  @Field(type = FieldType.Keyword, name = "patches")
  private Set<String> patches = new HashSet<>();

  @JsonProperty("item_qualification_type")
  @Field(type = FieldType.Keyword, name = "item_qualification_type")
  private String itemQualificationType;
}
