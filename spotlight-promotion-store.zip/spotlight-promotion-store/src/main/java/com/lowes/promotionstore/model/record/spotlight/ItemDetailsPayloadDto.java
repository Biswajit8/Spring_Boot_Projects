package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record ItemDetailsPayloadDto(String itemNo, String vendorNo, String modelNo, Boolean serviceItem,
                                    boolean defaultItem,
                                    Integer priority, Double discountValue,
                                    LocationsPayloadDto locations) {

}
