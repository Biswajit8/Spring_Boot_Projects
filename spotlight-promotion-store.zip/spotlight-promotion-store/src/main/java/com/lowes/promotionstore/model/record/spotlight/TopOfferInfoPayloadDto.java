package com.lowes.promotionstore.model.record.spotlight;

import java.util.Objects;

public record TopOfferInfoPayloadDto(
        Boolean topOffer,
        Boolean doorBuster,
        TopOfferScheduleDto topOfferSchedule
) {

  public TopOfferInfoPayloadDto {
    if (Objects.isNull(topOffer)) {
      doorBuster = null;
    }
    if (Boolean.FALSE.equals(topOffer)) {
      doorBuster = Boolean.FALSE;
    }
  }
}
