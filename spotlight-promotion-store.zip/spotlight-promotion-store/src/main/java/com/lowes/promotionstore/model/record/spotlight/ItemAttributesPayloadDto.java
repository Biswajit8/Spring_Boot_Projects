package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record ItemAttributesPayloadDto(String catalogRef,
                                       PromotionPayloadEnums.UnitEnum unit, Boolean mixAndMatch,
                                       Double value,
                                       Double min, Double max, Boolean xOrMore,
                                       List<PromotionPayloadEnums.PaymentModes> paymentModes,
                                       PromotionPayloadEnums.PurchaseMode purchaseMode) {

  public ItemAttributesPayloadDto {
    if (CollectionUtils.isEmpty(paymentModes)) {
      paymentModes = new ArrayList<>();
    }
  }
}
