package com.lowes.promotionstore.component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lowes.promotionstore.configuration.ObjectMapperConfig;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.model.record.spotlight.ForecastDataDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Slf4j
@Component
@RequiredArgsConstructor
public class ForecastDataMapper {

  private final ObjectMapperConfig objectMapper;

  public PromotionStore mapForecastData(PromotionStore promotionStore,
      ForecastDataDto forecastData) throws JsonProcessingException {
    if (Objects.isNull(forecastData)) {
      return promotionStore;
    }
    promotionStore.setId(forecastData.promotionId());
    promotionStore.setPromotionROI(forecastData.promotionROI());
    promotionStore.setPromotedMarginWithFunding(forecastData.promotedMarginWithFunding());
    promotionStore.setSwitchingAdjustedIncrementalMargin(
        forecastData.switchingAdjustedIncrementalMargin());
    promotionStore.setPromotedSales(forecastData.promotedSales());
    promotionStore.setSwitchingAdjustedIncrementalSales(
        forecastData.switchingAdjustedIncrementalSales());
    promotionStore.setPromotedVolume(forecastData.promotedVolume());
    promotionStore.setSwitchingAdjustedIncrementalVolume(
        forecastData.switchingAdjustedIncrementalVolume());
    promotionStore.setTotalPromotionFundingPerUnit(forecastData.totalPromotionFundingPerUnit());
    promotionStore.setTotalFundingCapped(forecastData.totalFundingCapped());
    promotionStore.setNetCouponExpense(forecastData.netCouponExpense());
    promotionStore.setDiscountPercent(forecastData.discountPercent());
    promotionStore.setPercentUpLiftSales(forecastData.percentUpLiftSales());
    promotionStore.setPercentUpLiftUnits(forecastData.percentUpLiftUnits());
    promotionStore.setPercentUpliftMarginWithFunding(forecastData.percentUpliftMarginWithFunding());
    promotionStore.setFundingGapPerUnit(forecastData.fundingGapPerUnit());
    promotionStore.setFundingGapPct(forecastData.fundingGapPct());
    promotionStore.setAccuracyIndicator(forecastData.accuracyIndicator());
    promotionStore.setTotalFundingGap(forecastData.totalFundingGap());
    promotionStore.setPercentUpliftSalesWithHalo(forecastData.percentUpliftSalesWithHalo());
    promotionStore.setPercentUpliftMarginWithHalo(forecastData.percentUpliftMarginWithHalo());
    promotionStore.setRawOfferForcast((Objects.isNull(forecastData)) ? null
        : objectMapper.objectMapper().writeValueAsString(forecastData));

    return promotionStore;
  }

}