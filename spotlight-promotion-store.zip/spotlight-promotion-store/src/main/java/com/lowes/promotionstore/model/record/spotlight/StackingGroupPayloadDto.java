package com.lowes.promotionstore.model.record.spotlight;

public record StackingGroupPayloadDto(boolean stackWithOtherOffers) {

}
