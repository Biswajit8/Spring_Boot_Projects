package com.lowes.promotionstore.component;

import com.lowes.genie.avro.outboundEvent.Activity;
import com.lowes.genie.avro.outboundEvent.Block;
import com.lowes.genie.avro.outboundEvent.Campaign;
import com.lowes.genie.avro.outboundEvent.Criteria;
import com.lowes.genie.avro.outboundEvent.Metadata;
import com.lowes.genie.avro.outboundEvent.OfferItem;
import com.lowes.genie.avro.outboundEvent.OutboundEvent;
import com.lowes.genie.avro.outboundEvent.Page;
import com.lowes.genie.avro.outboundEvent.Reward;
import com.lowes.promotionstore.model.record.feedback.ActivityPayloadDto;
import com.lowes.promotionstore.model.record.feedback.BlockPayloadDto;
import com.lowes.promotionstore.model.record.feedback.CampaignPayloadDto;
import com.lowes.promotionstore.model.record.feedback.CriteriaDto;
import com.lowes.promotionstore.model.record.feedback.FeaturedItemGenieDto;
import com.lowes.promotionstore.model.record.feedback.MetadataDto;
import com.lowes.promotionstore.model.record.feedback.OfferDto;
import com.lowes.promotionstore.model.record.feedback.OfferEventPayloadDto;
import com.lowes.promotionstore.model.record.feedback.PagePayloadDto;
import com.lowes.promotionstore.model.record.feedback.RewardDto;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Collection;
import java.util.List;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Maps Avro OutboundEvent -> ActivityPayloadDto (and nested DTOs).
 * <p>
 * Avro source package: com.lowes.genie.avro.outboundEvent DTO target package:
 * com.lowes.promotionstore.model.feedback
 */
@Component
@Slf4j
public final class OutboundEventMapper {

  public OutboundEventMapper() {
  }

  private static final DateTimeFormatter DTF = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
  private static final ZoneId FALLBACK_ZONE = ZoneId.of("Asia/Kolkata");

  public OfferEventPayloadDto toDto(OutboundEvent src) {
    if (src == null) {
      return null;
    }

    return OfferEventPayloadDto.builder()
        .id(toStr(src.getId()))
        .type(toStr(src.getType()))
        .operation(toStr(src.getOperation()))
        .channel(toStr(src.getChannel()))
        .campaign(mapCampaign(src.getCampaign()))
        .activity(mapActivity(src.getActivity()))
        .offer(mapOffer(src.getOffer()))
        .page(mapPage(src.getPage()))
        .block(mapBlock(src.getBlock()))
        .build();
  }

  private BlockPayloadDto mapBlock(Block block) {
    if (ObjectUtils.isEmpty(block)) {
      return null;
    }
    return BlockPayloadDto.builder()
        .id(block.getId())
        .alias(block.getAlias())
        .number(toStr(block.getNumber()))
        .build();
  }

  private PagePayloadDto mapPage(Page page) {
    if (ObjectUtils.isEmpty(page)) {
      return null;
    }
    return PagePayloadDto.builder()
        .id(page.getId())
        .alias(page.getAlias())
        .type(page.getType())
        .number(page.getNumber())
        .build();
  }

  private CampaignPayloadDto mapCampaign(Campaign c) {
    if (c == null) {
      return null;
    }
    return CampaignPayloadDto.builder()
        .id(toStr(c.getId()))
        .name(toStr(c.getName()))
        .build();
  }

  private ActivityPayloadDto mapActivity(Activity a) {
    if (a == null) {
      return null;
    }

    return ActivityPayloadDto.builder()
        .id(toStr(a.getId()))
        .alias(toStr(a.getAlias()))
        .name(toStr(a.getName()))
        .status(toStr(a.getStatus()))
        .startDate(parseDate(a.getStartDate()))
        .endDate(parseDate(a.getEndDate()))
        .customers(toStringList(a.getCustomers()))
        .distribution(toStringList(a.getDistribution()))
        .build();
  }

  private OfferDto mapOffer(com.lowes.genie.avro.outboundEvent.Offer o) {
    if (o == null) {
      return null;
    }

    return OfferDto.builder()
        .offerId(toStr(o.getOfferId()))
        .allocationId(toStr(o.getAllocationId()))
        .patches(o.getPatches())
        .metadata(mapList(o.getMetadata(), OutboundEventMapper::mapMetadata))
        .build();
  }

  private static MetadataDto mapMetadata(Metadata m) {
    if (m == null) {
      return null;
    }

    return MetadataDto.builder()
        .metadataId(toStringOrNull(m.getMetadataId()))
        .criteria(mapList(m.getCriteria(), OutboundEventMapper::mapCriteria))
        .rewards(mapList(m.getRewards(), OutboundEventMapper::mapReward))
        .build();
  }

  private static CriteriaDto mapCriteria(Criteria c) {
    if (c == null) {
      return null;
    }

    return CriteriaDto.builder()
        .criteriaId(toStringOrNull(c.getCriteriaId()))
        .featuredItems(mapList(c.getFeaturedItems(), OutboundEventMapper::mapFeaturedItem))
        .build();
  }

  private static RewardDto mapReward(Reward r) {
    if (r == null) {
      return null;
    }

    // Avro "Reward.featuredItems" uses OfferItem; map it to DTO FeaturedItem.
    return RewardDto.builder()
        .rewardId(toStringOrNull(r.getRewardId()))
        .featuredItems(
            mapList(r.getFeaturedItems(), OutboundEventMapper::mapOfferItemToFeaturedItem))
        .build();
  }

  private static FeaturedItemGenieDto mapFeaturedItem(
      com.lowes.genie.avro.outboundEvent.FeaturedItem f) {
    if (f == null) {
      return null;
    }

    return FeaturedItemGenieDto.builder()
        .item(toStr(f.getItem()))
        .vendor(toStr(f.getVendor()))
        .model(toStr(f.getModel()))
        .patches(toStringList(f.getPatches()))
        .build();
  }

  private static FeaturedItemGenieDto mapOfferItemToFeaturedItem(OfferItem oi) {
    if (oi == null) {
      return null;
    }

    return FeaturedItemGenieDto.builder()
        .item(toStr(oi.getItem()))
        .vendor(toStr(oi.getVendor()))
        .model(toStr(oi.getModel()))
        .patches(toStringList(oi.getPatches()))
        .build();
  }

  private static String toStr(Object o) {
    return o == null ? null : o.toString();
  }

  private static String toStringOrNull(Integer i) {
    return i == null ? null : String.valueOf(i);
  }

  private static List<String> toStringList(Collection<?> src) {
    if (src == null) {
      return null;
    }
    return src.stream()
        .filter(Objects::nonNull)
        .map(Object::toString)
        .collect(Collectors.toList());
  }

  private static <S, T> List<T> mapList(Collection<S> src, Function<S, T> mapper) {
    if (src == null) {
      return null;
    }
    return src.stream()
        .map(mapper)
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
  }

  private LocalDateTime parseDate(CharSequence cs) {
    if (cs == null) {
      return null;
    }
    String s = cs.toString().trim();
    if (s.isEmpty()) {
      return null;
    }

    try {
      return LocalDateTime.parse(s, DTF);
    } catch (DateTimeParseException ignore) {
      log.warn("Exception while parsing date: {}", cs, ignore);
    }

    try {
      return LocalDateTime.parse(s);
    } catch (DateTimeParseException ignore) {
      log.warn("Exception while parsing date: {}", cs, ignore);
    }

    try {
      return OffsetDateTime.parse(s).toLocalDateTime();
    } catch (DateTimeParseException ignore) {
      log.warn("Exception while parsing date: {}", cs, ignore);
    }

    try {
      return LocalDateTime.ofInstant(Instant.parse(s), FALLBACK_ZONE);
    } catch (DateTimeParseException ignore) {
      log.warn("Exception while parsing date: {}", cs, ignore);
    }

    return null;
  }
}
