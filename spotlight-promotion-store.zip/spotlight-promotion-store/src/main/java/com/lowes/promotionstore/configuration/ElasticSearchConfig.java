package com.lowes.promotionstore.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.elasticsearch.client.ClientConfiguration;
import org.springframework.data.elasticsearch.client.elc.ElasticsearchConfiguration;
import org.springframework.data.elasticsearch.support.HttpHeaders;
import org.springframework.util.StringUtils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

@Configuration
public class ElasticSearchConfig extends ElasticsearchConfiguration {

  @Value("${application.elastic.offers-api.ssl-root-cert}")
  private String sslrootcert;

  @Value("${application.elastic.offers-api.username}")
  private String username;

  @Value("${application.elastic.offers-api.password}")
  private String password;

  @Value("${application.elastic.offers-api.host}")
  private String elasticSearchHost;

  // ✅ ADD THIS: cached SSLContext (thread-safe via volatile + double-check locking)
  private volatile SSLContext cachedSslContext;

  // ✅ OPTIONAL BUT RECOMMENDED: cache "no SSL" decision too
  private volatile boolean sslContextInitialized = false;

  @Override
  public ClientConfiguration clientConfiguration() {
    HttpHeaders defaultHeaders = new HttpHeaders();

    String credentials = username + ":" + password;
    String encodedAuth = Base64.getEncoder()
        .encodeToString(credentials.getBytes(StandardCharsets.UTF_8));
    defaultHeaders.add("Authorization", "Basic " + encodedAuth);
    defaultHeaders.add("Content-Type", "application/json");

    try {
      ClientConfiguration.MaybeSecureClientConfigurationBuilder config = ClientConfiguration.builder()
          .connectedTo(elasticSearchHost);

      SSLContext sslContext = getSSLContext();
      if (sslContext != null) {
        config.usingSsl(sslContext);
      }

      return config.withDefaultHeaders(defaultHeaders).build();
    } catch (IOException | CertificateException | KeyStoreException | NoSuchAlgorithmException |
             KeyManagementException | UnrecoverableKeyException e) {
      throw new RuntimeException("Failed to configure Elasticsearch client", e);
    }
  }

  private SSLContext getSSLContext() throws
      IOException, CertificateException, KeyStoreException,
      NoSuchAlgorithmException, KeyManagementException, UnrecoverableKeyException {

    // ✅ Fast path: we've already initialized (either to a real SSLContext or to "null")
    if (sslContextInitialized) {
      return cachedSslContext;
    }

    synchronized (this) {
      if (sslContextInitialized) {
        return cachedSslContext;
      }

      if (!StringUtils.hasText(sslrootcert)) {
        // cache the "no SSL" state so we don't keep checking
        cachedSslContext = null;
        sslContextInitialized = true;
        return null;
      }

      String sslKey = Files.readString(Path.of(sslrootcert));
      List<String> pemCerts = extractPemCertificates(sslKey);

      if (pemCerts.size() != 2) {
        throw new IllegalArgumentException("Expected exactly 2 certificates in PEM file.");
      }

      CertificateFactory cf = CertificateFactory.getInstance("X.509");

      Certificate caCert;
      try (InputStream caStream = new ByteArrayInputStream(
          Base64.getDecoder().decode(pemCerts.get(0)))) {
        caCert = cf.generateCertificate(caStream);
      }

      KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
      trustStore.load(null, null);
      trustStore.setCertificateEntry("ca", caCert);

      TrustManagerFactory tmf = TrustManagerFactory.getInstance(
          TrustManagerFactory.getDefaultAlgorithm());
      tmf.init(trustStore);

      Certificate clientCert;
      try (InputStream clientStream = new ByteArrayInputStream(
          Base64.getDecoder().decode(pemCerts.get(1)))) {
        clientCert = cf.generateCertificate(clientStream);
      }

      KeyStore keyStore = KeyStore.getInstance(KeyStore.getDefaultType());
      keyStore.load(null, null);
      keyStore.setCertificateEntry("client", clientCert);

      KeyManagerFactory kmf = KeyManagerFactory.getInstance(
          KeyManagerFactory.getDefaultAlgorithm());
      kmf.init(keyStore, null);

      SSLContext context = SSLContext.getInstance("TLS");
      context.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);

      cachedSslContext = context;
      sslContextInitialized = true;
      return cachedSslContext;
    }
  }

  private List<String> extractPemCertificates(String pemContent) {
    List<String> certs = new ArrayList<>();
    Matcher matcher = Pattern.compile(
            "-----BEGIN CERTIFICATE-----(.*?)-----END CERTIFICATE-----", Pattern.DOTALL)
        .matcher(pemContent);

    while (matcher.find()) {
      String base64Cert = matcher.group(1).replaceAll("\\s+", "");
      certs.add(base64Cert);
    }

    return certs;
  }
}
