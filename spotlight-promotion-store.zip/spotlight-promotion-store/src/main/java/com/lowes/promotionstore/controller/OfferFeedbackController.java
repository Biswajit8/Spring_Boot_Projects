package com.lowes.promotionstore.controller;

import com.lowes.promotionstore.model.record.feedback.OfferEventPayloadDto;
import com.lowes.promotionstore.service.OfferAmplificationService;
import lombok.AllArgsConstructor;
import org.apache.coyote.BadRequestException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping
@AllArgsConstructor
public class OfferFeedbackController {

  private final OfferAmplificationService offerAmplificationService;

  @PostMapping(value = "/feedback")
  public ResponseEntity<String> processFeedbackListener(
          @RequestBody OfferEventPayloadDto offerEvent) {
    try {
      offerAmplificationService.process(offerEvent, "genie.outbound.event",
              "e7e9b7b7-827b-48b2-bd26-0fe9e7ed8a23");
      return ResponseEntity.accepted().body("Data was saved successfully in the table");
    } catch (BadRequestException e) {
      return ResponseEntity.badRequest().body("Bad Request: " + e.getMessage());
    } catch (Exception e) {
      return ResponseEntity.internalServerError().body("Error: " + e.getMessage());
    }
  }

}
