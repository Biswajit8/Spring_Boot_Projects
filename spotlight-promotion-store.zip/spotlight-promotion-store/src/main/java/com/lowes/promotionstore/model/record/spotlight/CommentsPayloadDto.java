package com.lowes.promotionstore.model.record.spotlight;

public record CommentsPayloadDto(
    String commentId, String commentText,
    String createdBy,
    String createdTs,
    String modifiedTs,
    String modifiedBy,
    String spotlightUserRole) {

}
