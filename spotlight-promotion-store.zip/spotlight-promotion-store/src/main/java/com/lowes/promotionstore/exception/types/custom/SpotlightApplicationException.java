package com.lowes.promotionstore.exception.types.custom;

import com.lowes.promotionstore.exception.constants.ErrorEnums;
import com.lowes.promotionstore.exception.types.base.SpotlightRuntimeException;
import org.springframework.http.HttpStatus;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;


public class SpotlightApplicationException extends SpotlightRuntimeException {


  public static final String SYSTEM_NAME = "SPOTLIGHT";
  public static final String ZONE_UTC = "UTC";

  public SpotlightApplicationException(ErrorEnums.ErrorCodeEnum errorCode, Throwable ex) {
    super(errorCode.getMessage(), ErrorEnums.ErrorTypeEnum.APPLICATION_ERROR, errorCode,
        SYSTEM_NAME, HttpStatus.INTERNAL_SERVER_ERROR,
        Timestamp.valueOf(LocalDateTime.now(ZoneId.of(ZONE_UTC))), ex);
  }

  public SpotlightApplicationException(ErrorEnums.ErrorCodeEnum errorCode) {
    super(errorCode.getMessage(), ErrorEnums.ErrorTypeEnum.APPLICATION_ERROR, errorCode,
        SYSTEM_NAME, HttpStatus.INTERNAL_SERVER_ERROR,
        Timestamp.valueOf(LocalDateTime.now(ZoneId.of(ZONE_UTC))));
  }

  public SpotlightApplicationException(ErrorEnums.ErrorCodeEnum errorCode, String message,
      HttpStatus httpStatus, Throwable ex) {
    super(message, ErrorEnums.ErrorTypeEnum.APPLICATION_ERROR, errorCode, SYSTEM_NAME, httpStatus,
        Timestamp.valueOf(LocalDateTime.now(ZoneId.of(ZONE_UTC))), ex);
  }
}
