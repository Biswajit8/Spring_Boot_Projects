package com.lowes.promotionstore.entity.spotlight;


import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Dynamic;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Set;

@SuppressWarnings("java:S1068")
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY,
    getterVisibility = JsonAutoDetect.Visibility.NONE,
    isGetterVisibility = JsonAutoDetect.Visibility.NONE)
@Document(indexName = "promotion-store", createIndex = false, dynamic = Dynamic.FALSE)
public class PromotionStore extends SalesEnums {

  @Id
  @JsonProperty("id")
  @Field(type = FieldType.Keyword, name = "id")
  private String id;

  @JsonProperty("name")
  @Field(type = FieldType.Text, name = "name")
  private String name;

  @JsonProperty("offer_type")
  @Field(type = FieldType.Keyword, name = "offer_type")
  private String offerType;

  @JsonProperty("offer_type_name")
  @Field(type = FieldType.Text, name = "offer_type_name")
  private String offerTypeName;

  @JsonProperty("offer_sub_type")
  @Field(type = FieldType.Keyword, name = "offer_sub_type")
  private String offerSubType;

  @JsonProperty("offer_sub_type_name")
  @Field(type = FieldType.Text, name = "offer_sub_type_name")
  private String offerSubTypeName;

  @JsonProperty("offer_tactic")
  @Field(type = FieldType.Keyword, name = "offer_tactic")
  private String offerTactic;

  @JsonProperty("active")
  @Field(type = FieldType.Boolean, name = "active")
  private Boolean active;

  @JsonProperty("activated_by")
  @Field(type = FieldType.Text, name = "activated_by")
  private String activatedBy;

  @JsonProperty("activated_ts")
  @JsonFormat(shape = JsonFormat.Shape.STRING,
      pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
      timezone = "UTC")
  @Field(type = FieldType.Date, format = DateFormat.date_time, name = "activated_ts")
  private Instant activatedTs;

  @JsonProperty("indexed_ts")
  @Field(type = FieldType.Date, format = DateFormat.date_time, name = "indexed_ts")
  @JsonFormat(shape = JsonFormat.Shape.STRING,
      pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
      timezone = "UTC")
  private Instant indexedTs;

  @JsonProperty("auto_apply_code")
  @Field(type = FieldType.Keyword, name = "auto_apply_code")
  private String autoApplyCode;

  @JsonProperty("calendar_week")
  @Field(type = FieldType.Integer, name = "calendar_week")
  private Integer calendarWeek;

  @JsonProperty("coupon_code")
  @Field(type = FieldType.Keyword, name = "coupon_code")
  private String couponCode;

  @JsonProperty("created_by")
  @Field(type = FieldType.Text, name = "created_by")
  private String createdBy;

  @JsonProperty("created_ts")
  @Field(type = FieldType.Date, name = "created_ts")
  @JsonFormat(shape = JsonFormat.Shape.STRING,
      pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
      timezone = "UTC")
  private Instant createdTs;

  @JsonProperty("modified_ts")
  @Field(type = FieldType.Date, name = "modified_ts")
  @JsonFormat(shape = JsonFormat.Shape.STRING,
      pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
      timezone = "UTC")
  private Instant modifiedTs;

  @JsonProperty("modified_by")
  @Field(type = FieldType.Text, name = "modified_by")
  private String modifiedBy;

  @JsonProperty("deactivated_ts")
  @Field(type = FieldType.Date, name = "deactivated_ts")
  @JsonFormat(shape = JsonFormat.Shape.STRING,
      pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
      timezone = "UTC")
  private Instant deactivatedTs;

  @JsonProperty("deactivated_by")
  @Field(type = FieldType.Text, name = "deactivated_by")
  private String deactivatedBy;

  @JsonProperty("customer_type")
  @Field(type = FieldType.Keyword, name = "customer_type")
  private String customerType;

  @JsonProperty("no_end_date")
  @Field(type = FieldType.Boolean, name = "no_end_date")
  private Boolean noEndDate;

  @JsonProperty("offer_type_id")
  @Field(type = FieldType.Long, name = "offer_type_id")
  private Long offerTypeId;

  @JsonProperty("patches")
  @Field(type = FieldType.Keyword, name = "patches")
  private Set<String> patches;

  @JsonProperty("promo_tracker_link")
  @Field(type = FieldType.Text, name = "promo_tracker_link")
  private String promoTrackerlink;

  @JsonProperty("redemption_type")
  @Field(type = FieldType.Keyword, name = "redemption_type")
  private String redemptionType;

  @JsonProperty("start_date")
  @Field(type = FieldType.Date, name = "start_date")
  @JsonFormat(shape = JsonFormat.Shape.STRING,
      pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
      timezone = "UTC")
  private Instant startDate;

  @JsonProperty("end_date")
  @Field(type = FieldType.Date, name = "end_date")
  @JsonFormat(shape = JsonFormat.Shape.STRING,
      pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
      timezone = "UTC")
  private Instant endDate;

  @JsonProperty("blackout_date")
  @Field(type = FieldType.Date, name = "blackout_date")
  @JsonFormat(shape = JsonFormat.Shape.STRING,
      pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'",
      timezone = "UTC")
  private Instant blackoutDate;

  @JsonProperty("status")
  @Field(type = FieldType.Keyword, name = "status")
  private String status;

  @JsonProperty("stores")
  @Field(type = FieldType.Keyword, name = "stores")
  private Set<Integer> stores;

  @JsonProperty("sub_divisions")
  @Field(type = FieldType.Keyword, name = "sub_divisions")
  private Set<Integer> subDivisions;

  @JsonProperty("divisions")
  @Field(type = FieldType.Keyword, name = "divisions")
  private Set<Integer> divisions;

  @JsonProperty("include_all_stores")
  @Field(type = FieldType.Boolean, name = "include_all_stores")
  private Boolean includeAllStores;

  @JsonProperty("patch_offer")
  @Field(type = FieldType.Boolean, name = "patch_offer")
  private Boolean patchOffer;

  @JsonProperty("event_ids")
  @Field(type = FieldType.Keyword, name = "event_ids")
  private Set<Integer> eventIds;

  @JsonProperty("market_scope")
  @Field(type = FieldType.Keyword, name = "market_scope")
  private PromotionPayloadEnums.MarketScopeEnum marketScope;

  @JsonProperty("loyalties_tier_name")
  @Field(type = FieldType.Keyword, name = "loyalties_tier_name")
  private Set<String> loyaltiesTierName;

  @JsonProperty("loyalties_tier_id")
  @Field(type = FieldType.Keyword, name = "loyalties_tier_id")
  private Set<String> loyaltiesTierId;

  @JsonProperty("include_brand_ids")
  @Field(type = FieldType.Keyword, name = "include_brand_ids")
  private Set<String> includeBrandIds;

  @JsonProperty("include_brand_names")
  @Field(type = FieldType.Text, name = "include_brand_names")
  private Set<String> includeBrandNames;

  @JsonProperty("include_pcrs")
  @Field(type = FieldType.Keyword, name = "include_pcrs")
  private Set<String> includePcrs;

  @JsonProperty("include_digital_taxonomy_ids")
  @Field(type = FieldType.Keyword, name = "include_digital_taxonomy_ids")
  private Set<String> includeDigitalTaxonomyIds;

  @JsonProperty("include_digital_taxonomy_names")
  @Field(type = FieldType.Text, name = "include_digital_taxonomy_names")
  private Set<String> includeDigitalTaxonomyNames;

  @JsonProperty("include_merch_bucket_ids")
  @Field(type = FieldType.Keyword, name = "include_merch_bucket_ids")
  private Set<String> includeMerchBucketIds;

  @JsonProperty("include_merch_bucket_names")
  @Field(type = FieldType.Text, name = "include_merch_bucket_names")
  private Set<String> includeMerchBucketNames;

  @JsonProperty("include_product_types")
  @Field(type = FieldType.Keyword, name = "include_product_types")
  private Set<PromotionPayloadEnums.ProductTypeEnum> includeProductTypes;

  @JsonProperty("include_items")
  @Field(type = FieldType.Keyword, name = "include_items")
  private Set<IncludeItemStores> includeItemStores;

  @JsonProperty("exclude_brand_ids")
  @Field(type = FieldType.Keyword, name = "exclude_brand_ids")
  private Set<String> excludeBrandIds;

  @JsonProperty("exclude_brand_names")
  @Field(type = FieldType.Text, name = "exclude_brand_names")
  private Set<String> excludeBrandNames;

  @JsonProperty("exclude_digital_taxonomy_ids")
  @Field(type = FieldType.Keyword, name = "exclude_digital_taxonomy_ids")
  private Set<String> excludeDigitalTaxonomyIds;

  @JsonProperty("exclude_digital_taxonomy_names")
  @Field(type = FieldType.Text, name = "exclude_digital_taxonomy_names")
  private Set<String> excludeDigitalTaxonomyNames;

  @JsonProperty("exclude_merch_bucket_ids")
  @Field(type = FieldType.Keyword, name = "exclude_merch_bucket_ids")
  private Set<String> excludeMerchBucketIds;

  @JsonProperty("exclude_merch_bucket_names")
  @Field(type = FieldType.Text, name = "exclude_merch_bucket_names")
  private Set<String> excludeMerchBucketNames;

  @JsonProperty("exclude_product_types")
  @Field(type = FieldType.Keyword, name = "exclude_product_types")
  private Set<PromotionPayloadEnums.ProductTypeEnum> excludeProductTypes;

  @JsonProperty("exclude_items")
  @Field(type = FieldType.Keyword, name = "exclude_items")
  private Set<ExcludeItem> excludeItems;

  @JsonProperty("conditionGroups_item_catalog_ref")
  @Field(type = FieldType.Keyword, name = "conditiongroups_item_catalog_ref")
  private Set<String> conditionGroupCatalogRef;

  @JsonProperty("conditiongroups_item_quantity")
  @Field(type = FieldType.Double, name = "conditiongroups_item_quantity")
  private Set<Double> conditionGroupQuantity;

  @JsonProperty("conditiongroups_item_spend")
  @Field(type = FieldType.Double, name = "conditiongroups_item_spend")
  private Set<Double> conditionGroupSpend;

  @JsonProperty("conditiongroups_condition_on")
  @Field(type = FieldType.Keyword, name = "conditiongroups_condition_on")
  private Set<PromotionPayloadEnums.ConditionOnEnum> conditionGroupConditionOn;

  @JsonProperty("conditiongroups_condition_type")
  @Field(type = FieldType.Keyword, name = "conditiongroups_condition_type")
  private Set<PromotionPayloadEnums.ConditionTypeEnum> conditionGroupConditionType;

  @JsonProperty("conditiongroups_purchase_mode")
  @Field(type = FieldType.Keyword, name = "conditiongroups_purchase_mode")
  private Set<PromotionPayloadEnums.PurchaseMode> conditionGroupPurchaseMode;

  @JsonProperty("conditiongroups_payment_modes")
  @Field(type = FieldType.Keyword, name = "conditiongroups_payment_modes")
  private Set<PromotionPayloadEnums.PaymentModes> conditionGroupPaymentModes;


  @JsonProperty("conditiongroups_discount_type")
  @Field(type = FieldType.Keyword, name = "conditiongroups_discount_type")
  private Set<PromotionPayloadEnums.DiscountTypeEnum> conditionGroupDiscountType;

  @JsonProperty("rewardgroups_reward_type")
  @Field(type = FieldType.Keyword, name = "rewardgroups_reward_type")
  private Set<PromotionPayloadEnums.RewardTypeEnum> rewardGroupsRewardType;

  @JsonProperty("rewardgroups_reward_on")
  @Field(type = FieldType.Keyword, name = "rewardgroups_reward_on")
  private Set<PromotionPayloadEnums.RewardOnEnum> rewardGroupsRewardOn;

  @JsonProperty("rewardgroups_shipping_category")
  @Field(type = FieldType.Keyword, name = "rewardgroups_shipping_category")
  private Set<String> rewardGroupsShippingCategory;

  @JsonProperty("rewardgroups_shipping_type")
  @Field(type = FieldType.Keyword, name = "rewardgroups_shipping_type")
  private Set<String> rewardGroupsShippingType;

  @JsonProperty("rewardgroups_shipping_shipping_method")
  @Field(type = FieldType.Keyword, name = "rewardgroups_shipping_shipping_method")
  private Set<String> rewardGroupsShippingMethod;

  @JsonProperty("rewardGroups_shipping_fulfillmenttype")
  @Field(type = FieldType.Keyword, name = "rewardgroups_shipping_fulfillmenttype")
  private Set<String> rewardGroupsShippingFulfillmentType;

  @JsonProperty("rewardGroups_item_quantity")
  @Field(type = FieldType.Double, name = "rewardgroups_item_quantity")
  private Set<Double> rewardGroupsItemAttrQuantity;

  @JsonProperty("rewardGroups_item_spend")
  @Field(type = FieldType.Double, name = "rewardgroups_item_spend")
  private Set<Double> rewardGroupsItemAttrSpend;

  @JsonProperty("rewardGroups_item_catalog_ref")
  @Field(type = FieldType.Keyword, name = "rewardgroups_item_catalog_ref")
  private Set<String> rewardGroupsItemAttrCatalogRef;

  @JsonProperty("rewardGroups_finance_months")
  @Field(type = FieldType.Integer, name = "rewardgroups_finance_months")
  private Set<Integer> rewardGroupsFinanceMonths;

  @JsonProperty("rewardGroups_finance_type")
  @Field(type = FieldType.Keyword, name = "rewardgroups_finance_type")
  private Set<PromotionPayloadEnums.FinanceTypeEnum> rewardGroupsFinanceType;

  @JsonProperty("rewardgroups_finance_term_identifier")
  @Field(type = FieldType.Keyword, name = "rewardgroups_finance_term_identifier")
  private Set<String> rewardGroupsFinanceTermIdentifier;

  @JsonProperty("rewardgroups_finance_term_type")
  @Field(type = FieldType.Keyword, name = "rewardgroups_finance_term_type")
  private Set<String> rewardGroupsFinanceTermType;

  @JsonProperty("rewardGroups_finance_blockcode")
  @Field(type = FieldType.Keyword, name = "rewardgroups_finance_blockcode")
  private Set<String> rewardGroupsFinanceBlockCode;

  @JsonProperty("rewardgroups_finance_annual_percent_rate")
  @Field(type = FieldType.Double, name = "rewardgroups_finance_annual_percent_rate")
  private Set<Double> rewardGroupsFinanceAnnualPercentRate;

  @JsonProperty("reward_attribute_quantity")
  @Field(type = FieldType.Keyword, name = "reward_attribute_quantity")
  private Set<PromotionPayloadEnums.RewardQuantityEnum> rewardAttrQuantity;

  @JsonProperty("reward_attribute_quantity_value")
  @Field(type = FieldType.Double, name = "reward_attribute_quantity_value")
  private Set<Double> rewardAttrQuantityValue;

  @JsonProperty("reward_attribute_discount_type")
  @Field(type = FieldType.Keyword, name = "reward_attribute_discount_type")
  private Set<PromotionPayloadEnums.DiscountTypeEnum> rewardAttrDiscountType;

  @JsonProperty("reward_attribute_discount_on")
  @Field(type = FieldType.Keyword, name = "reward_attribute_discount_on")
  private Set<PromotionPayloadEnums.DiscountOnEnum> rewardAttrDiscountOn;

  @JsonProperty("reward_attribute_discount_value")
  @Field(type = FieldType.Double, name = "reward_attribute_discount_value")
  private Set<Double> rewardAttrDiscountValue;

  @JsonProperty("raw_offer")
  @Field(type = FieldType.Text, name = "raw_offer")
  private String rawOffer;

  @JsonProperty("raw_offer_forecast")
  @Field(type = FieldType.Text, name = "raw_offer_forecast")
  private String rawOfferForcast;

  @JsonProperty("raw_offer_sales")
  @Field(type = FieldType.Text, name = "raw_offer_sales")
  private String rawOfferSales;

  @JsonProperty("featured_items")
  @Field(type = FieldType.Keyword, name = "featured_items")
  private List<FeaturedItemEntity> featuredItems;

  @JsonProperty("version")
  @Field(type = FieldType.Keyword, name = "version")
  private Integer version;

  @JsonProperty("top_offer")
  @Field(type = FieldType.Boolean, name = "top_offer")
  private Boolean topOffer;

  @JsonProperty("door_buster")
  @Field(type = FieldType.Boolean, name = "door_buster")
  private Boolean doorBuster;

  @JsonProperty("source_system")
  @Field(type = FieldType.Keyword, name = "source_system")
  private String sourceSystem;

  @JsonProperty("promotion_roi")
  @Field(type = FieldType.Keyword, name = "promotion_roi")
  private BigDecimal promotionROI;

  @JsonProperty("promoted_margin_with_funding")
  @Field(type = FieldType.Keyword, name = "promoted_margin_with_funding")
  private Double promotedMarginWithFunding;

  @JsonProperty("switching_adjusted_incremental_margin")
  @Field(type = FieldType.Keyword, name = "switching_adjusted_incremental_margin")
  private BigDecimal switchingAdjustedIncrementalMargin;

  @JsonProperty("promoted_sales")
  @Field(type = FieldType.Keyword, name = "promoted_sales")
  private Double promotedSales;

  @JsonProperty("switching_adjusted_incremental_sales")
  @Field(type = FieldType.Keyword, name = "switching_adjusted_incremental_sales")
  private Double switchingAdjustedIncrementalSales;

  @JsonProperty("promoted_volume")
  @Field(type = FieldType.Keyword, name = "promoted_volume")
  private Double promotedVolume;

  @JsonProperty("switching_adjusted_incremental_volume")
  @Field(type = FieldType.Keyword, name = "switching_adjusted_incremental_volume")
  private Double switchingAdjustedIncrementalVolume;

  @JsonProperty("total_promotion_funding_per_unit")
  @Field(type = FieldType.Keyword, name = "total_promotion_funding_per_unit")
  private BigDecimal totalPromotionFundingPerUnit;

  @JsonProperty("total_funding_capped")
  @Field(type = FieldType.Keyword, name = "total_funding_capped")
  private Double totalFundingCapped;

  @JsonProperty("group_id")
  @Field(type = FieldType.Keyword, name = "group_id")
  private String groupId;

  @JsonProperty("group_name")
  @Field(type = FieldType.Text, name = "group_name")
  private String groupName;

  @JsonProperty("net_coupon_expense")
  @Field(type = FieldType.Keyword, name = "net_coupon_expense")
  private Double netCouponExpense;

  @JsonProperty("discount_percent")
  @Field(type = FieldType.Double, name = "discount_percent")
  private BigDecimal discountPercent;

  @JsonProperty("percent_upLift_units")
  @Field(type = FieldType.Double, name = "percent_upLift_units")
  private BigDecimal percentUpLiftUnits;

  @JsonProperty("percent_upLift_sales")
  @Field(type = FieldType.Double, name = "percent_upLift_sales")
  private BigDecimal percentUpLiftSales;

  @JsonProperty("percent_uplift_margin_with_funding")
  @Field(type = FieldType.Double, name = "percent_uplift_margin_with_funding")
  private BigDecimal percentUpliftMarginWithFunding;

  @JsonProperty("funding_gap_per_unit")
  @Field(type = FieldType.Double, name = "funding_gap_per_unit")
  private Double fundingGapPerUnit;

  @JsonProperty("funding_gap_pct")
  @Field(type = FieldType.Double, name = "funding_gap_pct")
  private BigDecimal fundingGapPct;

  @JsonProperty("total_funding_gap")
  @Field(type = FieldType.Double, name = "total_funding_gap")
  private Double totalFundingGap;

  @JsonProperty("percent_uplift_sales_with_halo")
  @Field(type = FieldType.Double, name = "percent_uplift_sales_with_halo")
  private BigDecimal percentUpliftSalesWithHalo;

  @JsonProperty("percent_uplift_margin_with_halo")
  @Field(type = FieldType.Double, name = "percent_uplift_margin_with_halo")
  private BigDecimal percentUpliftMarginWithHalo;

  @JsonProperty("accuracy_indicator")
  @Field(type = FieldType.Keyword, name = "accuracy_indicator")
  private String accuracyIndicator;

  @JsonProperty("is_approved_and_locked")
  @Field(type = FieldType.Boolean, name = "is_approved_and_locked")
  private Boolean isApprovedAndLocked;

  @JsonProperty("sales_roi")
  @Field(type = FieldType.Double, name = "sales_roi")
  private BigDecimal salesROI;

  @JsonProperty("sales")
  @Field(type = FieldType.Double, name = "sales")
  private BigDecimal sales;

  @JsonProperty("inc_sales")
  @Field(type = FieldType.Double, name = "inc_sales")
  private BigDecimal incSales;

  @JsonProperty("sales_units")
  @Field(type = FieldType.Double, name = "sales_units")
  private BigDecimal salesUnits;

  @JsonProperty("sales_inc_units")
  @Field(type = FieldType.Double, name = "sales_inc_units")
  private BigDecimal salesIncUnits;

  @JsonProperty("sales_margin")
  @Field(type = FieldType.Double, name = "sales_margin")
  private BigDecimal salesMargin;

  @JsonProperty("sales_inc_margin")
  @Field(type = FieldType.Double, name = "sales_inc_margin")
  private BigDecimal salesIncMargin;

  @JsonProperty("has_error")
  @Field(type = FieldType.Boolean, name = "has_error")
  private Boolean hasError;

  @JsonProperty("has_warning")
  @Field(type = FieldType.Boolean, name = "has_warning")
  private Boolean hasWarning;

  @JsonProperty("enriched_status")
  @Field(type = FieldType.Keyword, name = "enriched_status")
  private String enrichedStatus;

  @JsonProperty("previous_status")
  @Field(type = FieldType.Keyword, name = "previous_status")
  private String previousStatus;

  @JsonProperty("top_offer_promo_weeks")
  @Field(type = FieldType.Keyword, name = "top_offer_promo_weeks")
  private List<String> topOfferPromoWeeks;

  @JsonProperty("top_offer_fiscal_quarters")
  @Field(type = FieldType.Keyword, name = "top_offer_fiscal_quarters")
  private List<String> topOfferFiscalQuarters;

  @JsonProperty("amplification_channel")
  @Field(type = FieldType.Keyword, name = "amplification_channel")
  private String amplificationChannel;

  @JsonProperty("patches_count")
  @Field(type = FieldType.Integer, name = "patches_count")
  private Integer patchesCount;

  @JsonProperty("featured_items_count")
  @Field(type = FieldType.Integer, name = "featured_items_count")
  private Integer featuredItemsCount;

}





