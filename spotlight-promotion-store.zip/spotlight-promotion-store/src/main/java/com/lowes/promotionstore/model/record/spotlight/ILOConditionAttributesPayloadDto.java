package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;


@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record ILOConditionAttributesPayloadDto(
    String validationRequestId,
    String catalogRef,
    PromotionPayloadEnums.DiscountTypeEnum discountType,
    Boolean mixAndMatch,
    PromotionPayloadEnums.PurchaseMode purchaseMode,
    PromotionPayloadEnums.UnitEnum unit,
    Double value,
    Boolean xOrMore,
    String programType
) {

}
