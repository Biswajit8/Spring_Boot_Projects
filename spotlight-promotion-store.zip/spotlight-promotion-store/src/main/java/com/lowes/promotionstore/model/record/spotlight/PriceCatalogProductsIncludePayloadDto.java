package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@SuppressWarnings("java:S1068")
@JsonInclude(JsonInclude.Include.NON_NULL)
public record PriceCatalogProductsIncludePayloadDto(
    List<PriceCatalogItemDetailPayloadDto> itemDetails,
    String productType,
    String priceCatalogType
) {

}
