package com.lowes.promotionstore.configuration.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "application.rest")
@Data
public class AppRestProperties {

  private CoreData coreData;
  private SpotlightApi spotlightApi;

  @Data
  public static class CoreData {

    private String domain;
    private CoreDataPath path;
  }

  @Data
  public static class CoreDataPath {

    private String getExternalItemCatalogue;
    private String calendar;
  }

  @Data
  public static class SpotlightApi {

    private String domain;
    private SpotlightApiPath path;
  }

  @Data
  public static class SpotlightApiPath {

    private String getExternalItemCatalogue;
  }
}
