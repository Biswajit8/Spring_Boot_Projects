package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonInclude;

@SuppressWarnings("java:S1068")
@JsonInclude(JsonInclude.Include.NON_NULL)
public record PriceCatalogItemDetailPayloadDto(
    String id,
    String itemDesc,
    String itemNo,
    String modelNo,
    String vendorNo,
    PriceCatalogItemLocationsPayloadDto locations,
    String value,
    boolean isoFlag,
    String futureBasePrice,
    String ecpPrice,
    String pmap,
    String housePromo,
    String inOutCart,
    String onlineNowPrice,
    String storePrice
) {

}
