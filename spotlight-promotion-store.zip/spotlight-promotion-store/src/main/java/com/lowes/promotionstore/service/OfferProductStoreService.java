package com.lowes.promotionstore.service;

import com.lowes.model.generated.OfferProductDto;
import com.lowes.promotionstore.component.MicrometerEventRegister;
import com.lowes.promotionstore.component.OfferProductMapper;
import com.lowes.promotionstore.configuration.KafkaConsumerToggleConfig;
import com.lowes.promotionstore.entity.offerproductstore.OfferProductStore;
import com.lowes.promotionstore.exception.constants.ErrorEnums;
import com.lowes.promotionstore.exception.types.custom.SpotlightApplicationException;
import com.lowes.promotionstore.model.record.micrometer.RegistryEvent;
import com.lowes.promotionstore.repository.dao.OfferProductStoreESDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.StreamSupport;

import static com.lowes.promotionstore.constants.ApplicationConstants.FULL_LOAD_TYPE;
import static com.lowes.promotionstore.constants.ApplicationConstants.MESSAGE_TYPE;
import static com.lowes.promotionstore.exception.constants.ErrorEnums.ErrorCodeEnum.SERIALIZATION_ERROR;

@Component
@Slf4j
@RequiredArgsConstructor
public class OfferProductStoreService {

  private final MicrometerEventRegister registryService;
  private final OfferProductStoreESDao offerProductStoreESDao;
  private final OfferProductMapper offerProductMapper;
  private final KafkaConsumerToggleConfig kafkaConsumerToggleConfig;

  public void process(ConsumerRecords<String, OfferProductDto> consumerRecords, String topic) {
    String registryEventName = "kafka_offer_product_consumer_process_failure";
    try {

      Map<Boolean, Set<OfferProductDto>> partitionedRecords = partitionRecords(consumerRecords);
      Set<OfferProductDto> fullLoadRecords = partitionedRecords.get(true);
      Set<OfferProductDto> deltaRecords = partitionedRecords.get(false);

      List<OfferProductStore> deltaEntities = offerProductMapper.createItemEntities(deltaRecords);

      List<OfferProductStore> allEntities = new ArrayList<>(deltaEntities);
      if (!fullLoadRecords.isEmpty() && isFullLoadProcessingEnabled()) {
        List<OfferProductStore> fullLoadEntities = offerProductMapper.createItemEntities(
            fullLoadRecords);
        allEntities.addAll(fullLoadEntities);
      }
      offerProductStoreESDao.saveOfferProductStoreDetails(allEntities);
    } catch (SpotlightApplicationException e) {
      if (e.getErrorCode() == SERIALIZATION_ERROR) {
        log.error("Parsing Exception: {}", e.getMessage(), e);
        registryService.incrementCounter(RegistryEvent.builder()
            .event(registryEventName)
            .source(topic)
            .message(ErrorEnums.ErrorCodeEnum.PARSING_FAILURE.getMessage())
            .build());
      }
    } catch (Exception e) {
      log.error("Exception: {}", e.getMessage(), e);
      registryService.incrementCounter(RegistryEvent.builder()
          .event(registryEventName)
          .source(topic)
          .message(ErrorEnums.ErrorCodeEnum.PROCESSING_FAILURE.getMessage())
          .build());
    }
  }

  private boolean isFullLoadProcessingEnabled() {
    return kafkaConsumerToggleConfig.isEnableOfferProductConsumer();
  }

  private Map<Boolean, Set<OfferProductDto>> partitionRecords(
      ConsumerRecords<String, OfferProductDto> records) {
    Map<Boolean, Set<OfferProductDto>> result = new HashMap<>();
    Set<OfferProductDto> fullLoadRecords = new HashSet<>();
    Set<OfferProductDto> deltaRecords = new HashSet<>();

    StreamSupport.stream(records.spliterator(), false)
        .forEach(consumerRecord -> {
          boolean isFullLoadRecord = isFullLoadRecord(consumerRecord);
          if (isFullLoadRecord) {
            fullLoadRecords.add(consumerRecord.value());
          } else {
            deltaRecords.add(consumerRecord.value());
          }
        });

    result.put(Boolean.TRUE, fullLoadRecords);
    result.put(Boolean.FALSE, deltaRecords);
    return result;
  }

  private boolean isFullLoadRecord(ConsumerRecord<String, OfferProductDto> consumerRecord) {
    return Arrays.stream(consumerRecord.headers().toArray())
        .anyMatch(header ->
            MESSAGE_TYPE.equals(header.key()) &&
                Arrays.equals(FULL_LOAD_TYPE.getBytes(), header.value())
        );
  }

}
