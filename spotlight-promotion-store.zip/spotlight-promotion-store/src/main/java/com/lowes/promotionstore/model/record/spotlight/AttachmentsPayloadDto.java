package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public record AttachmentsPayloadDto(
    String documentId,
    String documentName
) {

}
