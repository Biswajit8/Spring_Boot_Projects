package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonInclude;

@SuppressWarnings("java:S1068")
@JsonInclude(JsonInclude.Include.NON_NULL)
public record PriceCatalogProductsPayloadDto(
    PriceCatalogProductsIncludePayloadDto include
) {

}
