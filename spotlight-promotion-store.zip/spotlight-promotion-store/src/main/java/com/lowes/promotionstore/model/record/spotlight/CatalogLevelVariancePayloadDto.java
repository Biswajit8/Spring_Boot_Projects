package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record CatalogLevelVariancePayloadDto(
    String catalogId,
    String catalogType,
    String catalogProductType,
    List<CatalogLevelVarianceValuePayloadDto> catalogLevelVarianceValues
) {

}

