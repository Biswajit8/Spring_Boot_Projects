package com.lowes.promotionstore.repository.dao;

import com.lowes.promotionstore.entity.amplification.PageBlockState;
import com.lowes.promotionstore.entity.amplification.PageEntity;
import com.lowes.promotionstore.entity.amplification.PagePayloadJson;
import com.lowes.promotionstore.model.record.feedback.BlockPayloadDto;
import com.lowes.promotionstore.model.record.feedback.OfferEventPayloadDto;
import com.lowes.promotionstore.model.record.feedback.PagePayloadDto;
import com.lowes.promotionstore.repository.postgres.PageRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class PageDao {

  private final PageRepository pageRepository;

  @Transactional
  public void upsertPage(OfferEventPayloadDto payloadDto) {
    if (payloadDto.getPage() == null) {
      log.debug("No page to upsert (page or page.id is null) for payload: {}", payloadDto);
      return;
    }
    String pageId = req(payloadDto.getPage().getId());
    PagePayloadDto page = payloadDto.getPage();

    PagePayloadJson pageJson = Objects.nonNull(page)
        ? PagePayloadJson.builder()
        .id(page.getId())
        .alias(page.getAlias())
        .type(page.getType())
        .number(page.getNumber())
        .build()
        : null;

    PageEntity entity = PageEntity.builder()
        .pageId(pageId)
        .activityId(payloadDto.getActivity().getId())
        .payload(pageJson)
        .status(PageBlockState.ADDED)
        .build();

    pageRepository.save(entity);
    log.info("page.create and pageId={}", pageId);
  }

  public int updatePageStatus(String activityId, PageBlockState status) {
    return pageRepository.updateStatusByActivityId(activityId, status);
  }

  // -------- helpers --------
  private static <T> T req(T v) {
    if (v == null) {
      throw new IllegalArgumentException("Required value is null");
    }
    return v;
  }

  public void updatePageAttributes(PagePayloadDto page) {
    String pageId = req(page.getId());
    log.info("page.update and pageId={}", pageId);

    PageEntity entity = pageRepository.findById(pageId)
        .orElseThrow(() -> new IllegalStateException("Page not found for id=" + pageId));

    PagePayloadJson pageJson = Optional.ofNullable(entity.getPayload())
        .orElse(new PagePayloadJson());
    pageJson.setType(page.getType());
    pageJson.setNumber(page.getNumber());

    entity.setPayload(pageJson);
    entity.setStatus(PageBlockState.UPDATED);
    pageRepository.save(entity);
    log.info("page json updated with page={}", pageId);
  }

  public void markPageStatusDeleted(PagePayloadDto page) {
    String pageId = req(page.getId());
    log.info("page.delete and pageId={}", pageId);

    pageRepository.findById(pageId)
        .ifPresent(entity -> {
          PageBlockState currentStatus = entity.getStatus();
          if (currentStatus == PageBlockState.ADDED || currentStatus == PageBlockState.UPDATED) {
            entity.setStatus(PageBlockState.DELETED);
            pageRepository.save(entity);
            log.info("page marked as DELETED for pageId={}", pageId);
          } else {
            log.warn("page not marked as DELETED - current status is {} for pageId={}",
                currentStatus, pageId);
          }
        });
  }
}
