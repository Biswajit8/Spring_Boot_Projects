package com.lowes.promotionstore.entity.spotlight;


public class SalesEnums {

  public enum ForecastSearchEnum {
    raw_offer_forecast,
    promotion_roi,
    promoted_margin_with_funding,
    switching_adjusted_incremental_margin,
    promoted_sales,
    switching_adjusted_incremental_sales,
    promoted_volume,
    switching_adjusted_incremental_volume,
    total_promotion_funding_per_unit,
    total_funding_capped,
    funding_gap_pct,
    funding_gap_per_unit,
    accuracy_indicator,
    net_coupon_expense,
    discount_percent,
    percent_upLift_sales,
    percent_uplift_margin_with_funding,
    total_funding_gap,
    percent_uplift_sales_with_halo,
    percent_uplift_margin_with_halo
  }

  public enum SalesSearchEnum {
    raw_offer_sales,
    sales_roi,
    sales,
    inc_sales,
    sales_units,
    sales_inc_units,
    sales_margin,
    sales_inc_margin;

  }
}
