package com.lowes.promotionstore.repository.dao;

import com.lowes.promotionstore.entity.offerproductstore.OfferProductStore;
import com.lowes.promotionstore.repository.es.OfferProductStoreRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
@AllArgsConstructor
public class OfferProductStoreESDao {

  private final OfferProductStoreRepository offerProductStoreRepository;

  public void saveOfferProductStoreDetails(List<OfferProductStore> offerProductEntities) {
    if (offerProductEntities != null) {
      offerProductStoreRepository.saveAll(offerProductEntities);
      log.info("OfferProductStoreRepository save success : " + offerProductEntities.size());
    } else {
      log.error("not able to save promotionStore ");
    }
  }
}
