package com.lowes.promotionstore.configuration;

import io.micrometer.observation.ObservationRegistry;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;
import io.netty.handler.ssl.util.InsecureTrustManagerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import javax.net.ssl.SSLException;


@Configuration
public class WebClientConfiguration {

  @SuppressWarnings("unused")
  @Bean
  @ConditionalOnProperty(name = "application.startInLocal", havingValue = "true")
  public WebClient webClientLocal(ObservationRegistry observationRegistry) throws SSLException {
    SslContext sslContext = SslContextBuilder.forClient().trustManager(
        InsecureTrustManagerFactory.INSTANCE).build();

    HttpClient httpClient = HttpClient.create().secure(t -> t.sslContext(sslContext));
    return WebClient.builder()
        .codecs(
            clientCodecConfigurer ->
                clientCodecConfigurer.defaultCodecs().maxInMemorySize(10 * 1024 * 1024))
        .clientConnector(new ReactorClientHttpConnector(httpClient))
        .observationRegistry(observationRegistry)
        .build();
  }

  @SuppressWarnings("unused")
  @Bean
  @ConditionalOnProperty(name = "application.startInLocal", havingValue = "false")
  public WebClient webClient(ObservationRegistry observationRegistry) {
    return WebClient.builder()
        .codecs(
            clientCodecConfigurer ->
                clientCodecConfigurer.defaultCodecs().maxInMemorySize(10 * 1024 * 1024))
        .observationRegistry(observationRegistry)
        .build();
  }

}
