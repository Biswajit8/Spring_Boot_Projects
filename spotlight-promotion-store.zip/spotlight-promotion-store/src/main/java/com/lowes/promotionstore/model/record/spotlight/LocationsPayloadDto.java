package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record LocationsPayloadDto(boolean includeAllStores, List<String> stores, List<String> patches) {

  public LocationsPayloadDto {
    if (CollectionUtils.isEmpty(stores)) {
      stores = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(patches)) {
      patches = new ArrayList<>();
    }
  }
}
