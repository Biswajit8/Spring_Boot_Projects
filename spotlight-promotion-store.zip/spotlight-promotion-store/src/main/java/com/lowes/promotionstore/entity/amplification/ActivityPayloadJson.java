package com.lowes.promotionstore.entity.amplification;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ActivityPayloadJson {

  // context/meta
  private String channel;            // optional, from inbound
  private String eventType;          // "ACTIVITY"
  private String activityOperation;  // "CREATE"/"UPDATE"

  // activity body (no campaigns here)
  private String alias;
  private String name;
  private String status;
  private LocalDateTime startDate;
  private LocalDateTime endDate;
  private List<String> customers;
  private List<String> distribution;
}

