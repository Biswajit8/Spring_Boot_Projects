package com.lowes.promotionstore.model.record.spotlight.enums;

import lombok.Getter;

public class PromotionPayloadEnums {

  public enum SourceSystemEnum {
    SPOTLIGHT, PROCISION
  }

  public enum AmplificationSignal {
    TAB
  }

  public enum MarketScopeEnum {
    STORE, ONLINE, OMNI
  }

  public enum CustomerEnum {
    REGULAR, DIY, PRO, EMPLOYEE, MILITARY, ALL
  }

  @Getter
  public enum VendorFundingCalculationBasis {
    FIXED_AMOUNT("Fixed Amount"),
    PER_UNIT_DOLLAR("Per Unit $"),
    PER_OF_COST("% of Cost"),
    PER_OF_RETAIL("% of Retail"),
    ;

    private final String value;

    VendorFundingCalculationBasis(String value) {
      this.value = value;
    }
  }

  public enum RedemptionTypeEnum {

    INSTANT("Instant"),
    COUPON("Coupon"),
    AUTO_APPLY_CODE("Auto Apply Code");

    private final String value;

    RedemptionTypeEnum(String value) {
      this.value = value;
    }

    public static RedemptionTypeEnum fromValue(String value) {
      for (RedemptionTypeEnum redemptionTypeEnum : RedemptionTypeEnum.values()) {
        if (redemptionTypeEnum.getValue().equalsIgnoreCase(value)) {
          return redemptionTypeEnum;
        }
      }
      throw new IllegalArgumentException("Invalid RedemptionTypeEnum value: " + value);
    }

    public String getValue() {
      return value;
    }
  }

  public enum UnitEnum {
    QUANTITY, SPEND
  }

  public enum ItemsInputTypeEnum {
    COPYPASTE, UPLOAD, CATEGORYSELECTION, MERCH_BUCKET, DIGITAL_TAXONOMY, PCR, BRAND
  }

  public enum PaymentModes {
    LAR("Lowe's Account Receivable"),
    LBA("Lowe's Business Account"),
    LBR("Lowe's Business Rewards"),
    LCC("Lowe's Credit Card");

    private final String value;

    PaymentModes(String value) {
      this.value = value;
    }

    public String getValue() {
      return value;
    }
  }

  public enum ConditionTypeEnum {
    CATALOG_ITEMS, SHIPPING, CATALOG_ITEMS_ILO, CATALOG_ITEMS_NDO
  }

  public enum ConditionOnEnum {
    ENTIRE_CART, SPECIFIC_ITEMS, ENTIRE_CART_PAYMENT, SPECIFIC_ITEMS_ILO, SPECIFIC_ITEM_PAYMENT, SPECIFIC_ITEMS_NDO
  }

  public enum RewardTypeEnum {
    CATALOG_ITEMS, SHIPPING, FINANCE
  }

  public enum PurchaseMode {
    ONE_TIME, SUBSCRIPTION
  }

  public enum RewardOnEnum {
    ENTIRE_CART, SPECIFIC_ITEMS, ITEMS_ON_CONDITION, SPECIFIC_ITEMS_CHOICE
  }

  public enum StatusEnum {
    INPROGRESS,
    COMPLETE,
    DELETED,
    PROPOSED,
    CANCELLED
  }

  public enum RewardQuantityEnum {
    ALL_QUANTITY, SPECIFIC_QUANTITY
  }

  @Getter
  public enum DiscountTypeEnum {
    PERCENTAGE_OFF("% Off"),
    AMOUNT_OFF("$ Off"),
    FIXED_PRICE("Fixed Price"),
    FREE("Free");

    private final String value;

    DiscountTypeEnum(String value) {
      this.value = value;
    }
  }

  public enum DiscountOnEnum {
    ALL_UNITS, EACH_UNIT
  }

  public enum ExecutionMessageTypeEnum {
    REGULAR, EMERGENCY
  }

  public enum ProductTypeEnum {
    ITEM, BRAND, PCR, PRODUCT_GROUP, ASSORTMENT, MERCH_BUCKET, DIGITAL_TAXONOMY, UPLOAD, ALL_LOWES_ITEMS
  }

  public enum FinanceTypeEnum {
    SPECIAL, PROJECT
  }

  public enum OfferTypeEnum {
    DISCOUNTED_PRICING("Discounted Pricing"), PRO_SAVINGS("PRO Savings"), CREDIT("Credit");

    private final String value;

    OfferTypeEnum(String value) {
      this.value = value;
    }

    public String getOfferTypeName() {
      return value;
    }
  }

  public enum OfferSubTypeEnum {
    CLEARANCE("Clearance"), BULK_SAVINGS("Bulk Savings"), CREDIT_DISCOUNT(
        "Credit Discount"), FINANCE_OFFER("Finance Offer");
    private final String value;

    OfferSubTypeEnum(String value) {
      this.value = value;
    }

    public String getOfferSubTypeEnum() {
      return value;
    }
  }

  public enum ScheduleTypeEnum {
    OFFER_DURATION, PROMO_WEEK, FISCAL_QUARTERS
  }

}
