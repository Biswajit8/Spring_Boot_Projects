package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.VendorFundingCalculationBasis;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public record FundingCalcPayloadDto(
    VendorFundingCalculationBasis basis,
    Double amt,
    Double maxAmt,
    List<String> tieredFundingAmounts
) {

}
