package com.lowes.promotionstore.model.record.micrometer;

import lombok.Builder;
import lombok.Getter;

@Builder
@Getter
public class RegistryEvent {

  private String source;
  private String event;
  private String message;

}
