package com.lowes.promotionstore.listener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Component
public class SpotlightOfferPayloadDtoDeserializer
    implements org.apache.kafka.common.serialization.Deserializer<SpotlightOfferPayloadDto> {

  private final ObjectMapper mapper;

  public SpotlightOfferPayloadDtoDeserializer() {
    mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.configOverride(LocalDateTime.class)
        .setFormat(JsonFormat.Value.forPattern("yyyy-MM-dd HH:mm:ss"));
    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  }

  @Override
  public SpotlightOfferPayloadDto deserialize(String topic, byte[] data) {
    if (data == null) {
      return null;
    }
    try {
      return mapper.readValue(data, SpotlightOfferPayloadDto.class);
    } catch (Exception e) {
      throw new org.apache.kafka.common.errors.SerializationException(
          "Failed to deserialize SpotlightOfferPayloadDto", e);
    }
  }
}

