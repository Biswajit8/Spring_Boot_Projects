package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record CustomerPayloadDto(PromotionPayloadEnums.CustomerEnum customerType,
                                 List<LoyaltyPayloadDto> loyalties, SegmentPayloadDto segment) {

  public CustomerPayloadDto {
    if (CollectionUtils.isEmpty(loyalties)) {
      loyalties = new ArrayList<>();
    }
  }
}
