package com.lowes.promotionstore.model.record.spotlight;

public record LabelInfoResponse(Boolean labelEligible, Integer labelCode, String labelType){ }
