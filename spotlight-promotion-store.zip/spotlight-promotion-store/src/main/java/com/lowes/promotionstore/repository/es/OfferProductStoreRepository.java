package com.lowes.promotionstore.repository.es;

import com.lowes.promotionstore.entity.offerproductstore.OfferProductStore;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

public interface OfferProductStoreRepository extends
    ElasticsearchRepository<OfferProductStore, String> {

}
