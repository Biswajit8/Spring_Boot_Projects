package com.lowes.promotionstore.configuration.async;

import org.slf4j.MDC;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;

@Component
public class MdcAwareExecutor extends ThreadPoolTaskExecutor {

  @Override
  public void execute(Runnable task) {
    // Get the MDC context from the parent thread
    final var contextMap = MDC.getCopyOfContextMap();

    // Wrap the task in a new Runnable that sets the MDC context for the child thread
    super.execute(() -> {
      if (contextMap != null) {
        MDC.setContextMap(contextMap);
      }
      task.run();
    });
  }
}
