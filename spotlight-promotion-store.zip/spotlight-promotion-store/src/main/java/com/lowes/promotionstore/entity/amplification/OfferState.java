package com.lowes.promotionstore.entity.amplification;

public enum OfferState {
  ADDED, DELETED
}