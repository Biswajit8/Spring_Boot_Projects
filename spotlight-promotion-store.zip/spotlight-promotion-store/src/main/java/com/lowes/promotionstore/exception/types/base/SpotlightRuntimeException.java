package com.lowes.promotionstore.exception.types.base;

import com.lowes.promotionstore.exception.constants.ErrorEnums;
import com.lowes.promotionstore.exception.types.custom.SpotlightApplicationException;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import java.sql.Timestamp;

/**
 * Base RuntimeException class for this application. This exception should not be directly used in
 * the code. Use custom exception classes in the package
 * {@link com.lowes.promotionstore.exception.types.custom}.
 * <p>
 * Usage of Custom Exception Classes is made mandatory to support alerts on exception classes in
 * Grafana. Create new custom types cautiously.
 * <p>
 * For example, use {@link SpotlightApplicationException} for all exceptions that get generated
 * within Service classes. Use
 * {@link SpotlightRuntimeException#errorCode} to
 * categorize exceptions. This value can be fetched from logs.
 * <p>
 * Refer documentation on each class to know more details.
 */

@SuppressWarnings("unused")
@Getter
@Setter
public abstract class SpotlightRuntimeException extends RuntimeException {

  private final ErrorEnums.ErrorTypeEnum errorTypeEnum;
  private final ErrorEnums.ErrorCodeEnum errorCode;
  private final String errorSystem;
  private final HttpStatus exceptionHttpStatus;
  private final Timestamp createdTs;
  private final Throwable actualException;

  protected SpotlightRuntimeException(String message,
      ErrorEnums.ErrorTypeEnum errorTypeEnum,
      ErrorEnums.ErrorCodeEnum errorCode,
      String errorSystem,
      HttpStatus exceptionHttpStatus,
      Timestamp createdTs,
      Throwable actualException) {
    super(message, actualException);
    this.errorTypeEnum = errorTypeEnum;
    this.errorCode = errorCode;
    this.errorSystem = errorSystem;
    this.exceptionHttpStatus = exceptionHttpStatus;
    this.createdTs = createdTs;
    this.actualException = actualException;
  }

  protected SpotlightRuntimeException(String message,
      ErrorEnums.ErrorTypeEnum errorTypeEnum,
      ErrorEnums.ErrorCodeEnum errorCode,
      String errorSystem,
      HttpStatus exceptionHttpStatus,
      Timestamp createdTs) {
    super(message);
    this.errorTypeEnum = errorTypeEnum;
    this.errorCode = errorCode;
    this.errorSystem = errorSystem;
    this.exceptionHttpStatus = exceptionHttpStatus;
    this.createdTs = createdTs;
    this.actualException = null;
  }
}
