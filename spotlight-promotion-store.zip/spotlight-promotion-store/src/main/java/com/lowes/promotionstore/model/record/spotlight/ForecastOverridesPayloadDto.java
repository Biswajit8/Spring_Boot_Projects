package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.Set;

@SuppressWarnings("java:S1068")
@JsonInclude(JsonInclude.Include.NON_NULL)
public record ForecastOverridesPayloadDto(
    Set<CatalogOverridesPayloadDto> catalogOverrides,
    PromoOverridesPayloadDto promoOverrides
) {

}
