package com.lowes.promotionstore.configuration;


import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class SwaggerConfiguration {

  @Value("${server.port}")
  private String port;

  @Value("${application.context-path}")
  private String contextPath;

  @Bean
  public OpenAPI customOpenAPI() {

    String localHost = "http://localhost:" + port;
    String devHost = "https://internal-sadc-dev.carbon.lowes.com";
    String stageHost = "https://internal-sadc-stage.carbon.lowes.com";
    String prodWsdcHost = "https://internal-wsdc.carbon.lowes.com";
    String prodSadcHost = "https://internal-sadc.carbon.lowes.com";

    final Server localServer = new Server();
    localServer.setUrl(localHost + "/" + contextPath);

    final Server devServer = new Server();
    devServer.setUrl(devHost + "/" + contextPath);

    final Server stageServer = new Server();
    stageServer.setUrl(stageHost + "/" + contextPath);

    final Server prodWsdcServer = new Server();
    prodWsdcServer.setUrl(prodWsdcHost + "/" + contextPath);

    final Server prodSadcServer = new Server();
    prodSadcServer.setUrl(prodSadcHost + "/" + contextPath);

    return new OpenAPI().servers(
        List.of(prodWsdcServer, prodSadcServer, stageServer, devServer, localServer));
  }
}
