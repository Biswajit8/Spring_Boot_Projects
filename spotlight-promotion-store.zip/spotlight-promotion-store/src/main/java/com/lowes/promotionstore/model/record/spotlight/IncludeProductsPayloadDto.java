package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record IncludeProductsPayloadDto(PromotionPayloadEnums.ProductTypeEnum productType,
                                        List<ItemDetailsPayloadDto> itemDetails,
                                        List<KeyValuePayloadDto> brands,
                                        List<String> pcrs, List<CategoryDetailsPayloadDto> categoryDetails,
                                        List<KeyValuePayloadDto> merchBuckets,
                                        List<KeyValuePayloadDto> digitalTaxonomies) {

  public IncludeProductsPayloadDto {
    if (CollectionUtils.isEmpty(itemDetails)) {
      itemDetails = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(brands)) {
      brands = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(pcrs)) {
      pcrs = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(merchBuckets)) {
      merchBuckets = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(digitalTaxonomies)) {
      digitalTaxonomies = new ArrayList<>();
    }
  }
}
