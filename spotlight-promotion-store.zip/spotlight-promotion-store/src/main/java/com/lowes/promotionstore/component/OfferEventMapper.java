package com.lowes.promotionstore.component;

import com.lowes.generated.model.offerevent.Catalog;
import com.lowes.generated.model.offerevent.CatalogFileRef;
import com.lowes.generated.model.offerevent.CatalogOverridesDto;
import com.lowes.generated.model.offerevent.Comment;
import com.lowes.generated.model.offerevent.ConditionGroup;
import com.lowes.generated.model.offerevent.Customer;
import com.lowes.generated.model.offerevent.ForecastOverridesDto;
import com.lowes.generated.model.offerevent.ILOConditionAttributes;
import com.lowes.generated.model.offerevent.ItemAttributes;
import com.lowes.generated.model.offerevent.ItemDetails;
import com.lowes.generated.model.offerevent.ItemOverridesDto;
import com.lowes.generated.model.offerevent.LabelInfo;
import com.lowes.generated.model.offerevent.MarketingInfo;
import com.lowes.generated.model.offerevent.OfferEventPublishDto;
import com.lowes.generated.model.offerevent.OfferGroup;
import com.lowes.generated.model.offerevent.OfferIntegrationCompatibility;
import com.lowes.generated.model.offerevent.PriceCatalog;
import com.lowes.generated.model.offerevent.Products;
import com.lowes.generated.model.offerevent.PromoOverridesDto;
import com.lowes.generated.model.offerevent.PromotionMetaData;
import com.lowes.generated.model.offerevent.RebateInfo;
import com.lowes.generated.model.offerevent.RewardGroup;
import com.lowes.generated.model.offerevent.SalesProjection;
import com.lowes.generated.model.offerevent.Schedule;
import com.lowes.generated.model.offerevent.Segment;
import com.lowes.generated.model.offerevent.StackingGroup;
import com.lowes.generated.model.offerevent.Tier;
import com.lowes.generated.model.offerevent.TopOfferInfo;
import com.lowes.generated.model.offerevent.VendorFundingInfo;
import com.lowes.generated.model.offerevent.VersionChangesDto;
import com.lowes.generated.model.offerevent.pricecatalog.PriceCatalogItemDetail;
import com.lowes.generated.model.offerevent.pricecatalog.PriceCatalogProductsInclude;
import com.lowes.promotionstore.model.record.spotlight.AlertsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.AttachmentsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.CatalogFileRefPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.CatalogLevelVariancePayloadDto;
import com.lowes.promotionstore.model.record.spotlight.CatalogLevelVarianceValuePayloadDto;
import com.lowes.promotionstore.model.record.spotlight.CatalogOverridesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.CatalogPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.CategoryDetailsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.CommentsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ConditionGroupPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.CustomerPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ExcludeProductsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.FeatureCatalogItemPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.FeatureItemDetailPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.FinanceAttributesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ForecastOverridesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.FundingCalcPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.FundingDetailsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ILOConditionAttributesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.IncludeProductsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ItemAttributesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ItemDetailsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ItemOverridesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.KeyValuePayloadDto;
import com.lowes.promotionstore.model.record.spotlight.LabelInfoResponse;
import com.lowes.promotionstore.model.record.spotlight.LocationsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.LoyaltyPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.MarketingInfoPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.MerchantSignerPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.OfferGroupDetailsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.OfferIntegrationCompatibilityPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.PriceCatalogItemDetailPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.PriceCatalogItemLocationsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.PriceCatalogProductsIncludePayloadDto;
import com.lowes.promotionstore.model.record.spotlight.PriceCatalogProductsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ProductsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ProgramTierPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.PromoOverridesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.PromotionMetaDataPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.RebateInfoPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.RewardAttributesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.RewardGroupPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.RewardItemAttributesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.SalesProjectionPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.SchedulePayloadDto;
import com.lowes.promotionstore.model.record.spotlight.SegmentPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ShippingAttributesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ShippingTypeFieldsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.SignersPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.StackingGroupPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.TierPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.TopOfferInfoPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.VendorContactPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.VendorFundingInfoPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.VersionChangesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Mapper component for converting OfferEventPublishDto to SpotlightOfferPayloadDto.
 *
 * <p>This component handles the transformation of offer event data from the source format
 * to the spotlight promotion store format. It provides comprehensive null safety and organized
 * mapping logic for different aspects of offer data.</p>
 *
 * <p>Key features:</p>
 * <ul>
 *   <li>Null-safe mapping with comprehensive error handling</li>
 *   <li>Organized mapping logic grouped by functional areas</li>
 *   <li>Memory-efficient processing with proper resource management</li>
 *   <li>Extensive logging for debugging and monitoring</li>
 * </ul>
 *
 * @author Spotlight Promotion Store Team
 * @since 1.0
 */
@Slf4j
@Component
public class OfferEventMapper {

  // ========= Public API =========

  /**
   * Converts an OfferEventPublishDto to SpotlightOfferPayloadDto.
   *
   * <p>This is the main entry point for mapping offer events. The method breaks down
   * the complex mapping into logical groups for better maintainability and readability.</p>
   *
   * @param dto the source offer event data, may be null
   * @return the mapped spotlight offer payload, or null if input is null
   */
  public SpotlightOfferPayloadDto toSpotlightOffer(OfferEventPublishDto dto) {
    if (dto == null) {
      return null;
    }

    log.info("Converting record to spotlight: {}", dto);

    // Basic offer information
    OfferBasicInfo basicInfo = mapBasicOfferInfo(dto);

    // Timing and status information
    OfferTimingInfo timingInfo = mapTimingInfo(dto);

    // Business rules and constraints
    OfferBusinessRules businessRules = mapBusinessRules(dto);

    // Marketing and promotional details
    OfferMarketingInfo marketingInfo = mapMarketingDetails(dto);

    // System and metadata
    OfferSystemInfo systemInfo = mapSystemInfo(dto);

    return getSpotlightOfferPayloadDto(basicInfo, timingInfo, businessRules, marketingInfo,
        systemInfo);
  }

  private static SpotlightOfferPayloadDto getSpotlightOfferPayloadDto(OfferBasicInfo basicInfo,
      OfferTimingInfo timingInfo, OfferBusinessRules businessRules,
      OfferMarketingInfo marketingInfo, OfferSystemInfo systemInfo) {
    return new SpotlightOfferPayloadDto(
        // Basic Information
        basicInfo.id(),
        basicInfo.offerTypeId(),
        basicInfo.metaData(),
        basicInfo.name(),
        basicInfo.offerType(),
        basicInfo.offerTypeName(),
        basicInfo.offerSubType(),
        basicInfo.offerSubTypeName(),
        basicInfo.shortDescription(),

        // Timing & Schedule
        timingInfo.schedule(),
        basicInfo.marketScope(),
        timingInfo.locations(),
        timingInfo.customer(),
        timingInfo.redemptionType(),

        // Codes & Status
        basicInfo.couponCode(),
        basicInfo.autoApplyCode(),
        timingInfo.status(),

        // Structure & Catalog
        businessRules.tiers(),
        businessRules.catalogs(),
        marketingInfo.marketingInfo(),

        // Timestamps
        timingInfo.createdTs(),
        timingInfo.createdBy(),
        timingInfo.modifiedTs(),
        timingInfo.modifiedBy(),
        timingInfo.activatedTs(),
        timingInfo.activatedBy(),

        // Flags & Counters
        basicInfo.active(),
        basicInfo.version(),
        0, // activeCounter - not in DTO
        timingInfo.deactivatedTs(),
        timingInfo.deactivatedBy(),

        // Terms & Conditions
        basicInfo.termsAndConditions(),
        systemInfo.sourceSystem() != null ? systemInfo.sourceSystem().name() : null,
        basicInfo.offerTactic(),
        systemInfo.labelInfo(),

        // Data not available in source
        null, // forecastData - not present in DTO
        null, // salesData - not present in DTO

        // Business Rules
        businessRules.offerGroup(),
        null, // blackoutDate - not present in DTO
        businessRules.isApprovedAndLocked(),
        businessRules.priceCatalog(),
        businessRules.vendorFunding(),
        businessRules.comments(),
        systemInfo.executionMessageType(),
        businessRules.stackingGroup(),

        // Status Tracking
        timingInfo.previousStatus(),
        timingInfo.enrichedStatus(),
        systemInfo.alerts(),
        systemInfo.offerIntegrationCompatibility(),
        systemInfo.amplificationChannel() != null ? systemInfo.amplificationChannel().name() : null,

        // Contact & URLs
        timingInfo.createdByEmailId(),
        timingInfo.modifiedByEmailId(),
        basicInfo.catalogUrl(),

        // Configuration Flags
        basicInfo.dualMaintenance(),
        basicInfo.editingInProgress(),
        basicInfo.signage(),

        // Override Information
        marketingInfo.forecastOverrides(),
        marketingInfo.rebateInfo(),
        systemInfo.versionChanges(),

        // Counts
        basicInfo.patchesCount(),
        basicInfo.featuredItemsCount(),
        basicInfo.derivedPatches()

    );
  }

  // ========= Basic Offer Information =========

  private record OfferBasicInfo(
      Long id, Long offerTypeId, PromotionMetaDataPayloadDto metaData, String name,
      String offerType, String offerTypeName, String offerSubType, String offerSubTypeName,
      String shortDescription, String couponCode, String autoApplyCode, Boolean active,
      int version, String termsAndConditions, String offerTactic, String catalogUrl,
      Boolean dualMaintenance, Boolean editingInProgress, Boolean signage,
      Integer patchesCount, Integer featuredItemsCount,
      PromotionPayloadEnums.MarketScopeEnum marketScope, List<String> derivedPatches
  ) {

  }

  private OfferBasicInfo mapBasicOfferInfo(OfferEventPublishDto dto) {
    return new OfferBasicInfo(
        dto.getId(),
        mapOfferTypeId(dto.getOfferTypeId()),
        mapPromotionMetaData(dto.getMetaData()),
        toString(dto.getName()),
        toString(dto.getOfferType()),
        toString(dto.getOfferTypeName()),
        toString(dto.getOfferSubType()),
        toString(dto.getOfferSubTypeName()),
        toString(dto.getShortDescription()),
        toString(dto.getCouponCode()),
        toString(dto.getAutoApplyCode()),
        dto.getActive(),
        dto.getVersion(),
        toString(dto.getTermsAndConditions()),
        toString(dto.getOfferTactic()),
        toString(dto.getCatalogUrl()),
        dto.getDualMaintenance(),
        dto.getEditingInProgress(),
        dto.getSignage(),
        dto.getPatchesCount(),
        dto.getFeaturedItemsCount(),
        mapMarketScope(dto.getMarketScope()),
        dto.getDerivedPatches()
    );
  }

  // ========= Timing and Status Information =========

  private record OfferTimingInfo(
      SchedulePayloadDto schedule, LocationsPayloadDto locations, CustomerPayloadDto customer,
      PromotionPayloadEnums.RedemptionTypeEnum redemptionType,
      PromotionPayloadEnums.StatusEnum status,
      String createdTs, String createdBy, String modifiedTs, String modifiedBy,
      String activatedTs, String activatedBy, String deactivatedTs, String deactivatedBy,
      String previousStatus, String enrichedStatus, String createdByEmailId,
      String modifiedByEmailId
  ) {

  }

  private OfferTimingInfo mapTimingInfo(OfferEventPublishDto dto) {
    return new OfferTimingInfo(
        mapSchedule(dto.getSchedule()),
        mapLocations(dto.getLocations()),
        mapCustomer(dto.getCustomer()),
        mapRedemptionType(dto.getRedemptionType()),
        mapStatus(dto.getStatus()),
        convertLocalDateTimeToString(dto.getCreatedTs()),
        toString(dto.getCreatedBy()),
        convertLocalDateTimeToString(dto.getModifiedTs()),
        toString(dto.getModifiedBy()),
        convertLocalDateTimeToString(dto.getActivatedTs()),
        toString(dto.getActivatedBy()),
        convertLocalDateTimeToString(dto.getDeactivatedTs()),
        toString(dto.getDeactivatedBy()),
        toString(dto.getPreviousStatus()),
        toString(dto.getEnrichedStatus()),
        toString(dto.getCreatedByEmailId()),
        toString(dto.getModifiedByEmailId())
    );
  }

  // ========= Business Rules and Constraints =========

  private record OfferBusinessRules(
      List<TierPayloadDto> tiers, List<CatalogPayloadDto> catalogs,
      OfferGroupDetailsPayloadDto offerGroup,
      boolean isApprovedAndLocked, PriceCatalogProductsPayloadDto priceCatalog,
      List<VendorFundingInfoPayloadDto> vendorFunding, List<CommentsPayloadDto> comments,
      StackingGroupPayloadDto stackingGroup, PromotionPayloadEnums.MarketScopeEnum marketScope
  ) {

  }

  private OfferBusinessRules mapBusinessRules(OfferEventPublishDto dto) {
    return new OfferBusinessRules(
        mapTiers(dto.getTiers()),
        mapCatalogs(dto.getCatalogs()),
        mapOfferGroup(dto.getOfferGroup()),
        Boolean.TRUE.equals(dto.getIsApprovedAndLocked()),
        mapPriceCatalog(dto.getPriceCatalog()),
        mapVendorFunding(dto.getVendorFundingInfo()),
        mapComments(dto.getComments()),
        mapStackingGroup(dto.getStackingGroup()),
        mapMarketScope(dto.getMarketScope())
    );
  }

  // ========= Marketing and Promotional Details =========

  private record OfferMarketingInfo(
      MarketingInfoPayloadDto marketingInfo, ForecastOverridesPayloadDto forecastOverrides,
      RebateInfoPayloadDto rebateInfo
  ) {

  }

  private OfferMarketingInfo mapMarketingDetails(OfferEventPublishDto dto) {
    return new OfferMarketingInfo(
        mapMarketingInfo(dto.getMarketingInfo()),
        mapForecastOverrides(dto.getForecastOverrides()),
        mapRebateInfo(dto.getRebateInfo())
    );
  }

  // ========= System and Metadata Information =========

  private record OfferSystemInfo(
      PromotionPayloadEnums.SourceSystemEnum sourceSystem, LabelInfoResponse labelInfo,
      PromotionPayloadEnums.ExecutionMessageTypeEnum executionMessageType, AlertsPayloadDto alerts,
      OfferIntegrationCompatibilityPayloadDto offerIntegrationCompatibility,
      PromotionPayloadEnums.AmplificationSignal amplificationChannel,
      VersionChangesPayloadDto versionChanges
  ) {

  }

  private OfferSystemInfo mapSystemInfo(OfferEventPublishDto dto) {
    return new OfferSystemInfo(
        mapSourceSystem(dto.getSourceSystem()),
        mapLabelInfo(dto.getLabelInfo()),
        mapExecutionMessageType(dto.getExecutionMessageType()),
        mapAlerts(dto.getAlerts()),
        mapOfferIntegrationCompatibility(dto.getOfferIntegrationCompatibility()),
        mapAmplificationChannel(dto.getAmplificationChannel()),
        mapVersionChanges(dto.getVersionChanges())
    );
  }

  /**
   * Legacy method for backward compatibility.
   *
   * @param dto the source offer event data
   * @return the mapped spotlight offer payload
   * @see #toSpotlightOffer(OfferEventPublishDto)
   */
  public SpotlightOfferPayloadDto toSpotlightOffers(OfferEventPublishDto dto) {
    return toSpotlightOffer(dto);
  }

  // ========= Helper mapping methods =========

  // ========= Basic Type Mappings =========

  /**
   * Maps offer type ID from Integer to Long.
   *
   * @param offerTypeId the offer type ID, may be null
   * @return the mapped offer type ID, or null if input is null
   */
  private Long mapOfferTypeId(Integer offerTypeId) {
    return offerTypeId == null ? null : offerTypeId.longValue();
  }

  /**
   * Maps source system enum to PromotionPayloadEnums.
   *
   * @param sourceSystem the source system enum, may be null
   * @return the PromotionPayloadEnums equivalent, or null if input is null
   */
  private PromotionPayloadEnums.SourceSystemEnum mapSourceSystem(
      com.lowes.generated.model.offerevent.SourceSystemEnum sourceSystem) {
    if (sourceSystem == null) {
      return null;
    }
    switch (sourceSystem) {
      case SPOTLIGHT:
        return PromotionPayloadEnums.SourceSystemEnum.SPOTLIGHT;
      case PROCISION:
        return PromotionPayloadEnums.SourceSystemEnum.PROCISION;
      default:
        return null;
    }
  }

  /**
   * Maps amplification channel enum to PromotionPayloadEnums.
   *
   * @param amplificationChannel the amplification channel enum, may be null
   * @return the PromotionPayloadEnums equivalent, or null if input is null
   */
  private PromotionPayloadEnums.AmplificationSignal mapAmplificationChannel(
      com.lowes.generated.model.offerevent.AmplificationSignal amplificationChannel) {
    if (amplificationChannel == null) {
      return null;
    }
    switch (amplificationChannel) {
      case TAB:
        return PromotionPayloadEnums.AmplificationSignal.TAB;
      default:
        return null;
    }
  }

  // ========= Complex Object Mappings =========

  /**
   * Maps alerts information to payload DTO.
   *
   * @param alerts the source alerts data, may be null
   * @return the mapped alerts payload, or null if input is null
   */
  private AlertsPayloadDto mapAlerts(com.lowes.generated.model.offerevent.Alerts alerts) {
    return alerts == null ? null
        : new AlertsPayloadDto(alerts.getHasError(), alerts.getHasWarning());
  }

  private List<CommentsPayloadDto> mapComments(List<Comment> commentList) {
    if (CollectionUtils.isEmpty(commentList)) {
      return List.of();
    }
    return mapList(commentList, c -> new CommentsPayloadDto(
        toString(c.getCommentId()),
        toString(c.getCommentText()),
        toString(c.getCreatedBy()),
        toString(c.getCreatedTs()),
        toString(c.getModifiedTs()),
        toString(c.getModifiedBy()),
        toString(c.getSpotlightUserRole())
    ));
  }

  private PromotionMetaDataPayloadDto mapPromotionMetaData(PromotionMetaData dto) {
    if (dto == null) {
      return new PromotionMetaDataPayloadDto(List.of(), List.of(), List.of(), null);
    }
    var eventIds = safe(dto.getEventIds());
    var divisions = safe(dto.getDivisions());
    var subDivisions = safe(dto.getSubDivisions());
    var link = toString(dto.getPromoTrackerLink());
    return new PromotionMetaDataPayloadDto(eventIds, divisions, subDivisions, link);
  }

  private SchedulePayloadDto mapSchedule(Schedule dto) {
    if (dto == null) {
      return null;
    }
    return new SchedulePayloadDto(
        convertLocalDateTimeToString(dto.getStartDate()),
        convertLocalDateTimeToString(dto.getEndDate()),
        dto.getNoEndDate(),
        dto.getCalendarWeek(),
        toStringList(dto.getDaysOfWeek()),
        convertLocalDateTimeToString(dto.getActiveStartDate()),
        convertLocalDateTimeToString(dto.getActiveEndDate())
    );
  }

  public static String convertLocalDateTimeToString(LocalDateTime dateTime) {
    if (dateTime == null) {
      return null;
    }
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    return dateTime.format(formatter);
  }

  private LocationsPayloadDto mapLocations(com.lowes.generated.model.offerevent.Locations dto) {
    if (dto == null) {
      return new LocationsPayloadDto(false, List.of(), List.of());
    }
    return new LocationsPayloadDto(
        dto.getIncludeAllStores(),
        toStringList(dto.getStores()),
        toStringList(dto.getPatches())
    );
  }

  private CustomerPayloadDto mapCustomer(Customer dto) {
    if (dto == null) {
      return new CustomerPayloadDto(null, List.of(), null);
    }
    PromotionPayloadEnums.CustomerEnum customerType = mapCustomerType(dto.getCustomerType());
    List<LoyaltyPayloadDto> loyalties = mapList(dto.getLoyalties(),
        l -> new LoyaltyPayloadDto(toString(l.getTierId()), toString(l.getLoyaltyName())));
    SegmentPayloadDto segment = mapSegment(dto.getSegment());
    return new CustomerPayloadDto(customerType, loyalties, segment);
  }

  private SegmentPayloadDto mapSegment(Segment dto) {
    if (dto == null) {
      return null;
    }
    List<ProgramTierPayloadDto> tiers = mapList(dto.getProgramTierIds(),
        t -> new ProgramTierPayloadDto(toString(t.getId()), toString(t.getName())));
    return new SegmentPayloadDto(toString(dto.getProgramKey()), toString(dto.getProgramId()),
        tiers);
  }

  private List<TierPayloadDto> mapTiers(List<Tier> avroTiers) {
    return mapList(avroTiers, t -> {
      List<ConditionGroupPayloadDto> conditionGroups = mapList(t.getConditionGroups(),
          this::mapConditionGroup);
      List<RewardGroupPayloadDto> rewardGroups = mapList(t.getRewardGroups(), this::mapRewardGroup);
      return new TierPayloadDto(t.getTierId(), conditionGroups, rewardGroups);
    });
  }

  private ConditionGroupPayloadDto mapConditionGroup(ConditionGroup dto) {
    if (dto == null) {
      return null;
    }
    var conditionType = mapConditionType(dto.getConditionType());
    var conditionOn = mapConditionOn(dto.getConditionOn());

    List<ItemAttributesPayloadDto> itemAttrs = dto.getItemConditionAttributes().stream()
        .map(this::mapItemConditionAttributes).collect(Collectors.toList());

    ILOConditionAttributesPayloadDto ilo = mapILOConditionAttributes(
        dto.getIloConditionAttributes());

    return new ConditionGroupPayloadDto(dto.getGroupId(), conditionType, conditionOn, itemAttrs,
        ilo);
  }

  private ItemAttributesPayloadDto mapItemConditionAttributes(ItemAttributes dto) {
    if (dto == null) {
      return null;
    }
    return new ItemAttributesPayloadDto(
        toString(dto.getCatalogRef()),
        mapUnit(dto.getUnit()),
        dto.getMixAndMatch(),
        dto.getValue(),
        null, // min - not available in source
        null, // max - not available in source
        dto.getXOrMore(),
        mapList(dto.getPaymentModes(), pm -> PromotionPayloadEnums.PaymentModes.valueOf(pm.name())),
        mapPurchaseMode(dto.getPurchaseMode())
    );
  }

  private ILOConditionAttributesPayloadDto mapILOConditionAttributes(ILOConditionAttributes dto) {
    if (dto == null) {
      return null;
    }
    return new ILOConditionAttributesPayloadDto(
        toString(dto.getValidationRequestId()),
        toString(dto.getCatalogRef()),
        mapDiscountType(dto.getDiscountType()),
        dto.getMixAndMatch(),
        mapPurchaseMode(dto.getPurchaseMode()),
        mapUnit(dto.getUnit()),
        dto.getValue(),
        dto.getXOrMore(),
        dto.getProgramType() != null ? dto.getProgramType().name() : null
    );
  }

  private RewardGroupPayloadDto mapRewardGroup(RewardGroup dto) {
    if (dto == null) {
      return null;
    }

    // Reward items
    List<RewardItemAttributesPayloadDto> items = mapList(dto.getItemConditionAttributes(), i ->
        new RewardItemAttributesPayloadDto(toString(i.getCatalogRef()), mapUnit(i.getUnit()),
            i.getValue()));

    // Shipping
    ShippingAttributesPayloadDto ship = null;
    if (dto.getShippingAttributes() != null) {
      List<ShippingTypeFieldsPayloadDto> types = mapList(
          dto.getShippingAttributes().getShippingTypes(), st ->
              new ShippingTypeFieldsPayloadDto(
                  toString(st.getType()),
                  toString(st.getCategory()),
                  toString(st.getShippingMethod()),
                  toString(st.getFulfillmentType())
              ));
      ship = new ShippingAttributesPayloadDto(types);
    }

    // Reward attributes
    RewardAttributesPayloadDto rewardAttrs = null;
    if (dto.getRewardAttributes() != null) {
      rewardAttrs = new RewardAttributesPayloadDto(
          mapRewardQuantity(dto.getRewardAttributes().getRewardQuantity()),
          dto.getRewardAttributes().getQuantityValue(),
          mapDiscountType(dto.getRewardAttributes().getDiscountType()),
          mapDiscountOn(dto.getRewardAttributes().getDiscountOn()),
          dto.getRewardAttributes().getDiscountValue(),
          dto.getRewardAttributes().getMaxDiscount()
      );
    }

    // Finance
    FinanceAttributesPayloadDto fin = null;
    if (dto.getFinanceAttributes() != null) {
      fin = new FinanceAttributesPayloadDto(
          dto.getFinanceAttributes().getMonths(),
          mapFinanceType(dto.getFinanceAttributes().getFinanceType()),
          toString(dto.getFinanceAttributes().getTermIdentifier()),
          toString(dto.getFinanceAttributes().getTermType()),
          toString(dto.getFinanceAttributes().getBlockCode()),
          dto.getFinanceAttributes().getAnnualPercentRate()
      );
    }

    return new RewardGroupPayloadDto(
        dto.getGroupId(),
        mapRewardType(dto.getRewardType()),
        mapRewardOn(dto.getRewardOn()),
        items,
        ship,
        rewardAttrs,
        fin
    );
  }

  private List<CatalogPayloadDto> mapCatalogs(List<Catalog> dtoList) {
    return mapList(dtoList, c ->
        new CatalogPayloadDto(
            toString(c.getCatalogId()),
            mapCatalogFileRef(c.getCatalogFileRef()),
            mapProducts(c.getProducts())
        )
    );
  }

  private CatalogFileRefPayloadDto mapCatalogFileRef(CatalogFileRef dto) {
    if (dto == null) {
      return null;
    }
    return new CatalogFileRefPayloadDto(toString(dto.getOriginalName()),
        toString(dto.getUploadName()));
  }

  private PriceCatalogProductsPayloadDto mapPriceCatalogProducts(PriceCatalog dto) {
    if (dto == null || dto.getProducts() == null) {
      return null;
    }
    return new PriceCatalogProductsPayloadDto(
        mapPriceCatalogProductsInclude(dto.getProducts().getInclude())
    );
  }

  private PriceCatalogProductsIncludePayloadDto mapPriceCatalogProductsInclude(
      PriceCatalogProductsInclude dto) {
    if (dto == null) {
      return null;
    }
    return new PriceCatalogProductsIncludePayloadDto(
        mapList(dto.getItemDetails(), this::mapPriceCatalogItemDetail),
        dto.getProductType() != null ? dto.getProductType().name() : null,
        dto.getPriceCatalogType() != null ? dto.getPriceCatalogType().name() : null
    );
  }

  private PriceCatalogItemDetailPayloadDto mapPriceCatalogItemDetail(PriceCatalogItemDetail dto) {
    if (dto == null) {
      return null;
    }
    return new PriceCatalogItemDetailPayloadDto(
        toString(dto.getId()),
        toString(dto.getItemDesc()),
        toString(dto.getItemNo()),
        toString(dto.getModelNo()),
        toString(dto.getVendorNo()),
        mapPriceCatalogItemLocations(dto.getLocations()),
        toString(dto.getValue()),
        dto.getIsoFlag(),
        toString(dto.getFutureBasePrice()),
        toString(dto.getEcpPrice()),
        toString(dto.getPmap()),
        toString(dto.getHousePromo()),
        toString(dto.getInOutCart()),
        toString(dto.getOnlineNowPrice()),
        toString(dto.getStorePrice())
    );
  }

  private PriceCatalogItemLocationsPayloadDto mapPriceCatalogItemLocations(
      com.lowes.generated.model.offerevent.pricecatalog.Locations dto) {
    if (dto == null) {
      return null;
    }
    return new PriceCatalogItemLocationsPayloadDto(
        dto.getIncludeAllStores(),
        dto.getPatches() != null ? dto.getPatches() : List.of(),
        dto.getStores() != null ? dto.getStores() : List.of()
    );
  }

  private ProductsPayloadDto mapProducts(Products dto) {
    if (dto == null) {
      return null;
    }

    IncludeProductsPayloadDto include = null;
    if (dto.getInclude() != null) {
      include = new IncludeProductsPayloadDto(
          mapProductType(dto.getInclude().getProductType()),
          mapList(dto.getInclude().getItemDetails(), this::mapItemDetails),
          List.of(),
          toStringList(dto.getInclude().getPcrs()),
          mapList(dto.getInclude().getCategoryDetails(),
              cd -> new CategoryDetailsPayloadDto(toString(cd.getId()), toString(cd.getValue()))),
          mapList(dto.getInclude().getMerchBuckets(),
              kv -> new KeyValuePayloadDto(toString(kv.getId()), toString(kv.getValue()))),
          mapList(dto.getInclude().getDigitalTaxonomies(),
              kv -> new KeyValuePayloadDto(toString(kv.getId()), toString(kv.getValue())))
      );
    }

    // Exclude not provided; keep as null per current contract
    ExcludeProductsPayloadDto exclude = null;

    return new ProductsPayloadDto(include, exclude);
  }

  private ItemDetailsPayloadDto mapItemDetails(ItemDetails d) {
    if (d == null) {
      return null;
    }
    return new ItemDetailsPayloadDto(
        toString(d.getItemNo()),
        toString(d.getVendorNo()),
        toString(d.getModelNo()),
        d.getServiceItem(),
        d.getDefaultItem() != null && d.getDefaultItem(),
        d.getPriority(),
        null,
        null
    );
  }

  private MarketingInfoPayloadDto mapMarketingInfo(MarketingInfo dto) {
    if (dto == null) {
      return null;
    }

    // Marketing featured items → Spotlight FeatureCatalogItem/FeatureItemDetail
    Set<FeatureCatalogItemPayloadDto> featured = mapSet(dto.getFeaturedItems(), cat -> {
      String catalogId = toString(cat.getCatalogId());
      Set<FeatureItemDetailPayloadDto> items = mapSet(cat.getItemDetails(), it ->
          new FeatureItemDetailPayloadDto(
              toString(it.getItemNo()),
              toString(it.getVendorNo()),
              toString(it.getModelNo()),
              toStringSet(it.getPatches()),
              toStringSet(it.getStores())
          )
      );
      return new FeatureCatalogItemPayloadDto(catalogId, items);
    });

    TopOfferInfoPayloadDto topOfferInfo = mapTopOfferInfo(dto.getTopOfferInfo());
    SalesProjectionPayloadDto salesProjection = mapSalesProjection(dto.getSalesProjection());

    return new MarketingInfoPayloadDto(
        dto.getMarketingEligible(),
        topOfferInfo,
        toStringList(dto.getOfferIntent()),
        salesProjection,
        featured,
        dto.getDealOfTheDay()
    );
  }

  private TopOfferInfoPayloadDto mapTopOfferInfo(TopOfferInfo dto) {
    if (dto == null) {
      return null;
    }
    return new TopOfferInfoPayloadDto(
        dto.getTopOffer(),
        dto.getDoorBuster(),
        null // topOfferSchedule not available in source DTO
    );
  }

  private SalesProjectionPayloadDto mapSalesProjection(SalesProjection dto) {
    if (dto == null) {
      return null;
    }
    return new SalesProjectionPayloadDto(
        dto.getSales(),
        dto.getUnitsSold(),
        dto.getMargin()
    );
  }

  private LabelInfoResponse mapLabelInfo(LabelInfo dto) {
    if (dto == null) {
      return null;
    }
    return new LabelInfoResponse(dto.getLabelEligible(), dto.getLabelCode(),
        toString(dto.getLabelType()));
  }

  private OfferGroupDetailsPayloadDto mapOfferGroup(OfferGroup dto) {
    if (dto == null) {
      return null;
    }
    Integer id = null;
    if (dto.getId() != null) {
      try {
        id = Math.toIntExact(dto.getId());
      } catch (ArithmeticException ex) {
        // out-of-range for int → leave null; log if needed
        log.warn("OfferGroup id out of int range: {}", dto.getId(), ex);
      }
    }
    return new OfferGroupDetailsPayloadDto(id, toString(dto.getName()));
  }

  private PriceCatalogProductsPayloadDto mapPriceCatalog(PriceCatalog pc) {
    if (pc == null || pc.getProducts() == null || pc.getProducts().getInclude() == null) {
      return null;
    }
    return new PriceCatalogProductsPayloadDto(
        mapPriceCatalogProductsInclude(pc.getProducts().getInclude()));
  }

  private ForecastOverridesPayloadDto mapForecastOverrides(ForecastOverridesDto dto) {
    if (dto == null) {
      return null;
    }
    return new ForecastOverridesPayloadDto(
        mapSet(dto.getCatalogOverrides(), this::mapCatalogOverrides),
        mapPromoOverrides(dto.getPromoOverrides())
    );
  }

  private CatalogOverridesPayloadDto mapCatalogOverrides(CatalogOverridesDto dto) {
    if (dto == null) {
      return null;
    }
    return new CatalogOverridesPayloadDto(
        toString(dto.getCatalogId()),
        toString(dto.getCatalogProductType()),
        toString(dto.getCatalogType()),
        mapList(dto.getItemOverrides(), this::mapItemOverrides)
    );
  }

  private ItemOverridesPayloadDto mapItemOverrides(ItemOverridesDto dto) {
    if (dto == null) {
      return null;
    }
    return new ItemOverridesPayloadDto(
        dto.getForecastedUnitsOverrideVal(),
        toString(dto.getItemNo()),
        toString(dto.getModelNo()),
        toString(dto.getSubCatalogRef()),
        toString(dto.getVendorNo())
    );
  }

  private PromoOverridesPayloadDto mapPromoOverrides(PromoOverridesDto dto) {
    if (dto == null) {
      return null;
    }
    return new PromoOverridesPayloadDto(dto.getForecastedUnitsOverrideVal());
  }

  private RebateInfoPayloadDto mapRebateInfo(RebateInfo dto) {
    if (dto == null) {
      return null;
    }
    return new RebateInfoPayloadDto(
        dto.getRebate(),
        dto.getRebateProgramType() != null ? dto.getRebateProgramType().name() : null,
        toString(dto.getRebateProgramName())
    );
  }

  private VersionChangesPayloadDto mapVersionChanges(VersionChangesDto dto) {
    if (dto == null) {
      return null;
    }
    return new VersionChangesPayloadDto(
        dto.getSections() != null ? dto.getSections() : List.of(),
        dto.getPromotionSections() != null ? dto.getPromotionSections() : List.of(),
        dto.getForecastSections() != null ? dto.getForecastSections() : List.of(),
        dto.getMarketingSections() != null ? dto.getMarketingSections() : List.of()
    );
  }

  private StackingGroupPayloadDto mapStackingGroup(StackingGroup stackingGroup) {
    if (stackingGroup == null) {
      return null;
    }
    Boolean stackWithOthers = stackingGroup.getStackWithOtherOffers();
    return stackWithOthers == null ? null : new StackingGroupPayloadDto(stackWithOthers);
  }

  private List<VendorFundingInfoPayloadDto> mapVendorFunding(List<VendorFundingInfo> arr) {
    if (CollectionUtils.isEmpty(arr)) {
      return null;
    }

    return arr.stream().map(vendorFundingInfo -> {
      VendorFundingInfo dto = vendorFundingInfo; // Use stream parameter

      FundingDetailsPayloadDto fd = null;
      if (dto.getFundingDetails() != null) {
        var f = dto.getFundingDetails();
        FundingCalcPayloadDto calc = null;
        if (f.getFundingCalc() != null) {
          var c = f.getFundingCalc();
          calc = new FundingCalcPayloadDto(
              vendorFundingCalculationBasis(c.getBasis()),
              c.getAmt(),
              c.getMaxAmt(),
              c.getTieredFundingAmounts()
          );
        }
        List<AttachmentsPayloadDto> attachments = mapList(f.getAttachments(),
            a -> new AttachmentsPayloadDto(a.getDocumentId(),
                a.getDocumentName()));
        fd = new FundingDetailsPayloadDto(
            f.getSubDivId(),
            calc,
            f.getCollectionMethod(),
            f.getRemitVbu(),
            f.getPartOfAnotherNegotiatedAgreement(),
            f.getFundsSubjectToContingency(),
            f.getFundContingencyDetails(),
            f.getAreItemsSoldDirectly(),
            f.getItemSaleDetails(),
            f.getAttachmentUrls(),
            attachments,
            f.getAdditionalNotes()
        );
      }

      List<String> fundedItems = List.of(); // not exposed at this level
      List<VendorContactPayloadDto> contacts = mapList(dto.getVendorContacts(),
          c -> new VendorContactPayloadDto(c.getId(), c.getName()));

      SignersPayloadDto signers = null;
      if (dto.getSigners() != null) {
        var s = dto.getSigners();
        MerchantSignerPayloadDto ms = (s.getMerchantSigner() == null) ? null
            : new MerchantSignerPayloadDto(s.getMerchantSigner().getId());
        signers = new SignersPayloadDto(s.getVendorSignerId(), ms);
      }

      List<CatalogLevelVariancePayloadDto> variances = mapList(dto.getCatalogLevelVariance(), v ->
          new CatalogLevelVariancePayloadDto(
              v.getCatalogId(),
              v.getCatalogType() == null ? null : v.getCatalogType().name(),
              v.getCatalogProductType() == null ? null : v.getCatalogProductType().name(),
              mapList(v.getCatalogLevelVarianceValues(), val ->
                  new CatalogLevelVarianceValuePayloadDto(
                      val.getSubCatalogRef(),
                      val.getItemNo(),
                      val.getVendorNo(),
                      val.getModelNo(),
                      val.getValue()
                  )
              )
          )
      );

      return new VendorFundingInfoPayloadDto(
          dto.getVendorNo(),
          fundedItems,
          fd,
          contacts,
          signers,
          variances
      );
    }).toList();
  }


  private PromotionPayloadEnums.VendorFundingCalculationBasis vendorFundingCalculationBasis(
      com.lowes.generated.model.offerevent.VendorFundingCalculationBasis e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case FIXED_AMOUNT -> PromotionPayloadEnums.VendorFundingCalculationBasis.FIXED_AMOUNT;
      case PER_UNIT_DOLLAR -> PromotionPayloadEnums.VendorFundingCalculationBasis.PER_UNIT_DOLLAR;
      case PER_OF_COST -> PromotionPayloadEnums.VendorFundingCalculationBasis.PER_OF_COST;
      case PER_OF_RETAIL -> PromotionPayloadEnums.VendorFundingCalculationBasis.PER_OF_RETAIL;
    };
  }

  private PromotionPayloadEnums.MarketScopeEnum mapMarketScope(
      com.lowes.generated.model.offerevent.MarketScopeEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case STORE -> PromotionPayloadEnums.MarketScopeEnum.STORE;
      case ONLINE -> PromotionPayloadEnums.MarketScopeEnum.ONLINE;
      case OMNI -> PromotionPayloadEnums.MarketScopeEnum.OMNI;
    };
  }

  private PromotionPayloadEnums.RedemptionTypeEnum mapRedemptionType(
      com.lowes.generated.model.offerevent.RedemptionTypeEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case INSTANT -> PromotionPayloadEnums.RedemptionTypeEnum.INSTANT;
      case COUPON -> PromotionPayloadEnums.RedemptionTypeEnum.COUPON;
      case AUTO_APPLY_CODE -> PromotionPayloadEnums.RedemptionTypeEnum.AUTO_APPLY_CODE;
    };
  }

  private PromotionPayloadEnums.ExecutionMessageTypeEnum mapExecutionMessageType(
      com.lowes.generated.model.offerevent.ExecutionMessageTypeEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case REGULAR -> PromotionPayloadEnums.ExecutionMessageTypeEnum.REGULAR;
      case EMERGENCY -> PromotionPayloadEnums.ExecutionMessageTypeEnum.EMERGENCY;
    };
  }

  private PromotionPayloadEnums.StatusEnum mapStatus(
      com.lowes.generated.model.offerevent.StatusEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case INPROGRESS -> PromotionPayloadEnums.StatusEnum.INPROGRESS;
      case COMPLETE -> PromotionPayloadEnums.StatusEnum.COMPLETE;
      case DELETED -> PromotionPayloadEnums.StatusEnum.DELETED;
      case PROPOSED -> PromotionPayloadEnums.StatusEnum.PROPOSED;
      case CANCELLED -> PromotionPayloadEnums.StatusEnum.CANCELLED;
    };
  }

  private PromotionPayloadEnums.ConditionTypeEnum mapConditionType(
      com.lowes.generated.model.offerevent.ConditionTypeEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case CATALOG_ITEMS -> PromotionPayloadEnums.ConditionTypeEnum.CATALOG_ITEMS;
      case CATALOG_ITEMS_ILO -> PromotionPayloadEnums.ConditionTypeEnum.CATALOG_ITEMS_ILO;
      case CATALOG_ITEMS_NDO -> PromotionPayloadEnums.ConditionTypeEnum.CATALOG_ITEMS_NDO;
    };
  }

  private PromotionPayloadEnums.ConditionOnEnum mapConditionOn(
      com.lowes.generated.model.offerevent.ConditionOnEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case ENTIRE_CART -> PromotionPayloadEnums.ConditionOnEnum.ENTIRE_CART;
      case SPECIFIC_ITEMS -> PromotionPayloadEnums.ConditionOnEnum.SPECIFIC_ITEMS;
      case ENTIRE_CART_PAYMENT -> PromotionPayloadEnums.ConditionOnEnum.ENTIRE_CART_PAYMENT;
      case SPECIFIC_ITEMS_ILO -> PromotionPayloadEnums.ConditionOnEnum.SPECIFIC_ITEMS_ILO;
      case SPECIFIC_ITEM_PAYMENT -> PromotionPayloadEnums.ConditionOnEnum.SPECIFIC_ITEM_PAYMENT;
      case SPECIFIC_ITEMS_NDO -> PromotionPayloadEnums.ConditionOnEnum.SPECIFIC_ITEMS_NDO;
    };
  }

  private PromotionPayloadEnums.DiscountTypeEnum mapDiscountType(
      com.lowes.generated.model.offerevent.DiscountTypeEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case PERCENTAGE_OFF -> PromotionPayloadEnums.DiscountTypeEnum.PERCENTAGE_OFF;
      case AMOUNT_OFF -> PromotionPayloadEnums.DiscountTypeEnum.AMOUNT_OFF;
      case FIXED_PRICE -> PromotionPayloadEnums.DiscountTypeEnum.FIXED_PRICE;
      case FREE -> PromotionPayloadEnums.DiscountTypeEnum.FREE;
    };
  }

  private PromotionPayloadEnums.UnitEnum mapUnit(com.lowes.generated.model.offerevent.UnitEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case QUANTITY -> PromotionPayloadEnums.UnitEnum.QUANTITY;
      case SPEND -> PromotionPayloadEnums.UnitEnum.SPEND;
    };
  }

  private PromotionPayloadEnums.PurchaseMode mapPurchaseMode(
      com.lowes.generated.model.offerevent.PurchaseMode e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case ONE_TIME -> PromotionPayloadEnums.PurchaseMode.ONE_TIME;
      case SUBSCRIPTION -> PromotionPayloadEnums.PurchaseMode.SUBSCRIPTION;
    };
  }

  private PromotionPayloadEnums.RewardQuantityEnum mapRewardQuantity(
      com.lowes.generated.model.offerevent.RewardQuantityEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case ALL_QUANTITY -> PromotionPayloadEnums.RewardQuantityEnum.ALL_QUANTITY;
      case SPECIFIC_QUANTITY -> PromotionPayloadEnums.RewardQuantityEnum.SPECIFIC_QUANTITY;
    };
  }

  private PromotionPayloadEnums.DiscountOnEnum mapDiscountOn(
      com.lowes.generated.model.offerevent.DiscountOnEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case ALL_UNITS -> PromotionPayloadEnums.DiscountOnEnum.ALL_UNITS;
      case EACH_UNIT -> PromotionPayloadEnums.DiscountOnEnum.EACH_UNIT;
    };
  }

  private PromotionPayloadEnums.FinanceTypeEnum mapFinanceType(
      com.lowes.generated.model.offerevent.FinanceTypeEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case SPECIAL -> PromotionPayloadEnums.FinanceTypeEnum.SPECIAL;
      case PROJECT -> PromotionPayloadEnums.FinanceTypeEnum.PROJECT;
    };
  }

  private PromotionPayloadEnums.RewardTypeEnum mapRewardType(
      com.lowes.generated.model.offerevent.RewardTypeEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case CATALOG_ITEMS -> PromotionPayloadEnums.RewardTypeEnum.CATALOG_ITEMS;
      case SHIPPING -> PromotionPayloadEnums.RewardTypeEnum.SHIPPING;
      case FINANCE -> PromotionPayloadEnums.RewardTypeEnum.FINANCE;
    };
  }

  private PromotionPayloadEnums.RewardOnEnum mapRewardOn(
      com.lowes.generated.model.offerevent.RewardOnEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case ENTIRE_CART -> PromotionPayloadEnums.RewardOnEnum.ENTIRE_CART;
      case SPECIFIC_ITEMS -> PromotionPayloadEnums.RewardOnEnum.SPECIFIC_ITEMS;
      case ITEMS_ON_CONDITION -> PromotionPayloadEnums.RewardOnEnum.ITEMS_ON_CONDITION;
      case SPECIFIC_ITEMS_CHOICE -> PromotionPayloadEnums.RewardOnEnum.SPECIFIC_ITEMS_CHOICE;
    };
  }

  private PromotionPayloadEnums.CustomerEnum mapCustomerType(
      com.lowes.generated.model.offerevent.CustomerEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case REGULAR -> PromotionPayloadEnums.CustomerEnum.REGULAR;
      case DIY -> PromotionPayloadEnums.CustomerEnum.DIY;
      case PRO -> PromotionPayloadEnums.CustomerEnum.PRO;
      case EMPLOYEE -> PromotionPayloadEnums.CustomerEnum.EMPLOYEE;
      case MILITARY -> PromotionPayloadEnums.CustomerEnum.MILITARY;
      case ALL -> PromotionPayloadEnums.CustomerEnum.ALL;
    };
  }

  private PromotionPayloadEnums.ProductTypeEnum mapProductType(
      com.lowes.generated.model.offerevent.ProductTypeEnum e) {
    if (e == null) {
      return null;
    }
    return switch (e) {
      case ITEM -> PromotionPayloadEnums.ProductTypeEnum.ITEM;
      case BRAND -> PromotionPayloadEnums.ProductTypeEnum.BRAND;
      case PCR -> PromotionPayloadEnums.ProductTypeEnum.PCR;
      case PRODUCT_GROUP -> PromotionPayloadEnums.ProductTypeEnum.PRODUCT_GROUP;
      case ASSORTMENT -> PromotionPayloadEnums.ProductTypeEnum.ASSORTMENT;
      case MERCH_BUCKET -> PromotionPayloadEnums.ProductTypeEnum.MERCH_BUCKET;
      case DIGITAL_TAXONOMY -> PromotionPayloadEnums.ProductTypeEnum.DIGITAL_TAXONOMY;
      case UPLOAD -> PromotionPayloadEnums.ProductTypeEnum.UPLOAD;
      case ALL_LOWES_ITEMS -> PromotionPayloadEnums.ProductTypeEnum.ALL_LOWES_ITEMS;
    };
  }

  private OfferIntegrationCompatibilityPayloadDto mapOfferIntegrationCompatibility(
      OfferIntegrationCompatibility oic) {
    if (Objects.isNull(oic)) {
      return null;
    }
    return new OfferIntegrationCompatibilityPayloadDto(oic.getIsSupportedByCalc(),
        oic.getIsSupportedByVendorFunding(),
        oic.getIndicators() != null ? new HashSet<>(oic.getIndicators()) : Set.of());
  }

  // ========= Utility Methods =========

  /**
   * Safely converts a list to set, filtering null values.
   *
   * @param list the list to convert, may be null
   * @return the set of non-null elements, or empty set if input is null
   */
  private static <T> Set<T> toSet(List<T> list) {
    if (list == null) {
      return Set.of();
    }
    return list.stream()
        .filter(Objects::nonNull)
        .collect(Collectors.toCollection(LinkedHashSet::new));
  }

  /**
   * Safely processes a list, filtering null values and applying a mapper function.
   *
   * @param list   the input list, may be null
   * @param mapper the mapping function to apply to each non-null element
   * @param <T>    the input type
   * @param <R>    the output type
   * @return the list of mapped elements, or empty list if input is null
   */
  private static <T, R> List<R> mapList(List<T> list, Function<T, R> mapper) {
    if (list == null) {
      return List.of();
    }
    return list.stream()
        .filter(Objects::nonNull)
        .map(mapper)
        .filter(Objects::nonNull)
        .toList();
  }


  /**
   * Safely processes a list, filtering null values and applying a mapper function.
   *
   * @param list   the input list, may be null
   * @param mapper the mapping function to apply to each non-null element
   * @param <T>    the input type
   * @param <R>    the output type
   * @return the list of mapped elements, or empty list if input is null
   */
  private static <T, R> Set<R> mapSet(List<T> list, Function<T, R> mapper) {
    if (list == null) {
      return Set.of();
    }
    return list.stream()
        .filter(Objects::nonNull)
        .map(mapper)
        .filter(Objects::nonNull)
        .collect(Collectors.toSet());
  }

  /**
   * Safely processes a list, filtering null values.
   *
   * @param list the input list, may be null
   * @param <T>  the element type
   * @return the list of non-null elements, or empty list if input is null
   */
  private static <T> List<T> safe(List<T> list) {
    return list == null ? List.of() : list.stream().filter(Objects::nonNull).toList();
  }

  // ========= Date/Time Converters =========

  private static final DateTimeFormatter ISO = DateTimeFormatter.ISO_OFFSET_DATE_TIME;
  private static final ZoneId ZONE = ZoneId.of("UTC"); // adjust if you need a specific local zone

  @SuppressWarnings("unused")
  private static String ts(Long epochMillis) {
    if (epochMillis == null) {
      return null;
    }
    return ISO.format(Instant.ofEpochMilli(epochMillis).atZone(ZONE));
  }

  private static String toString(CharSequence cs) {
    return cs == null ? null : cs.toString();
  }

  private static List<String> toStringList(List<? extends CharSequence> list) {
    if (list == null) {
      return List.of();
    }
    return list.stream()
        .filter(Objects::nonNull)
        .map(OfferEventMapper::toString)
        .filter(Objects::nonNull)
        .collect(Collectors.toList());
  }

  private static Set<String> toStringSet(List<? extends CharSequence> list) {
    if (list == null) {
      return Set.of();
    }
    return list.stream()
        .filter(Objects::nonNull)
        .map(OfferEventMapper::toString)
        .filter(Objects::nonNull)
        .collect(Collectors.toCollection(LinkedHashSet::new));
  }

}
