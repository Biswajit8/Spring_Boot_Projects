package com.lowes.promotionstore.controller;


import com.lowes.promotionstore.configuration.KafkaConsumerToggleConfig;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/app-config")
@AllArgsConstructor
@Slf4j
public class ToggleKafkaConsumerController {

  private final KafkaConsumerToggleConfig kafkaConsumerToggleConfig;

  @PostMapping("/toggle-adapter-consumer")
  public ResponseEntity<Boolean> toggleAdapterConsumer() {
    kafkaConsumerToggleConfig.setEnableAdapterConsumer(
        !kafkaConsumerToggleConfig.isEnableAdapterConsumer());
    return new ResponseEntity<>(kafkaConsumerToggleConfig.isEnableAdapterConsumer(), HttpStatus.OK);
  }

  @PostMapping("/toggle-offer-event-consumer")
  public ResponseEntity<Boolean> toggleOfferEventsConsumer() {
    kafkaConsumerToggleConfig.setEnableOfferEventsConsumer(
        !kafkaConsumerToggleConfig.isEnableOfferEventsConsumer());
    return new ResponseEntity<>(kafkaConsumerToggleConfig.isEnableOfferEventsConsumer(),
        HttpStatus.OK);
  }

  @PostMapping("/toggle-offer-product-consumer")
  public ResponseEntity<Boolean> toggleOfferProductConsumer() {
    kafkaConsumerToggleConfig.setEnableOfferProductConsumer(
        !kafkaConsumerToggleConfig.isEnableOfferProductConsumer());
    return new ResponseEntity<>(kafkaConsumerToggleConfig.isEnableOfferProductConsumer(),
        HttpStatus.OK);
  }

  @PostMapping("/toggle-full-load-consumer")
  public ResponseEntity<Boolean> toggleFullLoadConsumer() {
    kafkaConsumerToggleConfig.setEnableFullLoadConsumer(
        !kafkaConsumerToggleConfig.isEnableFullLoadConsumer());
    return new ResponseEntity<>(kafkaConsumerToggleConfig.isEnableFullLoadConsumer(),
        HttpStatus.OK);
  }

  @PostMapping("/toggle-feedback-consumer")
  public ResponseEntity<Boolean> toggleEnableFeedback() {
    kafkaConsumerToggleConfig.setEnableFeedback(
        !kafkaConsumerToggleConfig.isEnableFeedback());
    return new ResponseEntity<>(kafkaConsumerToggleConfig.isEnableFeedback(),
        HttpStatus.OK);
  }

  @GetMapping("/toggle-status")
  public ResponseEntity<Map<String, Boolean>> getToggleStatus() {
    return new ResponseEntity<>(
        Map.of("Spotlight Event Consumer", kafkaConsumerToggleConfig.isEnableAdapterConsumer(),
            "Full Load Consumer", kafkaConsumerToggleConfig.isEnableFullLoadConsumer(),
            "Offer Event Consumer", kafkaConsumerToggleConfig.isEnableOfferEventsConsumer(),
            "Offer Product Consumer", kafkaConsumerToggleConfig.isEnableOfferProductConsumer(),
            "Offer Feedback Consumer", kafkaConsumerToggleConfig.isEnableFeedback()
        ),
        HttpStatus.OK);
  }
}