package com.lowes.promotionstore.constants.enums;

public enum CalendarUnitType {
  PROMO_WEEK,
  FISCAL_WEEK,
  FISCAL_QUARTER,
  DATE_RANGE
}
