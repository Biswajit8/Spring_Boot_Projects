package com.lowes.promotionstore.model.coredata.validationresponse;

public enum ValidationStatus {
  PENDING,
  PROCESSING,
  COMPLETED,
  SUCCESS,
  FAILED

}
