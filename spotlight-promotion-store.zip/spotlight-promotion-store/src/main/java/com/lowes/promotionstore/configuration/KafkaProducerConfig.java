package com.lowes.promotionstore.configuration;

import com.lowes.generated.model.amplification.OfferAmplifiedPublishDto;
import com.lowes.promotionstore.configuration.properties.KafkaProps;
import com.lowes.promotionstore.configuration.properties.KafkaProps.ProducerSpec;
import io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroSerializer;
import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import lombok.RequiredArgsConstructor;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.util.StringUtils;

import java.util.HashMap;
import java.util.Map;

import static org.apache.kafka.common.config.SaslConfigs.SASL_JAAS_CONFIG;

@Configuration
@RequiredArgsConstructor
public class KafkaProducerConfig {

  private static final String OFFER_EVENTS_PRODUCER = "OFFER_FFEDBACK_PUBLISH";
  private final KafkaProps kafkaProps;


  @Bean(name = "KafkaTemplate")
  public KafkaTemplate<String, OfferAmplifiedPublishDto> kafkaTemplateForOfferMgmtUser() {
    KafkaTemplate<String, OfferAmplifiedPublishDto> kafkaTemplate =
        new KafkaTemplate<>(producerFactory(
            kafkaProps.getProducer().getAmplificationFeedbackProducer()));
    return kafkaTemplate;
  }

  public Map<String, Object> commonConfigs() {
    Map<String, Object> configs = new HashMap<>();
    configs.put("sasl.jaas.config", createJaasConfig());
    configs.put("security.protocol", kafkaProps.getSecurityProtocol());
    configs.put("ssl.truststore.location", kafkaProps.getTrustStoreLocation());
    configs.put("ssl.truststore.password", kafkaProps.getTrustStorePassword());
    configs.put("sasl.mechanism", kafkaProps.getSaslMechanism());
    configs.put("ssl.endpoint.identification.algorithm", "");

    return configs;
  }

  private String createJaasConfig() {
    StringBuilder jaasConfig = new StringBuilder();
    jaasConfig.append("org.apache.kafka.common.security.scram.ScramLoginModule required username=");
    jaasConfig.append("\"");
    jaasConfig.append(kafkaProps.getSaslCredentials().getSpotlightUser().getUsername());
    jaasConfig.append("\"");
    jaasConfig.append(" password=");
    jaasConfig.append("\"");
    jaasConfig.append(kafkaProps.getSaslCredentials().getSpotlightUser().getPassword());
    jaasConfig.append("\"");
    jaasConfig.append(";");

    return jaasConfig.toString();
  }

  private ProducerFactory<String, OfferAmplifiedPublishDto> producerFactory(
      ProducerSpec producerConfiguration) {
    Map<String, Object> configProps = new HashMap<>(commonConfigs());
    configProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,
        kafkaProps.getDefaults().getBootstrapServerOnprem());
    if (StringUtils.hasText(kafkaProps.getDefaults().getSchemaRegistryUrl())) {

      configProps.put(AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG,
          kafkaProps.getDefaults().getSchemaRegistryUrl());
      configProps.put("schema.registry.ssl.truststore.location",
          kafkaProps.getTrustStoreLocation());
      configProps.put("schema.registry.ssl.truststore.password",
          kafkaProps.getTrustStorePassword());
      configProps.put(KafkaAvroSerializerConfig.AUTO_REGISTER_SCHEMAS, "false");
      configProps.put("value.subject.name.strategy",
          "io.confluent.kafka.serializers.subject.TopicNameStrategy");
    }

    configProps.putAll(onPremProducerSerializerConfig(producerConfiguration));
    configProps.put(SASL_JAAS_CONFIG, createJaasConfig());
    return new DefaultKafkaProducerFactory<>(configProps);
  }

  private Map<String, Object> onPremProducerSerializerConfig(
      ProducerSpec producerConfiguration) {
    Map<String, Object> configProps = new HashMap<>();
    configProps.put(ProducerConfig.CLIENT_ID_CONFIG, OFFER_EVENTS_PRODUCER);
    configProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
    configProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
        KafkaAvroSerializer.class);
    configProps.put(ProducerConfig.LINGER_MS_CONFIG, producerConfiguration.getLingerMs());
    configProps.put(ProducerConfig.BATCH_SIZE_CONFIG, producerConfiguration.getBatchSize());
    return configProps;
  }

}