package com.lowes.promotionstore.model.coredata.validationresponse;

import java.util.List;

public record ValidationResponse(String requestId, String promotionId, ValidationStatus status,
                                 ProgramTypeEnum type, int totalItems, int successCount,
                                 int errorCount, List<ValidatedItemResponse> successItems,
                                 List<ValidationErrorResponse> errorItems, String message,
                                 Integer bulkUploadTrackerId) {

}