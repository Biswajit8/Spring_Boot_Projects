package com.lowes.promotionstore.configuration.properties;

public enum PayloadFormat { JSON, AVRO, STRING }
