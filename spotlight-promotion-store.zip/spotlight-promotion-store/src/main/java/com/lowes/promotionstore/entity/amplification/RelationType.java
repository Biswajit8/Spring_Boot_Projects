
package com.lowes.promotionstore.entity.amplification;

public enum RelationType {
  LOCKED, UNLOCKED
}