package com.lowes.promotionstore.service;

import com.lowes.promotionstore.component.publisher.OfferAmplificationPublisher;
import com.lowes.promotionstore.constants.ApplicationConstants;
import com.lowes.promotionstore.entity.amplification.ActivityAssociation;
import com.lowes.promotionstore.entity.amplification.ActivityAssociationType;
import com.lowes.promotionstore.entity.amplification.PageBlockState;
import com.lowes.promotionstore.entity.amplification.RelationType;
import com.lowes.promotionstore.model.record.feedback.OfferDto;
import com.lowes.promotionstore.model.record.feedback.OfferEventPayloadDto;
import com.lowes.promotionstore.model.record.feedback.PagePayloadDto;
import com.lowes.promotionstore.repository.dao.ActivityDao;
import com.lowes.promotionstore.repository.dao.AssociationDao;
import com.lowes.promotionstore.repository.dao.BlockDao;
import com.lowes.promotionstore.repository.dao.PageDao;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionSynchronization;
import org.springframework.transaction.support.TransactionSynchronizationManager;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

import static java.util.Objects.requireNonNull;

@Slf4j
@Component
public class OfferAmplificationService {

  private final ActivityDao activityDao;
  private final AssociationDao associationDao;
  private final OfferAmplificationPublisher publisher;
  private final PageDao pageDao;
  private final BlockDao blockDao;
  private final ThreadPoolTaskExecutor publishLockedOffersExecutor;

  private static final int CHUNK_SIZE = 500;

  public OfferAmplificationService(ActivityDao activityDao, AssociationDao associationDao,
                                   OfferAmplificationPublisher publisher, PageDao pageDao, BlockDao blockDao,
                                   @Qualifier("evaluate-delta-executor") ThreadPoolTaskExecutor publishLockedOffersExecutor) {
    this.activityDao = activityDao;
    this.associationDao = associationDao;
    this.publisher = publisher;
    this.pageDao = pageDao;
    this.blockDao = blockDao;
    this.publishLockedOffersExecutor = publishLockedOffersExecutor;
  }

  enum PayloadType {
    ACTIVITY, CAMPAIGN, OFFER, PAGE, BLOCK;

    static PayloadType of(String s) {
      try {
        return valueOf(requireNonNull(s, "type").trim().toUpperCase(Locale.ROOT));
      } catch (Exception e) {
        throw new UnsupportedOperationException("Unsupported type: " + s);
      }
    }
  }

  enum Operation {
    CREATE, UPDATE, DELETE;

    static Operation of(String s) {
      try {
        return valueOf(requireNonNull(s, "operation").trim().toUpperCase(Locale.ROOT));
      } catch (Exception e) {
        throw new UnsupportedOperationException("Unsupported operation: " + s);
      }
    }
  }

  // ===== Public API kept minimal =====
  @Transactional
  public void process(OfferEventPayloadDto payload, String topic, String traceId)
      throws BadRequestException {

    requireNonNull(payload, "payload");
    final PayloadType type;
    final Operation op;

    try {
      type = PayloadType.of(payload.getType());
      op = Operation.of(payload.getOperation());
    } catch (UnsupportedOperationException | NullPointerException e) {
      log.warn("Rejecting payload due to invalid type/operation. ctx={}",
          ctx(payload, topic, traceId), e);
      throw new BadRequestException(e.getMessage());
    }

    log.info("process start {}", ctx(payload, topic, traceId));

    try {
      // Dispatch to dedicated handlers
      switch (type) {
        case ACTIVITY -> handleActivity(op, payload, topic, traceId);
        case CAMPAIGN -> handleCampaign(op, payload, topic, traceId);
        case OFFER -> handleOffer(op, payload, topic, traceId);
        case PAGE -> handlePage(op, payload, topic, traceId);
        case BLOCK -> handleBlock(op, payload, topic, traceId);
        default ->
            throw new UnsupportedOperationException("Unsupported operation for type: " + type);
      }

    } catch (IllegalArgumentException e) {
      log.warn("Bad request (validation). ctx={} : {}", ctx(payload, topic, traceId),
          e.getMessage(), e);
      throw new BadRequestException(e.getMessage());
    } catch (BadRequestException e) {
      log.warn("Bad request. ctx={} : {}", ctx(payload, topic, traceId), e.getMessage(), e);
      throw e;
    } catch (UnsupportedOperationException e) {
      log.warn("Bad request (unsupported). ctx={} : {}", ctx(payload, topic, traceId),
          e.getMessage(), e);
      throw new BadRequestException(e.getMessage());
    }

    log.info("process end {}", ctx(payload, topic, traceId));
  }

  private void handleBlock(Operation op, OfferEventPayloadDto payload, String topic, String traceId) throws BadRequestException {
    final String activityId = requireActivityId(payload);
    requireActivityExists(activityId);
    throwOnActivityExistsCancelledOnHold(activityId);

    switch (op) {
      case DELETE -> processBlockDelete(payload, activityId, topic, traceId);
      default -> throw new UnsupportedOperationException("Unsupported operation for block: " + op);
    }
  }

  // Block + DELETE
  private void processBlockDelete(OfferEventPayloadDto payload, String activityId, String topic, String traceId) {
    var block = requireNonNull(payload.getBlock(), "payload.block required");
    var page = requireNonNull(payload.getPage(), "payload.page required");
    blockDao.markBlockStatusDeleted(
            block); // Make the status of activity_block_info table as DELETED
    unlockOfferViaPageDeletion(payload, activityId, topic, traceId, page);
  }

  private void handlePage(Operation op, OfferEventPayloadDto payload, String topic, String traceId)
      throws BadRequestException {
    final String activityId = requireActivityId(payload);
    requireActivityExists(activityId);
    throwOnActivityExistsCancelledOnHold(activityId);

    switch (op) {
      case UPDATE -> processPageUpdate(payload);
      case DELETE -> processPageDelete(payload, activityId, topic, traceId);
      default -> throw new UnsupportedOperationException("Unsupported operation for page: " + op);
    }

  }

  // PAGE + UPDATE
  private void processPageUpdate(OfferEventPayloadDto payload) {
    var page = requireNonNull(payload.getPage(), "payload.page required");
    pageDao.updatePageAttributes(page); // Update the page type & number
  }

  // PAGE + DELETE
  private void processPageDelete(OfferEventPayloadDto payload, String activityId, String topic,
                                 String traceId) {
    var page = requireNonNull(payload.getPage(), "payload.page required");
    pageDao.markPageStatusDeleted(page); // Make the status of activity_page_info table as DELETED
    blockDao.deleteBlockByPageId(page); // Delete all blocks associated with the page
    unlockOfferViaPageDeletion(payload, activityId, topic, traceId, page);
    // Unlock offers with the page and delete the offer
  }

  private void unlockOfferViaPageDeletion(OfferEventPayloadDto payload, String activityId, String topic,
                                          String traceId, PagePayloadDto page) {
    List<ActivityAssociation> associatedPages = associationDao.findAllAssociatedPage(activityId, page);
    // Create a map of allocationId -> offerId
    Map<String, String> allocationOfferMap = associatedPages.stream()
            .collect(Collectors.toMap(
                    ActivityAssociation::getAllocationId,
                    ActivityAssociation::getEntityId,
                    (existing, replacement) -> existing // Keep first value if duplicate keys
            ));

    // Process each offer deletion with its corresponding allocationId
    allocationOfferMap.forEach((allocationId, offerId) -> {
      // Create a new payload with the specific offerId and allocationId
      OfferEventPayloadDto offerPayload = OfferEventPayloadDto.builder()
              .activity(payload.getActivity())
              .offer(OfferDto.builder()
                      .offerId(offerId)
                      .allocationId(allocationId)
                      .build())
              .build();

      try {
        processOfferDelete(offerPayload, topic, traceId);
      } catch (BadRequestException e) {
        log.error("Failed to process offer delete for offerId={}, allocationId={}, activityId={}",
                offerId, allocationId, activityId, e);
        // Continue processing other offers even if one fails
      }
    });
  }

  // ===== Type-level routers (tiny switches) =====
  private void handleActivity(Operation op, OfferEventPayloadDto payload, String topic,
      String traceId)
      throws BadRequestException {
    final String activityId = requireActivityId(payload);
    switch (op) {
      case CREATE -> processActivityCreate(payload, topic, traceId);
      case UPDATE -> processActivityUpdate(payload, activityId, topic, traceId);
      default ->
          throw new UnsupportedOperationException("Unsupported operation for activity: " + op);
    }
  }

  private void handleCampaign(Operation op, OfferEventPayloadDto payload, String topic,
      String traceId)
      throws BadRequestException {
    final String activityId = requireActivityId(payload);
    requireActivityExists(activityId);
    throwOnActivityExistsCancelledOnHold(activityId);

    switch (op) {
      case UPDATE -> processCampaignUpdate(payload, activityId);
      case DELETE -> processCampaignDelete(payload, activityId);
      default ->
          throw new UnsupportedOperationException("Unsupported operation for campaign: " + op);
    }
  }

  private void handleOffer(Operation op, OfferEventPayloadDto payload, String topic, String traceId)
      throws BadRequestException {
    final String activityId = requireActivityId(payload);
    requireActivityExists(activityId);
    throwOnActivityExistsCancelledOnHold(activityId);

    switch (op) {
      case UPDATE -> processOfferUpdate(payload, topic, traceId);
      case DELETE -> processOfferDelete(payload, topic, traceId);
      default -> throw new UnsupportedOperationException("Unsupported operation for offer: " + op);
    }
  }


  // ACTIVITY + CREATE
  private void processActivityCreate(OfferEventPayloadDto payload, String topic, String traceId)
      throws BadRequestException {
    final String activityId = requireActivityId(payload);
    throwOnActivityExistsCancelledOnHold(activityId);

    activityDao.createActivity(payload);

    associationDao.persistAssociationsOnActivityCreate(payload).ifPresent(relationType -> {
      String offerId = (payload.getOffer() != null) ? payload.getOffer().getOfferId() : null;
      if (offerId != null) {
        publishOfferRelationAfterCommit(offerId, relationType, topic, traceId);
      } else {
        log.warn("Transition present but offerId missing. ctx={}", ctx(payload, topic, traceId));
      }
    });

    if (Objects.nonNull(payload.getCampaign()) && Objects.nonNull(payload.getCampaign().getId())) {
      activityDao.markActivityUpdatedFromCampaign(activityId, payload.getChannel());
    }
  }

  // ACTIVITY + UPDATE
  private void processActivityUpdate(OfferEventPayloadDto payload, String activityId,
      String topic, String traceId)
      throws BadRequestException {
    requireActivityExists(activityId);

    String prev = activityDao.updateActivityFields(payload);
    String curr = (payload.getActivity() != null) ? payload.getActivity().getStatus() : null;

    if (!Objects.equals(prev, curr)) {

      if (curr.equalsIgnoreCase(ApplicationConstants.ON_HOLD) &&
          prev.equalsIgnoreCase(ApplicationConstants.CANCELLED)) {
        return;
      }

      Map<String, RelationType> publish = new HashMap<>();
      boolean prevBlocked = isBlocked(prev);
      boolean currBlocked = isBlocked(curr);

      if (currBlocked) {
        publish = associationDao.bulkLinkDelinkActivity(activityId, RelationType.UNLOCKED);
      } else if (prevBlocked) {
        publish = associationDao.bulkLinkDelinkActivity(activityId, RelationType.LOCKED);
      }

      if (Objects.nonNull(payload.getPage()) && curr.equalsIgnoreCase(
          ApplicationConstants.CANCELLED)) {
        pageDao.updatePageStatus(activityId, PageBlockState.DELETED);
        blockDao.updateBlockStatus(payload.getPage().getId(), PageBlockState.DELETED);
      }

      if (Objects.nonNull(publish)) {
        publish.entrySet().stream().filter(Objects::nonNull).forEach(entry -> {
          if (StringUtils.hasText(entry.getKey())) {
            publishOfferRelationAfterCommit(entry.getKey(), entry.getValue(), topic, traceId);
          } else {
            log.warn("Transition present but offerId missing. ctx={}",
                ctx(payload, topic, traceId));
          }
        });
      }
    }
  }

  // CAMPAIGN + UPDATE
  private void processCampaignUpdate(OfferEventPayloadDto payload, String activityId)
      throws BadRequestException {
    var campaign = requireNonNull(payload.getCampaign(), "payload.campaign required");
    associationDao.upsertGenericAssociation(
        activityId,
        ActivityAssociationType.CAMPAIGN,
        requireNonNull(campaign.getId(), "payload.campaign.id required"),
        null,
        campaign,
        null,
        null
    );
    activityDao.markActivityUpdatedFromCampaign(activityId, payload.getChannel());
  }

  // CAMPAIGN + DELETE
  private void processCampaignDelete(OfferEventPayloadDto payload, String activityId)
      throws BadRequestException {
    var campaign = requireNonNull(payload.getCampaign(), "payload.campaign required");
    associationDao.deleteGenericAssociation(
        activityId,
        ActivityAssociationType.CAMPAIGN,
        requireNonNull(campaign.getId(), "payload.campaign.id required"),
        null
    );
    activityDao.markActivityUpdatedFromCampaign(activityId, payload.getChannel());
  }

  // OFFER + UPDATE
  private void processOfferUpdate(OfferEventPayloadDto payload, String topic, String traceId)
      throws BadRequestException {
    associationDao.upsertOfferAssociation(payload).ifPresent(
        t -> publishOfferRelationAfterCommit(payload.getOffer().getOfferId(), t, topic, traceId)
    );
  }

  // OFFER + DELETE
  private void processOfferDelete(OfferEventPayloadDto payload, String topic, String traceId)
      throws BadRequestException {
    associationDao.deleteOfferAssociation(payload).ifPresent(
        t -> publishOfferRelationAfterCommit(payload.getOffer().getOfferId(), t, topic, traceId)
    );
  }

  // ===== Helpers =====

  private static String requireActivityId(OfferEventPayloadDto p) throws BadRequestException {
    String id = (p.getActivity() != null) ? p.getActivity().getId() : null;
    if (id == null || id.isBlank()) {
      throw new BadRequestException("activity.id required");
    }
    return id;
  }

  private boolean isBlocked(String status) {
    if (status == null) {
      return false;
    }
    return status.equalsIgnoreCase(ApplicationConstants.CANCELLED)
        || status.equalsIgnoreCase(ApplicationConstants.ON_HOLD);
  }

  private void throwOnActivityExistsCancelledOnHold(String activityId) throws BadRequestException {
    if (activityDao.activityExistsWithCancelledOrOnHold(activityId)) {
      throw new BadRequestException("Activity present with Cancelled/OnHold state: " + activityId);
    }
  }

  private void requireActivityExists(String activityId) throws BadRequestException {
    if (!activityDao.activityExists(activityId)) {
      throw new BadRequestException("Activity is not present: " + activityId);
    }
  }

  private static String ctx(OfferEventPayloadDto p, String topic, String traceId) {
    String activityId = p.getActivity() != null ? p.getActivity().getId() : null;
    String offerId = p.getOffer() != null ? p.getOffer().getOfferId() : null;
    String allocationId = p.getOffer() != null ? p.getOffer().getAllocationId() : null;
    String campaignId = p.getCampaign() != null ? p.getCampaign().getId() : null;
    return String.format(
        "type=%s op=%s activityId=%s offerId=%s alloc=%s campaignId=%s topic=%s traceId=%s",
        p.getType(), p.getOperation(), activityId, offerId, allocationId, campaignId, topic,
        traceId);
  }

  private void publishOfferRelationAfterCommit(String offerId, RelationType type, String topic,
      String traceId) {
    boolean amplified = (type == RelationType.LOCKED);

    if (!TransactionSynchronizationManager.isSynchronizationActive()) {
      log.warn("No active TX; publishing immediately. offerId={} type={} topic={} traceId={}",
          offerId, type, topic, traceId);
      try {
        publisher.publishMessage(offerId, amplified);
      } catch (Exception e) {
        log.error("Immediate publish failed. offerId={} type={} topic={} traceId={}", offerId, type,
            topic, traceId, e);
      }
      return;
    }

    TransactionSynchronizationManager.registerSynchronization(new TransactionSynchronization() {
      @Override
      public void afterCommit() {
        try {
          publisher.publishMessage(offerId, amplified);
          log.info("Published after commit: offerId={} type={} topic={} traceId={}", offerId, type,
              topic, traceId);
        } catch (Exception e) {
          log.error("Post-commit publish failed. offerId={} type={} topic={} traceId={}", offerId,
              type, topic, traceId, e);
        }
      }
    });
    log.info("Queued publish after commit: offerId={} type={} topic={} traceId={}", offerId, type,
        topic, traceId);
  }

  public void publishLockedOffers() {

    List<String> offerIds = associationDao.getAllLockedOffers();
    List<List<String>> batches = chunk(offerIds);
    List<CompletableFuture<Void>> futures = new ArrayList<>();

    for (List<String> batch : batches) {
      CompletableFuture<Void> future =
              CompletableFuture.runAsync(() -> publishBatch(batch), publishLockedOffersExecutor);

      futures.add(future);
    }

    CompletableFuture.allOf(futures.toArray(new CompletableFuture[0])).join();
  }

  private <T> List<List<T>> chunk(List<T> list) {
    if (list == null || list.isEmpty()) {
      return Collections.emptyList();
    }
    List<List<T>> chunks = new ArrayList<>();
    int size = list.size();
    for (int i = 0; i < size; i += CHUNK_SIZE) {
      chunks.add(list.subList(i, Math.min(i + CHUNK_SIZE, size)));
    }
    return chunks;
  }

  private void publishBatch(List<String> offerIds) {
    for (String offerId : offerIds) {
      try {
        log.info("Received offerId: {}", offerId);
        publisher.publishMessage(offerId, true);
      } catch (Exception e) {
        log.error("Failed to publish locked offer {}", offerId, e);
      }
    }
  }
}