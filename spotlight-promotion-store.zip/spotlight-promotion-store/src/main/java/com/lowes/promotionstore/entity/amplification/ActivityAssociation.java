package com.lowes.promotionstore.entity.amplification;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.JdbcTypeCode;
import org.hibernate.type.SqlTypes;

import java.time.LocalDateTime;

@Entity
@Table(name = "activity_associations")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ActivityAssociation {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;

  @Column(name = "activity_id", nullable = false)
  private String activityId;

  @Enumerated(EnumType.STRING)
  @Column(name = "entity_type", nullable = false, columnDefinition = "text")
  private ActivityAssociationType entityType;

  @Column(name = "entity_id", nullable = false)
  private String entityId; // offerId / campaignId / pageId / blockId

  @Column(name = "allocation_id")
  private String allocationId; // required when entityType = OFFER

  @Column(name = "page_id")
  private String pageId; // required when entityType = PAGE

  @Column(name = "block_id")
  private String blockId; // required when entityType = BLOCK

  @Enumerated(EnumType.STRING)
  @Column(name = "state", nullable = false, columnDefinition = "text")
  private AssociationState state; //

  @JdbcTypeCode(SqlTypes.JSON)
  @Column(name = "payload", columnDefinition = "jsonb")
  private String payload; // or a structured POJO serialized to JSON via JsonBinaryType

  @Column(name = "created_at", nullable = false, columnDefinition = "timestamptz")
  private LocalDateTime createdAt;

  @Column(name = "updated_at", nullable = false, columnDefinition = "timestamptz")
  private LocalDateTime updatedAt;
}

