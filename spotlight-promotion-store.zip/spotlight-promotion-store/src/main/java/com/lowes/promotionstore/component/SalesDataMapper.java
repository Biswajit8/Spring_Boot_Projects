package com.lowes.promotionstore.component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lowes.promotionstore.configuration.ObjectMapperConfig;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.model.record.spotlight.OfferSalesPayloadDto;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

@Component
@AllArgsConstructor
public class SalesDataMapper {

  private final ObjectMapperConfig objectMapper;

  public void mapOfferSalesMetrics(PromotionStore promotionStore,
      OfferSalesPayloadDto sales) throws JsonProcessingException {
    if (Objects.isNull(sales)) {
      return;
    }
    promotionStore.setId(String.valueOf(sales.offerId()));
    promotionStore.setSalesROI(setOfferSalesROI(sales));
    promotionStore.setSales(sales.sales());
    promotionStore.setIncSales(sales.netIncrSales());
    promotionStore.setSalesUnits(sales.units());
    promotionStore.setSalesIncUnits(sales.netIncrUnits());
    promotionStore.setSalesMargin(sales.margin());
    promotionStore.setSalesIncMargin(sales.netIncrMargin());
    promotionStore.setRawOfferSales(
        Objects.isNull(sales) ? null : objectMapper.objectMapper().writeValueAsString(sales));
  }

  public BigDecimal setOfferSalesROI(OfferSalesPayloadDto sales) {
    if (sales.netIncrSales() != null && sales.discount() != null
        && BigDecimal.ZERO.compareTo(sales.discount()) != 0) {

      return sales.netIncrSales().divide(sales.discount(), 4, RoundingMode.HALF_UP);
    }
    return null;
  }


}
