package com.lowes.promotionstore.listener;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lowes.model.generated.OfferProductDto;

import java.time.LocalDateTime;

public class OfferProductDtoDeserializer implements
    org.apache.kafka.common.serialization.Deserializer<OfferProductDto> {

  private final ObjectMapper mapper;

  public OfferProductDtoDeserializer() {
    mapper = new ObjectMapper();
    mapper.registerModule(new JavaTimeModule());
    mapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    mapper.configOverride(LocalDateTime.class)
        .setFormat(JsonFormat.Value.forPattern("yyyy-MM-dd HH:mm:ss"));
    mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  }

  @Override
  public OfferProductDto deserialize(String topic, byte[] data) {
    if (data == null) {
      return null;
    }
    try {
      return mapper.readValue(data, OfferProductDto.class);
    } catch (Exception e) {
      throw new org.apache.kafka.common.errors.SerializationException(
          "Failed to deserialize Offer Product", e);
    }
  }

}
