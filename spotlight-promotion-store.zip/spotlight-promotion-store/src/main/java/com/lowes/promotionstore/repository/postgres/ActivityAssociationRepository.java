package com.lowes.promotionstore.repository.postgres;

import com.lowes.promotionstore.entity.amplification.ActivityAssociation;
import com.lowes.promotionstore.entity.amplification.ActivityAssociationType;
import com.lowes.promotionstore.entity.amplification.AssociationState;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ActivityAssociationRepository extends JpaRepository<ActivityAssociation, Long> {


  @Modifying(clearAutomatically = true, flushAutomatically = true)
  @Query(value = """
      update ActivityAssociation a
      set a.state = :state,
        a.payload = :payload,
        a.updatedAt = CURRENT_TIMESTAMP
       where a.activityId = :activityId and a.entityType = :type
      """)
  int updateCampaignAssoc(@Param("activityId") String activityId,
      @Param("type") ActivityAssociationType type,
      @Param("state") AssociationState state,
      @Param("payload") String payload);

  @Query(value = """
      SELECT a.entity_id FROM activity_associations a 
      JOIN ( SELECT entity_id FROM activity_associations 
      WHERE entity_type = :type AND state = :state 
      GROUP BY entity_id HAVING COUNT(DISTINCT activity_id) = 1 ) one ON one.entity_id = a.entity_id 
      WHERE a.entity_type = :type AND a.state = :state AND a.activity_id = :activityId 
      """, nativeQuery = true)
  List<String> findExclusiveEntityIdsForActivityNative(@Param("type") String type,
      @Param("state") String state, @Param("activityId") String activityId);

  // Offer lock check: "is there any ADDED association for this offer?"
  boolean existsByEntityTypeAndEntityIdAndState(ActivityAssociationType type,
      String entityId,
      AssociationState state);

  // Exact association row (activity + entity + allocation for offers)
  Optional<ActivityAssociation> findByActivityIdAndEntityType(
      String activityId, ActivityAssociationType type);

  // Exact association row (activity + entity + allocation for offers)
  Optional<ActivityAssociation> findByActivityIdAndEntityTypeAndEntityIdAndAllocationId(
      String activityId, ActivityAssociationType type, String entityId, String allocationId);

  // Find associations by activityId, pageId and state (can return multiple)
  List<ActivityAssociation> findByActivityIdAndPageIdAndState(
      String activityId, String pageId, AssociationState state);

  // Find associations by activityId, pageId and blockId and state (can return multiple)
  List<ActivityAssociation> findByActivityIdAndPageIdAndBlockIdAndState(
      String activityId, String pageId, String blockId, AssociationState state);

  List<ActivityAssociation> findByActivityIdAndPageIdAndStateAndEntityType(
      String activityId, String id, AssociationState associationState,
      ActivityAssociationType activityAssociationType);
}

