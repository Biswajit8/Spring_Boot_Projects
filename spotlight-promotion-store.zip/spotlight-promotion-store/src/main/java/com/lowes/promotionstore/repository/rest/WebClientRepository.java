package com.lowes.promotionstore.repository.rest;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

import java.net.URI;

@Slf4j
@Component
@AllArgsConstructor
public class WebClientRepository {

  private final WebClient webClient;

  public <T> T exchange(URI url,
      HttpMethod method,
      HttpHeaders headers,
      Object body,
      ParameterizedTypeReference<T> responseType) {
    log.info(" Api Call Started {} ::: url {}", method, url);
    WebClient.RequestBodySpec requestBodySpec = webClient.method(method).uri(url).headers(
        httpHeaders -> {
          if (headers != null) {
            headers.forEach((key, values) ->
                values.forEach(value -> httpHeaders.add(key, value)));
          }
        });
    WebClient.RequestHeadersSpec<?> requestHeadersSpec;
    if (method == HttpMethod.GET || method == HttpMethod.DELETE) {
      requestHeadersSpec = requestBodySpec;
    } else {
      requestHeadersSpec = requestBodySpec.contentType(MediaType.APPLICATION_JSON)
          .body(BodyInserters.fromValue(body));
    }
    return requestHeadersSpec.accept(MediaType.APPLICATION_JSON)
        .retrieve()
        .bodyToMono(responseType)
        .block();
  }

}
