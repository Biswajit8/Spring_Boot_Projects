package com.lowes.promotionstore.component;

import com.lowes.promotionstore.model.record.micrometer.RegistryEvent;
import io.micrometer.core.instrument.MeterRegistry;
import org.springframework.stereotype.Component;


@Component
public class MicrometerEventRegister {

  private final MeterRegistry micrometerRegistry;

  public MicrometerEventRegister(MeterRegistry micrometerRegistry) {
    this.micrometerRegistry = micrometerRegistry;
  }

  public void incrementCounter(RegistryEvent event) {
    micrometerRegistry.counter(event.getEvent(),
            "source", event.getSource(),
            "message", event.getMessage())
        .increment();
  }
}

