package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record RewardGroupPayloadDto(Integer groupId, PromotionPayloadEnums.RewardTypeEnum rewardType,
                                    PromotionPayloadEnums.RewardOnEnum rewardOn,
                                    List<RewardItemAttributesPayloadDto> itemConditionAttributes,
                                    ShippingAttributesPayloadDto shippingAttributes, RewardAttributesPayloadDto rewardAttributes,
                                    FinanceAttributesPayloadDto financeAttributes) {

  public RewardGroupPayloadDto {
    if (CollectionUtils.isEmpty(itemConditionAttributes)) {
      itemConditionAttributes = new ArrayList<>();
    }
  }
}
