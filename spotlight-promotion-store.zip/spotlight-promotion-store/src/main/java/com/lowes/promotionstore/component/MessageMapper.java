package com.lowes.promotionstore.component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lowes.promotionstore.exception.constants.ErrorEnums;
import com.lowes.promotionstore.exception.types.custom.SpotlightApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Slf4j
@Component
public class MessageMapper {

  private final ObjectMapper objectMapper;

  public MessageMapper() {
    objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
    objectMapper.configOverride(LocalDateTime.class)
        .setFormat(JsonFormat.Value.forPattern("yyyy-MM-dd HH:mm:ss"));
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
  }

  public <T> T parseStringToObject(String message, Class<T> clazz) {
    try {
      T parsedObject = objectMapper.readValue(message, clazz);
      log.info("Successfully parsed message into class: {}", clazz.getSimpleName());
      return parsedObject;
    } catch (Exception e) {
      log.warn("Error while parsing the incoming message into {}: {}", clazz.getSimpleName(), message);
      throw new SpotlightApplicationException(ErrorEnums.ErrorCodeEnum.SERIALIZATION_ERROR, e);
    }
  }

}
