package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

public record OfferSalesPayloadDto(@NotNull
                                   @JsonProperty("offerId")
                                   Long offerId,

                                   @JsonProperty("sales")
                                   BigDecimal sales,

                                   @JsonProperty("grossIncrSales")
                                   BigDecimal grossIncrSales,

                                   @JsonProperty("cnbSales")
                                   BigDecimal cnbSales,

                                   @JsonProperty("pullForwardSales")
                                   BigDecimal pullForwardSales,

                                   @JsonProperty("haloSales")
                                   BigDecimal haloSales,

                                   @JsonProperty("netIncrSales")
                                   BigDecimal netIncrSales,

                                   @JsonProperty("units")
                                   BigDecimal units,

                                   @JsonProperty("grossIncrUnits")
                                   BigDecimal grossIncrUnits,

                                   @JsonProperty("cnbUnits")
                                   BigDecimal cnbUnits,

                                   @JsonProperty("pullForwardUnits")
                                   BigDecimal pullForwardUnits,

                                   @JsonProperty("haloUnits")
                                   BigDecimal haloUnits,

                                   @JsonProperty("netIncrUnits")
                                   BigDecimal netIncrUnits,

                                   @JsonProperty("margin")
                                   BigDecimal margin,

                                   @JsonProperty("grossIncrMargin")
                                   BigDecimal grossIncrMargin,

                                   @JsonProperty("cnbMargin")
                                   BigDecimal cnbMargin,

                                   @JsonProperty("pullForwardMargin")
                                   BigDecimal pullForwardMargin,

                                   @JsonProperty("haloMargin")
                                   BigDecimal haloMargin,

                                   @JsonProperty("netIncrMargin")
                                   BigDecimal netIncrMargin,

                                   @JsonProperty("discount")
                                   BigDecimal discount,

                                   @JsonProperty("baselineSales")
                                   BigDecimal baselineSales,

                                   @JsonProperty("baselineUnits")
                                   BigDecimal baselineUnits,

                                   @JsonProperty("baselineMargin")
                                   BigDecimal baselineMargin,

                                   @JsonProperty("baselineSalesRegion")
                                   BigDecimal baselineSalesRegion,

                                   @JsonProperty("baselineUnitsRegion")
                                   BigDecimal baselineUnitsRegion,

                                   @JsonProperty("baselineMarginRegion")
                                   BigDecimal baselineMarginRegion,

                                   @JsonProperty("createdTs")
                                   String createdTs,

                                   @JsonProperty("modifiedTs")
                                   String modifiedTs) {

}
