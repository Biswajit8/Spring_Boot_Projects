package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonInclude;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@SuppressWarnings("java:S1068")
@JsonInclude(JsonInclude.Include.NON_NULL)
public record MarketingInfoPayloadDto(Boolean marketingEligible,
                                      TopOfferInfoPayloadDto topOfferInfo, List<String> offerIntent,
                                      SalesProjectionPayloadDto salesProjection,
                                      Set<FeatureCatalogItemPayloadDto> featuredItems,
                                      Boolean dealOfTheDay) {

  public MarketingInfoPayloadDto {
    if (CollectionUtils.isEmpty(offerIntent)) {
      offerIntent = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(featuredItems)) {
      featuredItems = new HashSet<>();
    }
  }
}
