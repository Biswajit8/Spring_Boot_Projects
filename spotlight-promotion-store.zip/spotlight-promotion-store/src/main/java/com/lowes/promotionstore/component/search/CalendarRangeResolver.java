package com.lowes.promotionstore.component.search;

import com.lowes.promotionstore.constants.enums.CalendarUnitType;
import com.lowes.promotionstore.model.coredata.FiscalCalendarDto;
import com.lowes.promotionstore.service.coredata.CalendarService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

@Component
@Slf4j
public class CalendarRangeResolver {

  private final CalendarService calendarService;

  public CalendarRangeResolver(CalendarService calendarService) {
    this.calendarService = calendarService;
  }

  public List<String> getPromoWeeksForDateRange(LocalDate from, LocalDate to) {
    List<FiscalCalendarDto> cached = calendarService.getCachedWeeks();
    if (from == null || to == null || cached == null || cached.isEmpty()) {
      return Collections.emptyList();
    }

    Set<String> result = new LinkedHashSet<>();
    for (FiscalCalendarDto f : cached) {
      if (f == null || f.getStartDate() == null || f.getEndDate() == null) {
        continue;
      }
      if (f.getCalendarUnitType() != CalendarUnitType.PROMO_WEEK
          && f.getCalendarUnitType() != CalendarUnitType.FISCAL_WEEK) {
        continue;
      }
      LocalDate start = f.getStartDate();
      LocalDate end = f.getEndDate();

      if (!(to.isBefore(start) || from.isAfter(end))) {
        Integer weekId = f.getWeekId();
        Integer promoYear = f.getPromoYear();
        if (weekId != null && promoYear != null) {
          result.add(String.format("PW%d-%d", weekId, promoYear));
        }
      }
    }

    return new ArrayList<>(result);
  }

  public List<String> getFiscalQuartersForDateRange(LocalDate from, LocalDate to) {
    List<FiscalCalendarDto> cached = calendarService.getCachedWeeks();
    if (from == null || to == null || cached == null || cached.isEmpty()) {
      return Collections.emptyList();
    }

    Set<String> result = new LinkedHashSet<>();
    for (FiscalCalendarDto f : cached) {
      if (f == null || f.getStartDate() == null || f.getEndDate() == null) {
        continue;
      }
      if (f.getCalendarUnitType() != CalendarUnitType.FISCAL_QUARTER) {
        continue;
      }
      LocalDate start = f.getStartDate();
      LocalDate end = f.getEndDate();

      if (!(to.isBefore(start) || from.isAfter(end))) {
        Integer quarter = f.getFiscalQuarter();
        Integer fiscalYear = f.getFiscalYear();
        if (quarter != null && fiscalYear != null) {
          result.add(String.format("Q%d-%d", quarter, fiscalYear));
        }
      }
    }

    return new ArrayList<>(result);
  }
}
