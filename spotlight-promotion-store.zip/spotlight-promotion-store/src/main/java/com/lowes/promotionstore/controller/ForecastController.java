package com.lowes.promotionstore.controller;

import com.lowes.promotionstore.model.record.spotlight.ForecastDataDto;
import com.lowes.promotionstore.service.ForecastService;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;

@RestController
@RequestMapping("/forecast")
@AllArgsConstructor
public class ForecastController {

  private final ForecastService forecastService;

  @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation = ForecastDataDto.class)))
  @ApiResponse(responseCode = "400", content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  @ApiResponse(responseCode = "500", content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  @PostMapping(value = "/merge", consumes = APPLICATION_JSON_VALUE, produces = APPLICATION_JSON_VALUE)
  public ResponseEntity<String> mergeForecastData(
      @Valid @RequestBody ForecastDataDto forecastData) {

    String promotionId = forecastService.saveForecastData(
        forecastData);
    if (StringUtils.hasText(promotionId)) {
      return ResponseEntity.ok(promotionId);
    }
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
  }
}