package com.lowes.promotionstore.controller;

import com.lowes.promotionstore.model.record.spotlight.OfferSalesPayloadDto;
import com.lowes.promotionstore.service.OfferSalesMatrixService;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.ErrorResponse;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/offer-sales")
@AllArgsConstructor
public class OfferSalesMetricsController {

  private final OfferSalesMatrixService offerSalesMatrixService;

  @ApiResponse(responseCode = "200", content = @Content(schema = @Schema(implementation = OfferSalesPayloadDto.class)))
  @ApiResponse(responseCode = "400", content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  @ApiResponse(responseCode = "500", content = @Content(schema = @Schema(implementation = ErrorResponse.class)))
  @PostMapping(value = "/merge", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
  public ResponseEntity<String> mergeOfferSalesData(
      @Valid @RequestBody OfferSalesPayloadDto offerSales) {
    String offerId = offerSalesMatrixService.saveOfferSalesMetrics(offerSales);
    if (StringUtils.hasText(offerId)) {
      return ResponseEntity.ok(offerId);
    }
    return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
  }

}
