package com.lowes.promotionstore.component;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class MemoryMetrics {

  private String operation;
  private int payloadCount;
  private long heapUsed;
  private long heapMax;
  private double heapUsagePercent;
  private long freeMemory;
  private long nonHeapUsed;
  private long timestamp;
}
