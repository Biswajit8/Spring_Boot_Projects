package com.lowes.promotionstore.entity.spotlight;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;

public enum PromotionJsonField {

  id,
  name,
  offer_type,
  offer_type_name,
  offer_sub_type,
  offer_sub_type_name,
  offer_tactic,
  active,
  activated_by,
  activated_ts,
  indexed_ts,
  auto_apply_code,
  calendar_week,
  coupon_code,
  created_by,
  created_ts,
  modified_ts,
  modified_by,
  deactivated_ts,
  deactivated_by,
  customer_type,
  no_end_date,
  offer_type_id,
  patches,
  promo_tracker_link,
  redemption_type,
  start_date,
  end_date,
  blackout_date,
  status,
  stores,
  sub_divisions,
  divisions,
  include_all_stores,
  patch_offer,
  event_ids,
  market_scope,
  loyalties_tier_name,
  loyalties_tier_id,
  include_brand_ids,
  include_brand_names,
  include_pcrs,
  include_digital_taxonomy_ids,
  include_digital_taxonomy_names,
  include_merch_bucket_ids,
  include_merch_bucket_names,
  include_product_types,
  include_items,
  exclude_brand_ids,
  exclude_brand_names,
  exclude_digital_taxonomy_ids,
  exclude_digital_taxonomy_names,
  exclude_merch_bucket_ids,
  exclude_merch_bucket_names,
  exclude_product_types,
  exclude_items,
  conditionGroups_item_catalog_ref,
  conditiongroups_item_quantity,
  conditiongroups_item_spend,
  conditiongroups_condition_on,
  conditiongroups_condition_type,
  conditiongroups_purchase_mode,
  conditiongroups_discount_type,
  rewardgroups_reward_type,
  rewardgroups_reward_on,
  rewardgroups_shipping_category,
  rewardgroups_shipping_type,
  rewardgroups_shipping_shipping_method,
  rewardGroups_shipping_fulfillmenttype,
  rewardGroups_item_quantity,
  rewardGroups_item_spend,
  rewardGroups_item_catalog_ref,
  rewardGroups_finance_months,
  rewardGroups_finance_type,
  rewardgroups_finance_term_identifier,
  rewardgroups_finance_term_type,
  rewardGroups_finance_blockcode,
  rewardgroups_finance_annual_percent_rate,
  reward_attribute_quantity,
  reward_attribute_quantity_value,
  reward_attribute_discount_type,
  reward_attribute_discount_on,
  reward_attribute_discount_value,
  raw_offer,
  raw_offer_forecast,
  raw_offer_sales,
  featured_items,
  version,
  top_offer,
  door_buster,
  source_system;

  @JsonValue
  public String value() {
    return name();
  }

  @JsonCreator
  public static PromotionJsonField from(String v) {
    try {
      return PromotionJsonField.valueOf(v);
    } catch (IllegalArgumentException ex) {
      return null; // or throw if you prefer strict handling
    }
  }
}

