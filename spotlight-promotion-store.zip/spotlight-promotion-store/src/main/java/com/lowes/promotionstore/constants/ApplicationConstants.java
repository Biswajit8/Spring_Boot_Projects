package com.lowes.promotionstore.constants;

import java.util.List;

public class ApplicationConstants {

  private ApplicationConstants() {
  }

  public static final Integer DIVISION_APPLIANCES = 37;

  public static final String MESSAGE_TYPE = "x-message-type";
  public static final String FULL_LOAD_TYPE = "FULL";
  public static final String OFFER_PRODUCT_LISTENER = "offer-product-listener";
  public static final String OFFER_EVENT_LISTENER = "offer-event-listener";
  public static final int MAX_CHUNK_SIZE = 100;
  public static final String CANCELLED = "Cancelled";
  public static final String ON_HOLD = "On-Hold";
  public static final String ACTIVITY = "ACTIVITY";
  public static final String UPDATE = "UPDATE";
  public static final String FORECAST_UNSUPPORTED_INDICATOR = "NOT_SUPPORTED";
  public static final List<Long> NDO_OFFER_TYPES = List.of(105L);
  public static final List<Long> CLEARANCE_OFFER_TYPES = List.of(15L);
  public static final List<Long> SPR_OFFER_TYPES = List.of(103L, 12L);

}
