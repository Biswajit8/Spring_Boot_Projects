package com.lowes.promotionstore.repository.es;

import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;

public interface SpotlightPromoStoreRepository extends
    ElasticsearchRepository<PromotionStore, String> {

}
