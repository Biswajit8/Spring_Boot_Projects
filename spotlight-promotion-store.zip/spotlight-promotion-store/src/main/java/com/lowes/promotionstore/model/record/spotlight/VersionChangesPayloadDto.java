package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@SuppressWarnings("java:S1068")
@JsonInclude(JsonInclude.Include.NON_NULL)
public record VersionChangesPayloadDto(
    List<String> sections,
    List<String> promotionSections,
    List<String> forecastSections,
    List<String> marketingSections
) {

}
