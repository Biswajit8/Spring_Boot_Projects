package com.lowes.promotionstore.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lowes.promotionstore.component.ForecastDataMapper;
import com.lowes.promotionstore.component.MicrometerEventRegister;
import com.lowes.promotionstore.component.PartialMapBuilders;
import com.lowes.promotionstore.entity.spotlight.PromotionJsonField;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.entity.spotlight.SalesEnums.ForecastSearchEnum;
import com.lowes.promotionstore.exception.constants.ErrorEnums;
import com.lowes.promotionstore.exception.constants.ErrorEnums.ErrorCodeEnum;
import com.lowes.promotionstore.model.record.micrometer.RegistryEvent;
import com.lowes.promotionstore.model.record.spotlight.ForecastDataDto;
import com.lowes.promotionstore.repository.dao.SpotlightPromoStoreElasticSearchDao;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ForecastService {

  private static final String FORECAST_DATA_SOURCE = "forecastData_merge_api";
  private final ForecastDataMapper forecastDataMapper;
  private final SpotlightPromoStoreElasticSearchDao spotlightPromoStoreElasticSearchDao;
  private final PartialMapBuilders partialMapBuilders;
  private final MicrometerEventRegister registryService;
  private static final String COMMON_REGISTRY_EVENT = "promotion_document_missing_in_elastic_index";


  public String saveForecastData(ForecastDataDto forecastData) {
    String registryEventName = "forecastData_process_failure";
    if (Objects.isNull(forecastData)) {
      log.error("Forecast data not saved, Forecast is null");
      registryService.incrementCounter(RegistryEvent.builder()
          .event(COMMON_REGISTRY_EVENT)
          .source(FORECAST_DATA_SOURCE)
          .message(ErrorCodeEnum.MISSING_DOCUMENT.getMessage())
          .build());
      return null;
    }

    try {
      PromotionStore updatedPromotionStore = new PromotionStore();
      forecastDataMapper.mapForecastData(updatedPromotionStore, forecastData);

      Set<String> eligibleFields = Arrays.stream(ForecastSearchEnum.values())
          .map(ForecastSearchEnum::name).collect(Collectors.toSet());
      eligibleFields.add(PromotionJsonField.id.name());

      Map<String, Object> nonNullValues = partialMapBuilders.from(updatedPromotionStore).dropNulls()
          .include(eligibleFields).build();
      spotlightPromoStoreElasticSearchDao.upsertPartial(updatedPromotionStore, nonNullValues);
      log.info("Forecast data saved for PromotionId {}", forecastData.promotionId());
      return updatedPromotionStore.getId();
    } catch (JsonProcessingException e) {
      log.error(
          "JsonProcessingException caught while saving or updating forecast data to Promotion Store {}",
          e.getMessage());
      registryService.incrementCounter(RegistryEvent.builder()
          .event(registryEventName)
          .source(FORECAST_DATA_SOURCE)
          .message(ErrorCodeEnum.PARSING_FAILURE.getMessage())
          .build());
    } catch (Exception e) {
      log.error("Exception caught while saving or updating forecast data to Promotion Store {}",
          e.getMessage());
      registryService.incrementCounter(RegistryEvent.builder()
          .event(registryEventName)
          .source(FORECAST_DATA_SOURCE)
          .message(ErrorCodeEnum.PARSING_FAILURE.getMessage())
          .build());
    }
    return null;
  }

}
