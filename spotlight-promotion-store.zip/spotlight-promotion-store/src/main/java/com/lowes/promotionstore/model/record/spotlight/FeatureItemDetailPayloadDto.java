package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Set;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record FeatureItemDetailPayloadDto(String itemNo, String vendorNo, String modelNo,
                                          Set<String> patches, Set<String> stores) {

}
