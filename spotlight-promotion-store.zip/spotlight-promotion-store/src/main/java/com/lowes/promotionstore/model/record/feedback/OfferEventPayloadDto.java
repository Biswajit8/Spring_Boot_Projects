package com.lowes.promotionstore.model.record.feedback;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor

@JsonIgnoreProperties(ignoreUnknown = true)

@JsonInclude(JsonInclude.Include.NON_NULL)

public class OfferEventPayloadDto {

  private String id;

  private String type;

  private String operation;

  private String channel;

  private CampaignPayloadDto campaign;

  private ActivityPayloadDto activity;

  private PagePayloadDto page;

  private BlockPayloadDto block;

  private OfferDto offer;

}












