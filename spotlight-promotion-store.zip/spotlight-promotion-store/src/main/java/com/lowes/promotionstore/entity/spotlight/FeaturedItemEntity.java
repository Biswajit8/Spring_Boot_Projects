package com.lowes.promotionstore.entity.spotlight;

import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.util.Set;

public record FeaturedItemEntity(
    @JsonProperty("item_no")
    @Field(type = FieldType.Keyword, name = "item_no")
    String itemNo,
    @JsonProperty("vendor_no")
    @Field(type = FieldType.Keyword, name = "vendor_no")
    String vendorNo,
    @JsonProperty("model_no")
    @Field(type = FieldType.Keyword, name = "model_no")
    String modelNo,
    @JsonProperty("patches")
    @Field(type = FieldType.Keyword, name = "patches")
    Set<String> patches,
    @JsonProperty("stores")
    @Field(type = FieldType.Keyword, name = "stores")
    Set<String> stores) {

}
