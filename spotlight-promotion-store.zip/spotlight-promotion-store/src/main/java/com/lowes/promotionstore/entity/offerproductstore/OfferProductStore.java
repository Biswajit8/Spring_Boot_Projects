package com.lowes.promotionstore.entity.offerproductstore;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.DateFormat;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;
import org.springframework.util.StringUtils;

import java.time.Instant;
import java.util.List;

@Document(indexName = "offer-product-store")
@JsonInclude(JsonInclude.Include.NON_NULL)
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class OfferProductStore {

  @Id
  @JsonProperty("id")
  private String id;

  @JsonProperty("omni_item_id")
  @Field(type = FieldType.Keyword, name = "omni_item_id")
  private String omniItemId;

  @JsonProperty("item_number")
  @Field(type = FieldType.Keyword, name = "item_number")
  private String itemNumber;

  @JsonProperty("vendor_number")
  @Field(type = FieldType.Keyword, name = "vendor_number")
  private String vendorNumber;

  @JsonProperty("model_id")
  @Field(type = FieldType.Keyword, name = "model_id")
  private String modelId;

  @JsonProperty("product_type")
  @Field(type = FieldType.Keyword, name = "product_type")
  private String productType;

  @JsonProperty("assortment_id")
  @Field(type = FieldType.Keyword, name = "assortment_id")
  private String assortmentId;

  @JsonProperty("product_group_id")
  @Field(type = FieldType.Keyword, name = "product_group_id")
  private String productGroupId;

  @JsonProperty("subdivision_id")
  @Field(type = FieldType.Keyword, name = "subdivision_id")
  private String subdivisionId;

  @JsonProperty("division_id")
  @Field(type = FieldType.Keyword, name = "division_id")
  private String divisionId;

  @JsonProperty("business_area_id")
  @Field(type = FieldType.Keyword, name = "business_area_id")
  private String businessAreaId;

  @JsonProperty("brand_id")
  @Field(type = FieldType.Keyword, name = "brand_id")
  private String brandId;

  @JsonProperty("program_type")
  @Field(type = FieldType.Keyword, name = "program_type")
  private String programType;

  @JsonProperty("store_eligible")
  @Field(type = FieldType.Boolean, name = "store_eligible")
  private Boolean storeEligible;

  @JsonProperty("is_published")
  @Field(type = FieldType.Keyword, name = "is_published")
  private String isPublished;

  @JsonProperty("is_buyable")
  @Field(type = FieldType.Keyword, name = "is_buyable")
  private String isBuyable;

  @JsonProperty("product_status")
  @Field(type = FieldType.Boolean, name = "product_status")
  private Boolean productStatus;

  @JsonProperty("status")
  @Field(type = FieldType.Keyword, name = "status")
  private String status;

  @JsonProperty("merch_bucket_ids")
  @Field(type = FieldType.Keyword, name = "merch_bucket_ids")
  private List<String> merchBucketIds;

  @JsonProperty("digital_taxonomy_ids")
  @Field(type = FieldType.Keyword, name = "digital_taxonomy_ids")
  private List<String> digitalTaxonomyIds;

  @JsonProperty("child_items")
  @Field(type = FieldType.Nested, name = "child_items")
  private List<ChildItemDto> childItems;

  @JsonProperty("indexed_ts")
  @Field(type = FieldType.Date, format = DateFormat.date_time, name = "indexed_ts")
  private Instant indexedTs;

  @JsonInclude(JsonInclude.Include.NON_NULL)
  @Builder
  public static class ChildItemDto {

    @JsonProperty("vbu")
    @Field(type = FieldType.Keyword, name = "vbu")
    private String vbu;

    @JsonProperty("model_id")
    @Field(type = FieldType.Keyword, name = "model_id")
    private String modelId;

    @JsonProperty("item_number")
    @Field(type = FieldType.Keyword, name = "item_number")
    private String itemNumber;

    @JsonProperty("omni_item_id")
    @Field(type = FieldType.Keyword, name = "omni_item_id")
    private String omniItemId;

  }

  public void generateId() {
    if (!StringUtils.hasText(modelId) && !StringUtils.hasText(vendorNumber)) {
      this.id = itemNumber;
    } else {
      this.id = itemNumber + "_" + vendorNumber + "_" + modelId;
    }
  }

}
