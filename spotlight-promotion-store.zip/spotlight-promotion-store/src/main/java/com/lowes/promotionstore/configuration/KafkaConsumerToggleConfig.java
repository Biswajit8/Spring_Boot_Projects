package com.lowes.promotionstore.configuration;

import lombok.Getter;
import lombok.Setter;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@SuppressWarnings("java:S1068")
@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "application")
@Scope(ConfigurableBeanFactory.SCOPE_SINGLETON)
public class KafkaConsumerToggleConfig {

  private boolean enableFullLoadConsumer = Boolean.FALSE;
  private boolean enableAdapterConsumer = Boolean.TRUE;
  private boolean enableOfferProductConsumer = Boolean.TRUE;
  private boolean enableFeedback = Boolean.TRUE;
  private boolean enableOfferEventsConsumer = Boolean.FALSE;
}

