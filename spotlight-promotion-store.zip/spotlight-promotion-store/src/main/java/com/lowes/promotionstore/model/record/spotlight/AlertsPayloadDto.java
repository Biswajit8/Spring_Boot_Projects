package com.lowes.promotionstore.model.record.spotlight;

public record AlertsPayloadDto(boolean hasError, boolean hasWarning) {

}
