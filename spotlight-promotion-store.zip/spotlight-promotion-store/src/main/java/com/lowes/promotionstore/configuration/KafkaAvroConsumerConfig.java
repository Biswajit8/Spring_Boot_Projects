package com.lowes.promotionstore.configuration;

import com.lowes.generated.model.offerevent.OfferEventPublishDto;
import com.lowes.genie.avro.outboundEvent.OutboundEvent;
import com.lowes.model.generated.OfferProductDto;
import com.lowes.promotionstore.configuration.properties.KafkaProps;
import com.lowes.promotionstore.configuration.properties.KafkaProps.ConsumerSpec;
import com.lowes.promotionstore.listener.OfferEventDeserializer;
import io.confluent.kafka.serializers.AbstractKafkaSchemaSerDeConfig;
import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.util.StringUtils;
import org.springframework.util.backoff.FixedBackOff;

import java.util.HashMap;
import java.util.Map;

import static org.springframework.kafka.listener.ContainerProperties.AckMode.MANUAL_IMMEDIATE;

@EnableKafka
@Configuration
@Slf4j
public class KafkaAvroConsumerConfig {

  private final KafkaProps kafkaProps;

  public KafkaAvroConsumerConfig(KafkaProps kafkaProps) {
    this.kafkaProps = kafkaProps;
  }

  @ConditionalOnProperty(
      prefix = "application.kafka.consumer.offerEventsListener",
      name = "enabled",
      havingValue = "true",
      matchIfMissing = true
  )
  @Bean(name = "offerEventConsumer")
  public ConcurrentKafkaListenerContainerFactory<String, OfferEventPublishDto> spotlightOfferEventListener() {
    var spec = kafkaProps.getConsumer().getOfferEventsListener();
    var props = getConsumerConfig(spec, false);

    // Configure error handling deserializers
    configureErrorHandlingDeserializers(props, StringDeserializer.class,
        OfferEventDeserializer.class);

    ConcurrentKafkaListenerContainerFactory<String, OfferEventPublishDto> factory = createBaseContainerFactory(
        props, spec);
    factory.setCommonErrorHandler(errorHandlerAvro());
    return factory;
  }

  // ========= offer-product (Avro, SpecificRecord) =========
  @Bean(name = "offerProductConsumer")
  public ConcurrentKafkaListenerContainerFactory<String, OfferProductDto> offerProductKafkaListenerContainerFactory() {
    var spec = kafkaProps.getConsumer().getOfferProductListener();
    var props = getConsumerConfig(spec, false);

    // Configure Avro deserializers
    props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
    props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class);

    ConcurrentKafkaListenerContainerFactory<String, OfferProductDto> factory = createBaseContainerFactory(
        props, spec);
    factory.setCommonErrorHandler(errorHandlerAvro());
    return factory;
  }


  // ===== Offer feedback (on-prem user) =====
  @Bean(name = "offerFeedbackConsumer")
  public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, OutboundEvent>> offerFeedbackListener() {
    var spec = kafkaProps.getConsumer().getOfferFeedbackListener();
    var props = new HashMap<>(getConsumerConfig(spec, false));

    // Override bootstrap servers for on-prem
    props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,
        kafkaProps.getDefaults().getBootstrapServerOnprem());

    // Configure Avro deserializers
    props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
    props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, KafkaAvroDeserializer.class);

    ConcurrentKafkaListenerContainerFactory<String, OutboundEvent> factory = createBaseContainerFactory(
        props, spec);
    factory.setBatchListener(false);
    factory.setCommonErrorHandler(errorHandlerAvro());
    return factory;
  }

  @Bean
  public DefaultErrorHandler errorHandlerAvro() {
    return new DefaultErrorHandler(
        (record, exception) -> log.warn("""
            Deserialization error: {}
            """, exception.getMessage(), exception),
        new FixedBackOff(0, 0)
    );
  }

  /**
   * Build Avro consumer props; wraps delegates with ErrorHandlingDeserializer and sets SR config.
   */
  private Map<String, Object> getConsumerConfig(ConsumerSpec spec, boolean useOnPremUser) {
    var props = new HashMap<>(commonConfigs(useOnPremUser));

    // Basic consumer configuration
    props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,
        kafkaProps.getDefaults().getBootstrapServers());
    props.put(ConsumerConfig.GROUP_ID_CONFIG, spec.getGroupId());

    // Schema registry configuration
    configureSchemaRegistry(props);

    // Avro-specific configuration
    props.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, true);

    // Offset/commit behavior
    configureOffsetReset(props, spec);

    // Additional properties from YAML
    if (spec.getProperties() != null) {
      props.putAll(spec.getProperties());
    }

    return props;
  }

  private Map<String, Object> commonConfigs(boolean useOnPremUser) {
    var configs = new HashMap<String, Object>();

    // Security configuration
    configs.put("security.protocol", kafkaProps.getSecurityProtocol());
    configs.put("ssl.truststore.location", kafkaProps.getTrustStoreLocation());
    configs.put("ssl.truststore.password", kafkaProps.getTrustStorePassword());
    configs.put("sasl.mechanism", kafkaProps.getSaslMechanism());
    configs.put("ssl.endpoint.identification.algorithm", ""); // keep as-is

    // SASL authentication
    var credentials = getUserCredentials(useOnPremUser);
    configs.put("sasl.jaas.config",
        createJaasConfig(credentials.getUsername(), credentials.getPassword()));

    return configs;
  }

  private static String createJaasConfig(String username, String password) {
    return """
        org.apache.kafka.common.security.scram.ScramLoginModule required 
        username="%s" 
        password="%s";
        """.formatted(username, password);
  }

  // ========= Helper methods =========

  private void configureErrorHandlingDeserializers(
      Map<String, Object> props,
      Class<?> keyDelegateClass,
      Class<?> valueDelegateClass
  ) {
    props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class);
    props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class);
    props.put("spring.deserializer.key.delegate.class", keyDelegateClass);
    props.put("spring.deserializer.value.delegate.class", valueDelegateClass);
  }

  private void configureSchemaRegistry(Map<String, Object> props) {
    var schemaRegistryUrl = kafkaProps.getDefaults().getSchemaRegistryUrl();
    if (StringUtils.hasText(schemaRegistryUrl)) {
      props.put(AbstractKafkaSchemaSerDeConfig.SCHEMA_REGISTRY_URL_CONFIG, schemaRegistryUrl);
      props.put("schema.registry.ssl.truststore.location", kafkaProps.getTrustStoreLocation());
      props.put("schema.registry.ssl.truststore.password", kafkaProps.getTrustStorePassword());
    }
  }

  private void configureOffsetReset(Map<String, Object> props, ConsumerSpec spec) {
    if (StringUtils.hasText(spec.getAutoOffsetReset())) {
      props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, spec.getAutoOffsetReset());
    }
  }

  private KafkaProps.SaslCredentials.UserCredentials getUserCredentials(boolean useOnPremUser) {
    return useOnPremUser
        ? kafkaProps.getSaslCredentials().getOnPremUser()
        : kafkaProps.getSaslCredentials().getSpotlightUser();
  }

  private <T> ConcurrentKafkaListenerContainerFactory<String, T> createBaseContainerFactory(
      Map<String, Object> props,
      ConsumerSpec spec
  ) {
    var factory = new ConcurrentKafkaListenerContainerFactory<String, T>();
    factory.setConcurrency(spec.getConcurrency());
    factory.setConsumerFactory(new DefaultKafkaConsumerFactory<>(props));
    factory.setBatchListener(true);
    props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
    factory.getContainerProperties().setAckMode(MANUAL_IMMEDIATE);
    return factory;
  }
}
