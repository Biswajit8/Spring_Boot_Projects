package com.lowes.promotionstore.component;

import com.lowes.model.generated.OfferProductDto;
import com.lowes.promotionstore.entity.offerproductstore.OfferProductStore;
import com.lowes.promotionstore.entity.offerproductstore.OfferProductStore.ChildItemDto;
import org.springframework.stereotype.Component;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@Component
public class OfferProductMapper {

  public List<OfferProductStore> createItemEntities(Set<OfferProductDto> consumerRecordDelta) {
    List<OfferProductStore> offerProductEntities = new ArrayList<>();
    consumerRecordDelta.forEach(offerProductDto -> {
      OfferProductStore offerProduct = new OfferProductStore();
      offerProduct.setOmniItemId(Optional.ofNullable(offerProductDto.getOmniItemId())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setItemNumber(Optional.ofNullable(offerProductDto.getItemNumber())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setModelId(Optional.ofNullable(offerProductDto.getModelId())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setVendorNumber(Optional.ofNullable(offerProductDto.getVendorNumber())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setProductType(Optional.ofNullable(offerProductDto.getProductType())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setAssortmentId(Optional.ofNullable(offerProductDto.getAssortmentId())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setProductGroupId(Optional.ofNullable(offerProductDto.getProductGroupId())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setSubdivisionId(Optional.ofNullable(offerProductDto.getSubdivisionId())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setDivisionId(Optional.ofNullable(offerProductDto.getDivisionId())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setBusinessAreaId(Optional.ofNullable(offerProductDto.getBusinessAreaId())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setBrandId(Optional.ofNullable(offerProductDto.getBrandId())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setProgramType(Optional.ofNullable(offerProductDto.getProgramType())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setIsPublished(Optional.ofNullable(offerProductDto.getIsPublished())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setIsBuyable(Optional.ofNullable(offerProductDto.getIsBuyable())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setProductStatus(offerProductDto.getProductStatus());
      offerProduct.setStatus(Optional.ofNullable(offerProductDto.getStatus())
          .map(CharSequence::toString)
          .orElse(null));
      offerProduct.setMerchBucketIds(offerProductDto.getMerchBucketIds().stream()
          .map(charSeq -> charSeq != null ? charSeq.toString() : null)
          .toList());
      offerProduct.setDigitalTaxonomyIds(offerProductDto.getDigitalTaxonomyIds().stream()
          .map(charSeq -> charSeq != null ? charSeq.toString() : null)
          .toList());
      offerProduct.setChildItems(
          Optional.ofNullable(offerProductDto.getChildItems()).orElse(new ArrayList<>()).stream()
              .map(childItemDto -> ChildItemDto.builder()
                  .vbu(
                      Optional.ofNullable(childItemDto.getVbu())
                          .map(CharSequence::toString)
                          .orElse(null))
                  .itemNumber(
                      Optional.ofNullable(childItemDto.getItemNumber())
                          .map(CharSequence::toString)
                          .orElse(null))
                  .modelId(
                      Optional.ofNullable(childItemDto.getModelId())
                          .map(CharSequence::toString)
                          .orElse(null))
                  .omniItemId(
                      Optional.ofNullable(childItemDto.getOmniItemId())
                          .map(CharSequence::toString)
                          .orElse(null))
                  .build())
              .toList());
      offerProduct.setIndexedTs(Instant.now());
      offerProduct.generateId();
      offerProductEntities.add(offerProduct);

    });
    return offerProductEntities;
  }
}

