package com.lowes.promotionstore.configuration;

import com.lowes.promotionstore.configuration.properties.KafkaProps;
import com.lowes.promotionstore.configuration.properties.KafkaProps.ConsumerSpec;
import com.lowes.promotionstore.listener.SpotlightOfferPayloadDtoDeserializer;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import lombok.extern.slf4j.Slf4j;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.KafkaListenerContainerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ConcurrentMessageListenerContainer;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.util.StringUtils;
import org.springframework.util.backoff.FixedBackOff;

import java.util.HashMap;
import java.util.Map;

import static org.springframework.kafka.listener.ContainerProperties.AckMode.MANUAL_IMMEDIATE;

@EnableKafka
@Configuration
@Slf4j
public class KafkaConsumerConfig {

  private final KafkaProps kafkaProps;

  public KafkaConsumerConfig(KafkaProps kafkaProps) {
    this.kafkaProps = kafkaProps;
  }

  // ===== Spotlight full-load (spotlight user) =====
  @Bean(name = "fullLoadConsumer")
  public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, SpotlightOfferPayloadDto>> fullLoadListener() {
    var spec = kafkaProps.getConsumer().getSpotlightPromotionFullLoadListener();
    var props = new HashMap<>(getConsumerConfig(spec, false));

    configureErrorHandlingDeserializers(props, SpotlightOfferPayloadDtoDeserializer.class);

    ConcurrentKafkaListenerContainerFactory<String, SpotlightOfferPayloadDto> factory = createBaseContainerFactory(
        props, spec);
    factory.setCommonErrorHandler(errorHandler());
    return factory;
  }

  // ===== Spotlight incremental (spotlight user) =====
  @Bean(name = "spotlightConsumer")
  public KafkaListenerContainerFactory<ConcurrentMessageListenerContainer<String, SpotlightOfferPayloadDto>> spotlightListener() {
    var spec = kafkaProps.getConsumer().getSpotlightPromotionListener();
    var props = new HashMap<>(getConsumerConfig(spec, false));

    configureErrorHandlingDeserializers(props, SpotlightOfferPayloadDtoDeserializer.class);

    ConcurrentKafkaListenerContainerFactory<String, SpotlightOfferPayloadDto> factory = createBaseContainerFactory(
        props, spec);
    factory.setCommonErrorHandler(errorHandler());
    return factory;
  }

  private Map<String, Object> getConsumerConfig(ConsumerSpec spec, boolean useOnPremUser) {
    var props = new HashMap<>(commonConfigs(useOnPremUser));

    // Basic configuration
    props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,
        kafkaProps.getDefaults().getBootstrapServers());
    props.put(ConsumerConfig.GROUP_ID_CONFIG, spec.getGroupId());

    // Use deserializers from YAML (EHD or real), do NOT wrap again here
    props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, spec.getKeyDeserializer());
    props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, spec.getValueDeserializer());

    // Offset and commit configuration
    configureOffsetAndCommitBehavior(props, spec);

    // Merge YAML properties (delegates, spring.json.*, etc.)
    if (spec.getProperties() != null) {
      props.putAll(spec.getProperties());
    }
    return props;
  }


  private Map<String, Object> commonConfigs(boolean useOnPremUser) {
    var configs = new HashMap<String, Object>();

    // Security configuration
    configs.put("security.protocol", kafkaProps.getSecurityProtocol());
    configs.put("ssl.truststore.location", kafkaProps.getTrustStoreLocation());
    configs.put("ssl.truststore.password", kafkaProps.getTrustStorePassword());
    configs.put("sasl.mechanism", kafkaProps.getSaslMechanism());
    // Consider setting to "HTTPS" in prod to enable hostname verification
    configs.put("ssl.endpoint.identification.algorithm", "");

    // SASL authentication
    var credentials = getUserCredentials(useOnPremUser);
    configs.put("sasl.jaas.config",
        createJaasConfig(credentials.getUsername(), credentials.getPassword()));
    return configs;
  }

  private static String createJaasConfig(String username, String password) {
    return """
        org.apache.kafka.common.security.scram.ScramLoginModule required 
        username="%s" 
        password="%s";
        """.formatted(username, password);
  }

  private static void applyAckModeAndObs(ConcurrentKafkaListenerContainerFactory<?, ?> factory,
      ConsumerSpec spec) {
    if (StringUtils.hasText(spec.getAckMode())) {
      factory.getContainerProperties()
          .setAckMode(ContainerProperties.AckMode.valueOf(spec.getAckMode()));
    }
    if (Boolean.TRUE.equals(spec.getObservationEnabled())) {
      factory.getContainerProperties().setObservationEnabled(true);
    }
  }

  @Bean
  public DefaultErrorHandler errorHandler() {
    return new DefaultErrorHandler(
        (record, exception) -> log.warn("""
            Deserialization error: {}
            """, exception.getMessage(), exception),
        new FixedBackOff(0, 0)
    );
  }

  // ========= Helper methods =========

  private void configureErrorHandlingDeserializers(
      Map<String, Object> props,
      Class<?> valueDelegateClass
  ) {
    props.put("spring.deserializer.key.delegate.class", StringDeserializer.class);
    props.put("spring.deserializer.value.delegate.class", valueDelegateClass);
  }

  private void configureOffsetAndCommitBehavior(Map<String, Object> props, ConsumerSpec spec) {
    props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, spec.getAutoOffsetReset());

    var needsContainerAcks = "BATCH".equalsIgnoreCase(spec.getAckMode()) ||
        "MANUAL_IMMEDIATE".equalsIgnoreCase(spec.getAckMode());

    props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG,
        needsContainerAcks ? false : Boolean.TRUE.equals(spec.getEnableAutoCommit()));
  }

  private KafkaProps.SaslCredentials.UserCredentials getUserCredentials(boolean useOnPremUser) {
    return useOnPremUser
        ? kafkaProps.getSaslCredentials().getOnPremUser()
        : kafkaProps.getSaslCredentials().getSpotlightUser();
  }

  private <T> ConcurrentKafkaListenerContainerFactory<String, T> createBaseContainerFactory(
      Map<String, Object> props,
      ConsumerSpec spec
  ) {
    var factory = new ConcurrentKafkaListenerContainerFactory<String, T>();
    factory.setConcurrency(spec.getConcurrency());
    factory.setConsumerFactory(new DefaultKafkaConsumerFactory<>(props));
    factory.setBatchListener(true);
    props.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
    factory.getContainerProperties().setAckMode(MANUAL_IMMEDIATE);
    return factory;
  }
}
