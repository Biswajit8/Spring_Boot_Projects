package com.lowes.promotionstore.component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lowes.promotionstore.component.search.CalendarRangeResolver;
import com.lowes.promotionstore.constants.ApplicationConstants;
import com.lowes.promotionstore.entity.spotlight.ExcludeItem;
import com.lowes.promotionstore.entity.spotlight.FeaturedItemEntity;
import com.lowes.promotionstore.entity.spotlight.IncludeItemStores;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.entity.spotlight.SalesEnums.ForecastSearchEnum;
import com.lowes.promotionstore.entity.spotlight.SalesEnums.SalesSearchEnum;
import com.lowes.promotionstore.model.coredata.uploaditems.ExternalCatalogItemPayloadDto;
import com.lowes.promotionstore.model.coredata.uploaditems.RowDetailsPayloadDto;
import com.lowes.promotionstore.model.coredata.uploaditems.UploadFileDtoPayloadDto;
import com.lowes.promotionstore.model.coredata.validationresponse.ValidationResponse;
import com.lowes.promotionstore.model.record.spotlight.CatalogPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ConditionGroupPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.CustomerPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.DigitalTaxonomyExcludePayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ILOConditionAttributesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ItemDetailsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.KeyValuePayloadDto;
import com.lowes.promotionstore.model.record.spotlight.LocationsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.LoyaltyPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.MarketingInfoPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.OfferIntegrationCompatibilityPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.PriceCatalogItemDetailPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.PriceCatalogItemLocationsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.PriceCatalogProductsIncludePayloadDto;
import com.lowes.promotionstore.model.record.spotlight.PriceCatalogProductsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.PromotionMetaDataPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.RewardGroupPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.RewardItemAttributesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.SchedulePayloadDto;
import com.lowes.promotionstore.model.record.spotlight.ShippingTypeFieldsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.TierPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.DiscountTypeEnum;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.OfferSubTypeEnum;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.OfferTypeEnum;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.ScheduleTypeEnum;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.UnitEnum;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionStoreEnums.CatalogQualificationTypeEnum;
import com.lowes.promotionstore.repository.rest.CoreDataRepository;
import com.lowes.promotionstore.repository.rest.SpotlightApiRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import java.time.DateTimeException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static com.lowes.promotionstore.constants.ApplicationConstants.DIVISION_APPLIANCES;
import static com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.RewardOnEnum.ITEMS_ON_CONDITION;
import static com.lowes.promotionstore.model.record.spotlight.enums.PromotionStoreEnums.CatalogQualificationTypeEnum.CONDITION_ITEM;
import static com.lowes.promotionstore.model.record.spotlight.enums.PromotionStoreEnums.CatalogQualificationTypeEnum.CONDITION_REWARD_ITEM;
import static com.lowes.promotionstore.model.record.spotlight.enums.PromotionStoreEnums.CatalogQualificationTypeEnum.REWARD_ITEM;

@Component
@Slf4j
public class SpotlightPromoStoreEntityMapper {

  public final CoreDataRepository coreDataRepository;
  public final SpotlightApiRepository spotlightApiRepository;
  public final CalendarRangeResolver calendarRangeResolver;
  private final ForecastDataMapper forecastDataMapper;
  private final SalesDataMapper salesDataMapper;
  public final ObjectMapper objectMapper;
  private final PartialMapBuilders partialMapBuilders;

  private final Predicate<SpotlightOfferPayloadDto> isPresentTopOfferInfo = (spotlightOfferPayloadDto) ->
      Objects.nonNull(spotlightOfferPayloadDto.marketingInfo())
          && Objects.nonNull(spotlightOfferPayloadDto.marketingInfo().topOfferInfo());


  public SpotlightPromoStoreEntityMapper(CoreDataRepository coreDataRepository,
      ForecastDataMapper forecastDataMapper, SalesDataMapper salesDataMapper,
      PartialMapBuilders partialMapBuilders, CalendarRangeResolver calendarRangeResolver,
      SpotlightApiRepository spotlightApiRepository) {
    this.coreDataRepository = coreDataRepository;
    this.forecastDataMapper = forecastDataMapper;
    this.salesDataMapper = salesDataMapper;
    objectMapper = new ObjectMapper();
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    objectMapper.registerModule(new JavaTimeModule());
    this.partialMapBuilders = partialMapBuilders;
    this.calendarRangeResolver = calendarRangeResolver;
    this.spotlightApiRepository = spotlightApiRepository;
  }

  private static void mapLocationFields(SpotlightOfferPayloadDto spotlightOffer,
      PromotionStore promotionStore) {
    LocationsPayloadDto locations = spotlightOffer.locations();
    if (Objects.nonNull(locations)) {
      promotionStore.setIncludeAllStores(locations.includeAllStores());

      if (!CollectionUtils.isEmpty(locations.patches())) {
        promotionStore.setPatches(new HashSet<>(locations.patches()));
        promotionStore.setPatchOffer(Boolean.TRUE);
      } else {
        promotionStore.setPatchOffer(Boolean.FALSE);
        promotionStore.setPatches(Collections.emptySet());
      }

      List<String> stores = locations.stores();
      if (!CollectionUtils.isEmpty(stores)) {
        promotionStore.setStores(stores.stream()
            .filter(Objects::nonNull)
            .map(Integer::valueOf)
            .collect(Collectors.toSet()));
      } else {
        promotionStore.setStores(Collections.emptySet());
      }
    } else {
      promotionStore.setStores(Collections.emptySet());
      promotionStore.setPatches(Collections.emptySet());
    }
  }

  private static void mapCustomerFields(CustomerPayloadDto customer,
      PromotionStore promotionStore) {
    if (Objects.nonNull(customer)) {
      promotionStore.setCustomerType(customer.customerType().name());
      List<LoyaltyPayloadDto> loyalties = customer.loyalties();
      if (!CollectionUtils.isEmpty(loyalties)) {
        promotionStore.setLoyaltiesTierId(loyalties.stream()
            .filter(Objects::nonNull)
            .map(LoyaltyPayloadDto::tierId)
            .collect(Collectors.toSet()));
        promotionStore.setLoyaltiesTierName(loyalties.stream()
            .filter(Objects::nonNull)
            .map(LoyaltyPayloadDto::loyaltyName)
            .collect(Collectors.toSet()));
      } else {
        promotionStore.setLoyaltiesTierId(new HashSet<>());
        promotionStore.setLoyaltiesTierName(new HashSet<>());
      }
    }
  }

  private static void mapMetaDataFields(PromotionMetaDataPayloadDto promotionMetaData,
      PromotionStore promotionStore) {
    if (Objects.nonNull(promotionMetaData)) {

      promotionStore.setPromoTrackerlink(promotionMetaData.promoTrackerLink());
      promotionStore.setSubDivisions(new HashSet<>(promotionMetaData.subDivisions()));
      promotionStore.setDivisions(new HashSet<>(promotionMetaData.divisions()));
      promotionStore.setEventIds(new HashSet<>(promotionMetaData.eventIds()));

    } else {
      promotionStore.setSubDivisions(Collections.emptySet());
      promotionStore.setDivisions(Collections.emptySet());
      promotionStore.setEventIds(Collections.emptySet());
    }

  }


  public static SpotlightOfferPayloadDto enrichSpotlightOfferDto(
      SpotlightOfferPayloadDto spotlightOfferDto) {
    OfferTypePair resolvedOfferTypes = resolveOfferTypes(spotlightOfferDto);
    String blackOutStartDate = enrichBlackoutDate(spotlightOfferDto);

    return copyWithUpdatedFields(
        spotlightOfferDto,
        resolvedOfferTypes.offerType(),
        resolvedOfferTypes.offerSubType(),
        resolvedOfferTypes.offerTypeName(),
        resolvedOfferTypes.offerTypeSubName(),
        blackOutStartDate
    );
  }

  private static String enrichBlackoutDate(SpotlightOfferPayloadDto spotlightOfferDto) {
    String blackoutStartDate = spotlightOfferDto.blackoutDate();

    boolean isNotAppliancesDivision = !spotlightOfferDto.metaData()
        .divisions()
        .contains(DIVISION_APPLIANCES);

    String scheduleStartDate = spotlightOfferDto.schedule().startDate();

    if (isNotAppliancesDivision && scheduleStartDate != null) {
      try {
        Instant startDateInstant = convertESTtoUtc(scheduleStartDate);
        if (Objects.nonNull(startDateInstant)) {
          Instant blackoutInstant = startDateInstant.minus(Duration.ofDays(14));
          blackoutStartDate = blackoutInstant.atZone(ZoneId.of("UTC"))
              .format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        }
      } catch (DateTimeException e) {
        log.warn("Failed to parse start date: {}", scheduleStartDate, e);
      }
    }
    return blackoutStartDate;
  }


  private record OfferTypePair(String offerType, String offerTypeName, String offerSubType,
                               String offerTypeSubName) {

  }

  private static OfferTypePair resolveOfferTypes(SpotlightOfferPayloadDto spotlightOfferDto) {
    OfferTypePair sourceOfferTypePair = new OfferTypePair(
        spotlightOfferDto.offerType(),
        spotlightOfferDto.offerTypeName(),
        spotlightOfferDto.offerSubType(),
        spotlightOfferDto.offerSubTypeName()
    );

    int offerTypeId = spotlightOfferDto.offerTypeId().intValue();

    switch (offerTypeId) {
      case 15 -> {
        return new OfferTypePair(
            OfferTypeEnum.DISCOUNTED_PRICING.name(),
            OfferTypeEnum.DISCOUNTED_PRICING.getOfferTypeName(),
            OfferSubTypeEnum.CLEARANCE.name(),
            OfferSubTypeEnum.CLEARANCE.getOfferSubTypeEnum()
        );
      }
      case 16, 17 -> {
        return new OfferTypePair(
            OfferTypeEnum.PRO_SAVINGS.name(),
            OfferTypeEnum.PRO_SAVINGS.getOfferTypeName(),
            OfferSubTypeEnum.BULK_SAVINGS.name(),
            OfferSubTypeEnum.BULK_SAVINGS.getOfferSubTypeEnum()
        );
      }
      case 7 -> {
        return new OfferTypePair(
            OfferTypeEnum.CREDIT.name(),
            OfferTypeEnum.CREDIT.getOfferTypeName(),
            OfferSubTypeEnum.CREDIT_DISCOUNT.name(),
            OfferSubTypeEnum.CREDIT_DISCOUNT.getOfferSubTypeEnum()
        );
      }
      case 14 -> {
        return new OfferTypePair(
            OfferTypeEnum.CREDIT.name(),
            OfferTypeEnum.CREDIT.getOfferTypeName(),
            OfferSubTypeEnum.FINANCE_OFFER.name(),
            OfferSubTypeEnum.FINANCE_OFFER.getOfferSubTypeEnum()
        );
      }
      default -> {
        log.warn("Unhandled offerTypeId: {} – no matching offer type or subtype found.",
            offerTypeId);
        return sourceOfferTypePair;
      }
    }
  }

  private static SpotlightOfferPayloadDto copyWithUpdatedFields(SpotlightOfferPayloadDto original,
      String offerType,
      String offerSubType, String offerTypeName, String offerSubTypeName,
      String blackoutStartDate) {
    return new SpotlightOfferPayloadDto(
        original.id(),
        original.offerTypeId(),
        original.metaData(),
        original.name(),
        offerType,
        offerTypeName,
        offerSubType,
        offerSubTypeName,
        original.shortDescription(),
        original.schedule(),
        original.marketScope(),
        original.locations(),
        original.customer(),
        original.redemptionType(),
        original.couponCode(),
        original.autoApplyCode(),
        original.status(),
        original.tiers(),
        original.catalogs(),
        original.marketingInfo(),
        original.createdTs(),
        original.createdBy(),
        original.modifiedTs(),
        original.modifiedBy(),
        original.activatedTs(),
        original.activatedBy(),
        original.active(),
        original.version(),
        original.activeCounter(),
        original.deactivatedTs(),
        original.deactivatedBy(),
        original.termsAndConditions(),
        original.sourceSystem(),
        original.offerTactic(),
        original.labelInfo(),
        original.forecastData(),
        original.salesData(),
        original.offerGroup(),
        blackoutStartDate,
        original.isApprovedAndLocked(),
        original.priceCatalogProducts(),
        original.vendorFundingInfo(),
        original.comments(),
        original.executionMessageType(),
        original.stackingGroup(),
        original.previousStatus(),
        original.enrichedStatus(),
        original.alerts(),
        original.offerIntegrationCompatibility(),
        original.amplificationChannel(),
        original.createdByEmailId(),
        original.modifiedByEmailId(),
        original.catalogUrl(),
        original.dualMaintenance(),
        original.editingInProgress(),
        original.signage(),
        original.forecastOverrides(),
        original.rebateInfo(),
        original.versionChanges(),
        original.patchesCount(),
        original.featuredItemsCount(),
        original.derivedPatches()
    );
  }

  private static Set<IncludeItemStores> mapIncludeItemStores(
      List<ItemDetailsPayloadDto> itemDetails,
      CatalogQualificationTypeEnum catalogQualificationTypeEnum) {
    Set<IncludeItemStores> includeItemStoresSet = new HashSet<>();
    for (ItemDetailsPayloadDto itemDetail : itemDetails) {
      IncludeItemStores includeItemStores = new IncludeItemStores();
      includeItemStores.setItemNo(itemDetail.itemNo());
      includeItemStores.setVendorNo(itemDetail.vendorNo());
      includeItemStores.setModelNo(itemDetail.modelNo());
      includeItemStores.setServiceItem(itemDetail.serviceItem());
      includeItemStores.setDefaultItem(itemDetail.defaultItem());
      if (Objects.nonNull(catalogQualificationTypeEnum)) {
        includeItemStores.setItemQualificationType(catalogQualificationTypeEnum.name());
      } else {
        log.warn("Catalog Qualification Type not found for itemid", itemDetail.itemNo(),
            catalogQualificationTypeEnum);
      }
      includeItemStores.setDiscountValue(String.valueOf(itemDetail.discountValue()));
      if (Objects.nonNull(itemDetail.locations())) {
        if (!CollectionUtils.isEmpty(itemDetail.locations().stores())) {
          includeItemStores.setStores(new HashSet<>(itemDetail.locations().stores()));
        }
        if (!CollectionUtils.isEmpty(itemDetail.locations().patches())) {
          includeItemStores.setPatches(new HashSet<>(itemDetail.locations().patches()));
        }
      }
      includeItemStoresSet.add(includeItemStores);
    }
    return includeItemStoresSet;
  }

  private static Set<ExcludeItem> mapExcludeItems(List<ItemDetailsPayloadDto> itemDetails,
      CatalogQualificationTypeEnum catalogQualificationTypeEnum) {
    Set<ExcludeItem> excludeItemSet = new HashSet<>();
    for (ItemDetailsPayloadDto itemDetail : itemDetails) {
      ExcludeItem excludeItem = new ExcludeItem();
      excludeItem.setItemNo(itemDetail.itemNo());
      excludeItem.setVendorNo(itemDetail.vendorNo());
      excludeItem.setModelNo(itemDetail.modelNo());
      excludeItem.setServiceItem(itemDetail.serviceItem());
      excludeItem.setDefaultItem(itemDetail.defaultItem());
      excludeItem.setItemQualificationType(catalogQualificationTypeEnum.name());
      excludeItemSet.add(excludeItem);
    }
    return excludeItemSet;
  }

  private static List<ExternalCatalogItemPayloadDto> createExternalCatalogItems(
      ValidationResponse validationResponse) {
    List<ExternalCatalogItemPayloadDto> externalCatalogItems = new ArrayList<>();
    validationResponse.successItems().stream().forEach(item -> {
      ExternalCatalogItemPayloadDto externalCatalogItemPayloadDto = new ExternalCatalogItemPayloadDto();
      mapItemNumber(item.getItemNumber(), externalCatalogItemPayloadDto);
      if (Objects.nonNull(item.getDiscountType()) && Objects.nonNull(item.getDiscountValue())) {
        mapOfferPrice(item.getOfferPrice(), item.getDiscountType().toString(),
            String.valueOf(item.getDiscountValue()),
            externalCatalogItemPayloadDto);
      }
      mapStoresOrPatches(item.getLocations(), externalCatalogItemPayloadDto);
      externalCatalogItems.add(externalCatalogItemPayloadDto);
    });
    return externalCatalogItems;
  }

  private static List<ExternalCatalogItemPayloadDto> createUploadCatalogItems(
      UploadFileDtoPayloadDto uploadFileDto) {
    List<ExternalCatalogItemPayloadDto> uploadCatalogItems = new ArrayList<>();
    for (RowDetailsPayloadDto rd : uploadFileDto.getSuccess()) {
      ExternalCatalogItemPayloadDto uploadCatalogItem = new ExternalCatalogItemPayloadDto();
      mapItemNumber(rd.getItemNumber(), uploadCatalogItem);
      mapOfferPrice(rd.getOfferPrice(), rd.getDiscountType(), rd.getDiscountValue(),
          uploadCatalogItem);
      mapStoresOrPatches(rd.getLocations(), uploadCatalogItem);
      uploadCatalogItems.add(uploadCatalogItem);
    }
    return uploadCatalogItems;
  }

  private static void mapItemNumber(String itemNumber,
      ExternalCatalogItemPayloadDto uploadCatalogItem) {
    itemNumber = StringUtils.hasText(itemNumber) ?
        itemNumber.replace("\n", "").replace("\r", "").trim() :
        null;
    uploadCatalogItem.setItemNumber(itemNumber);
  }

  private static void mapOfferPrice(String offerPrice,
      String discountType,
      String discountValue,
      ExternalCatalogItemPayloadDto uploadCatalogItem) {
    offerPrice = StringUtils.hasText(offerPrice) ?
        offerPrice.replace("\n", "").replace("\r", "").replace("$", "").trim() :
        null;
    if (StringUtils.hasText(offerPrice)) {
      uploadCatalogItem.setOfferPrice(offerPrice);
    }
    if (StringUtils.hasText(discountType)) {
      uploadCatalogItem.setDiscountType(discountType);
    }

    if (StringUtils.hasText(discountValue)) {
      uploadCatalogItem.setDiscountValue(discountValue);
    }
  }

  private static void mapStoresOrPatches(String locations,
      ExternalCatalogItemPayloadDto uploadCatalogItem) {
    String location;
    location = StringUtils.hasText(locations) ?
        locations.replace("\n", "").replace("\r", "").trim() :
        "";

    if (StringUtils.hasText(location)) {
      char firstChar = location.charAt(0);
      if (Character.isLetter(firstChar)) {
        uploadCatalogItem.setPatches(Stream.of(location.split(",")).map(String::trim).toList());
        uploadCatalogItem.setStores(Collections.emptyList());
      } else {
        uploadCatalogItem.setStores(Stream.of(location.split(",")).map(String::trim).toList());
        uploadCatalogItem.setPatches(Collections.emptyList());
      }
    } else {
      uploadCatalogItem.setStores(Collections.emptyList());
      uploadCatalogItem.setPatches(Collections.emptyList());
    }
  }

  private static void mapAsyncStoresOrPatches(String locations,
      ExternalCatalogItemPayloadDto uploadCatalogItem) {

    if (StringUtils.hasText(locations)) {
      char firstChar = locations.charAt(0);
      if (Character.isLetter(firstChar)) {
        uploadCatalogItem.setPatches(Stream.of(locations.split(",")).map(String::trim).toList());
        uploadCatalogItem.setStores(Collections.emptyList());
      } else {
        uploadCatalogItem.setStores(Stream.of(locations.split(",")).map(String::trim).toList());
        uploadCatalogItem.setPatches(Collections.emptyList());
      }
    } else {
      uploadCatalogItem.setStores(Collections.emptyList());
      uploadCatalogItem.setPatches(Collections.emptyList());
    }
  }

  private static boolean isSetupOnNationalOffer(IncludeItemStores itemStore) {
    return CollectionUtils.isEmpty(itemStore.getPatches())
        && CollectionUtils.isEmpty(itemStore.getStores());
  }

  public PromotionStore mapOfferToPromotionStoreEntity(SpotlightOfferPayloadDto spotlightOfferDTO)
      throws
      JsonProcessingException {

    PromotionStore promotionStore = new PromotionStore();
    promotionStore.setId(String.valueOf(spotlightOfferDTO.id()));
    promotionStore.setName(spotlightOfferDTO.name());
    promotionStore.setOfferType(spotlightOfferDTO.offerType());
    promotionStore.setOfferTypeName(spotlightOfferDTO.offerTypeName());
    promotionStore.setOfferSubType(spotlightOfferDTO.offerSubType());
    promotionStore.setOfferSubTypeName(spotlightOfferDTO.offerSubTypeName());
    promotionStore.setOfferTactic(spotlightOfferDTO.offerTactic());
    promotionStore.setActive(spotlightOfferDTO.active());
    promotionStore.setActivatedBy(spotlightOfferDTO.activatedBy());
    promotionStore.setActivatedTs(convertESTtoUtc(spotlightOfferDTO.activatedTs()));
    promotionStore.setModifiedTs(convertESTtoUtc(spotlightOfferDTO.modifiedTs()));
    promotionStore.setDeactivatedTs(convertESTtoUtc(spotlightOfferDTO.deactivatedTs()));
    promotionStore.setAutoApplyCode(spotlightOfferDTO.autoApplyCode());
    mapScheduleFields(spotlightOfferDTO.schedule(), promotionStore);
    promotionStore.setCouponCode(spotlightOfferDTO.couponCode());
    promotionStore.setCreatedBy(spotlightOfferDTO.createdBy());
    promotionStore.setCreatedTs(convertESTtoUtc(spotlightOfferDTO.createdTs()));
    promotionStore.setDeactivatedBy(spotlightOfferDTO.deactivatedBy());
    promotionStore.setModifiedBy(spotlightOfferDTO.modifiedBy());
    promotionStore.setOfferTypeId(spotlightOfferDTO.offerTypeId());
    mapLocationFields(spotlightOfferDTO, promotionStore);
    mapMetaDataFields(spotlightOfferDTO.metaData(), promotionStore);
    if (Objects.nonNull(spotlightOfferDTO.redemptionType())) {
      promotionStore.setRedemptionType(spotlightOfferDTO.redemptionType().name());
    }
    promotionStore.setIndexedTs(Instant.now());
    promotionStore.setStatus(spotlightOfferDTO.status().name());
    promotionStore.setVersion(spotlightOfferDTO.version());
    promotionStore.setSourceSystem(spotlightOfferDTO.sourceSystem());
    promotionStore.setMarketScope(spotlightOfferDTO.marketScope());
    mapCustomerFields(spotlightOfferDTO.customer(), promotionStore);

    mapTiers(spotlightOfferDTO, promotionStore);
    mapCatalogsFields(spotlightOfferDTO, promotionStore);

    promotionStore.setFeaturedItems(enrichFeaturedItem(spotlightOfferDTO));
    mapGroupInfo(spotlightOfferDTO, promotionStore);
    promotionStore.setRawOffer(objectMapper.writeValueAsString(spotlightOfferDTO));
    promotionStore.setBlackoutDate(convertESTtoUtc(spotlightOfferDTO.blackoutDate()));
    promotionStore.setIsApprovedAndLocked(spotlightOfferDTO.isApprovedAndLocked());
    promotionStore.setEnrichedStatus(spotlightOfferDTO.enrichedStatus());
    promotionStore.setPreviousStatus(spotlightOfferDTO.previousStatus());
    mapMarketingInfo(spotlightOfferDTO, promotionStore);
    promotionStore.setAmplificationChannel(spotlightOfferDTO.amplificationChannel());
    setAlerts(spotlightOfferDTO, promotionStore);
    setForecastAccuracyIndicator(promotionStore, spotlightOfferDTO.offerIntegrationCompatibility());
    promotionStore.setPatchesCount(spotlightOfferDTO.patchesCount());
    promotionStore.setFeaturedItemsCount(spotlightOfferDTO.featuredItemsCount());
    return promotionStore;
  }

  private void mapGroupInfo(SpotlightOfferPayloadDto spotlightOfferDTO,
      PromotionStore promotionStore) {
    if (Objects.nonNull(spotlightOfferDTO.offerGroup()) && Objects.nonNull(
        spotlightOfferDTO.offerGroup().id()) && Objects.nonNull(
        spotlightOfferDTO.offerGroup().name())) {
      promotionStore.setGroupId(String.valueOf(spotlightOfferDTO.offerGroup().id()));
      promotionStore.setGroupName(spotlightOfferDTO.offerGroup().name());
    }
  }

  private void mapMarketingInfo(SpotlightOfferPayloadDto spotlightOfferDTO,
      PromotionStore promotionStore) {
    if (isPresentTopOfferInfo.test(spotlightOfferDTO)) {
      promotionStore.setTopOffer(
          (Objects.nonNull(spotlightOfferDTO.marketingInfo().topOfferInfo().topOffer())) ?
              spotlightOfferDTO.marketingInfo().topOfferInfo().topOffer()
              : Boolean.FALSE);
      if (Objects.nonNull(spotlightOfferDTO.marketingInfo().topOfferInfo().topOffer())) {
        promotionStore.setDoorBuster(
            spotlightOfferDTO.marketingInfo().topOfferInfo().doorBuster());
      }
      mapTopOfferSchedule(spotlightOfferDTO, promotionStore);
    }
  }

  private void mapTopOfferSchedule(SpotlightOfferPayloadDto spotlightOfferDTO,
      PromotionStore promotionStore) {

    if (Objects.nonNull(spotlightOfferDTO.marketingInfo().topOfferInfo().topOfferSchedule())) {
      if (Objects.nonNull(
          spotlightOfferDTO.marketingInfo().topOfferInfo().topOfferSchedule().scheduleType())) {
        if (spotlightOfferDTO.marketingInfo().topOfferInfo().topOfferSchedule().scheduleType()
            .equals(ScheduleTypeEnum.OFFER_DURATION)) {
          LocalDate startDate =
              Objects.nonNull(spotlightOfferDTO.schedule())
                  ? parseLocalDate(spotlightOfferDTO.schedule().startDate())
                  : null;

          LocalDate endDate =
              Objects.nonNull(spotlightOfferDTO.schedule())
                  ? parseLocalDate(spotlightOfferDTO.schedule().endDate())
                  : null;

          promotionStore.setTopOfferPromoWeeks(
              calendarRangeResolver.getPromoWeeksForDateRange(startDate, endDate));
        } else {
          promotionStore.setTopOfferPromoWeeks(
              spotlightOfferDTO.marketingInfo().topOfferInfo().topOfferSchedule().promoWeeks());
          promotionStore.setTopOfferFiscalQuarters(
              spotlightOfferDTO.marketingInfo().topOfferInfo().topOfferSchedule().fiscalQuarters());
        }

      }
    }
  }

  private static LocalDate parseLocalDate(String s) {
    if (!StringUtils.hasText(s)) {
      return null;
    }

    List<DateTimeFormatter> fmts = List.of(
        DateTimeFormatter.ISO_LOCAL_DATE,                               // 2026-02-24
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"),             // 2026-02-24 00:00:00
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm")                 // 2026-02-24 00:00
    );

    for (DateTimeFormatter fmt : fmts) {
      try {
        // If it's a pure date, this works:
        return LocalDate.parse(s, fmt);
      } catch (DateTimeParseException ignore) {
        // If it included time, parse as LocalDateTime then drop the time:
        try {
          return LocalDateTime.parse(s, fmt).toLocalDate();
        } catch (DateTimeParseException ignore2) { /* try next fmt */ }
      }
    }
    log.error("Unable to parse date: " + s);
    return null;
  }

  private void setAlerts(SpotlightOfferPayloadDto spotlightOfferDTO,
      PromotionStore promotionStore) {
    if (Objects.nonNull(spotlightOfferDTO.alerts())) {
      promotionStore.setHasError(spotlightOfferDTO.alerts().hasError());
      promotionStore.setHasWarning(spotlightOfferDTO.alerts().hasWarning());
    }

  }

  private List<FeaturedItemEntity> enrichFeaturedItem(SpotlightOfferPayloadDto spotlightOfferDTO) {
    MarketingInfoPayloadDto marketingInfo = spotlightOfferDTO.marketingInfo();
    if (Objects.nonNull(marketingInfo) &&
        !CollectionUtils.isEmpty(marketingInfo.featuredItems())) {
      return spotlightOfferDTO.marketingInfo()
          .featuredItems()
          .stream()
          .filter(featureCatalogItem -> !CollectionUtils
              .isEmpty(featureCatalogItem.itemDetails()))
          .flatMap(featureCatalogItem -> featureCatalogItem.itemDetails()
              .stream())
          .map(m -> new FeaturedItemEntity(m.itemNo(), m.vendorNo(), m.modelNo(), m.patches(),
              m.stores()))
          .toList();
    }
    return null;
  }

  private void mapScheduleFields(SchedulePayloadDto schedule,
      PromotionStore promotionStore) {
    if (Objects.nonNull(schedule)) {
      promotionStore.setCalendarWeek(schedule.calendarWeek());
      promotionStore.setNoEndDate(schedule.noEndDate());
      promotionStore.setStartDate(convertESTtoUtc(schedule.startDate()));
      Instant endDate = convertESTtoUtc(schedule.endDate());

      if (endDate != null) {
        ZonedDateTime zonedDateTime = endDate.atZone(ZoneId.of("UTC"));
        if (zonedDateTime.getYear() > 9999) {
          promotionStore.setEndDate(LocalDateTime
              .of(9999, 12, 31, 23, 59, 59)
              .toInstant(ZoneOffset.UTC));
        } else {
          promotionStore.setEndDate(endDate);
        }
      }
    }
  }

  public Map<String, Object> ruleSetsEnrichment(PromotionStore promotionStore,
      SpotlightOfferPayloadDto spotlightOfferDTO) {
    List<String> excludes = new ArrayList<>();
    for (SalesSearchEnum e : SalesSearchEnum.values()) {
      excludes.add(e.name());
    }

    if (excludeUpdateToForecast(spotlightOfferDTO)) {
      for (ForecastSearchEnum e : ForecastSearchEnum.values()) {
        excludes.add(e.name());
      }
    }
    return partialMapBuilders.from(promotionStore).exclude(excludes).build();
  }

  public boolean excludeUpdateToForecast(SpotlightOfferPayloadDto spotlightOfferDTO) {
    return Objects.nonNull(spotlightOfferDTO.enrichedStatus()) && Objects.nonNull(
        spotlightOfferDTO.previousStatus()) &&
        "APPROVED".equals(spotlightOfferDTO.enrichedStatus()) && "PROPOSED".equals(
        spotlightOfferDTO.previousStatus()) && Objects.nonNull(
        spotlightOfferDTO.offerIntegrationCompatibility())
        && spotlightOfferDTO.offerIntegrationCompatibility().isSupportedByCalc();
  }

  private static Instant convertESTtoUtc(String estDate) {
    if (Objects.nonNull(estDate)) {
      DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
      LocalDateTime localDateTime = LocalDateTime.parse(estDate, formatter);
      return localDateTime.atZone(ZoneId.of("America/New_York")).toInstant();

    }
    return null;
  }

  private void mapCatalogsFields(SpotlightOfferPayloadDto spotlightOfferDto,
      PromotionStore promotionStore) {

    Map<String, CatalogQualificationTypeEnum> catalogRefMap = getcatalogRefMap(
        spotlightOfferDto);
    if (!CollectionUtils.isEmpty(spotlightOfferDto.catalogs()) && !CollectionUtils.isEmpty(
        catalogRefMap)) {
      mapIncludeProducts(spotlightOfferDto.catalogs(), catalogRefMap, promotionStore);
      mapIncludeExternalCatalog(spotlightOfferDto, promotionStore);
      mapIncludePriceCatalog(spotlightOfferDto, promotionStore);
      mapExcludeProducts(spotlightOfferDto.catalogs(), catalogRefMap, promotionStore);
    } else {
      promotionStore.setIncludeBrandIds(Collections.emptySet());
      promotionStore.setIncludeBrandNames(Collections.emptySet());
      promotionStore.setIncludePcrs(Collections.emptySet());
      promotionStore.setIncludeMerchBucketIds(Collections.emptySet());
      promotionStore.setIncludeMerchBucketNames(Collections.emptySet());
      promotionStore.setIncludeDigitalTaxonomyIds(Collections.emptySet());
      promotionStore.setIncludeDigitalTaxonomyNames(Collections.emptySet());
      promotionStore.setIncludeItemStores(Collections.emptySet());
      promotionStore.setIncludeProductTypes(Collections.emptySet());
      promotionStore.setExcludeBrandIds(Collections.emptySet());
      promotionStore.setExcludeBrandNames(Collections.emptySet());
      promotionStore.setExcludeMerchBucketIds(Collections.emptySet());
      promotionStore.setExcludeMerchBucketNames(Collections.emptySet());
      promotionStore.setExcludeDigitalTaxonomyIds(Collections.emptySet());
      promotionStore.setExcludeDigitalTaxonomyNames(Collections.emptySet());
      promotionStore.setExcludeProductTypes(Collections.emptySet());
      promotionStore.setExcludeItems(Collections.emptySet());
    }
  }

  private void mapIncludePriceCatalog(SpotlightOfferPayloadDto spotlightOfferDto,
      PromotionStore promotionStore) {
    PriceCatalogProductsPayloadDto priceCatalogs = spotlightOfferDto.priceCatalogProducts();
    if (Objects.isNull(priceCatalogs)) {
      return;
    }

    DiscountTypeEnum discountType = determineDiscountType(spotlightOfferDto, promotionStore);
    Set<IncludeItemStores> includeItemStores = mapToIncludeItemStore(priceCatalogs.include(),
        discountType);

    configureOfferFlags(spotlightOfferDto, promotionStore, includeItemStores);
    promotionStore.setIncludeItemStores(includeItemStores);
  }

  private DiscountTypeEnum determineDiscountType(SpotlightOfferPayloadDto spotlightOfferDto,
      PromotionStore promotionStore) {
    DiscountTypeEnum discountType =
        CollectionUtils.isEmpty(promotionStore.getConditionGroupDiscountType())
            ? null
            : promotionStore.getConditionGroupDiscountType().stream().findFirst().orElse(null);

    if (Objects.nonNull(discountType) && !CollectionUtils.isEmpty(spotlightOfferDto.tiers())) {
      discountType = spotlightOfferDto.tiers().get(0).conditionGroups()
          .stream()
          .filter(conditionGroup -> Objects.nonNull(conditionGroup.iloConditionAttributes()))
          .map(conditionGroup -> conditionGroup.iloConditionAttributes().discountType())
          .filter(Objects::nonNull)
          .findFirst()
          .orElse(discountType);
    }

    return discountType;
  }

  private void configureOfferFlags(SpotlightOfferPayloadDto spotlightOfferDto,
      PromotionStore promotionStore, Set<IncludeItemStores> includeItemStores) {
    if (isItemLevelOffer(spotlightOfferDto)) {
      promotionStore.setPatchOffer(isPatchOffer(includeItemStores));
      promotionStore.setIncludeAllStores(isNationalOffer(includeItemStores));
    }
  }


  private Set<IncludeItemStores> mapToIncludeItemStore(
      PriceCatalogProductsIncludePayloadDto include, DiscountTypeEnum discountTypeEnum) {
    if (include == null || CollectionUtils.isEmpty(include.itemDetails())) {
      return Collections.emptySet();
    }

    String discountType = Objects.nonNull(discountTypeEnum) ? discountTypeEnum.toString() : null;

    return include.itemDetails().stream()
        .map(itemDetail -> createIncludeItemStores(itemDetail, discountType))
        .collect(Collectors.toSet());
  }

  private IncludeItemStores createIncludeItemStores(PriceCatalogItemDetailPayloadDto itemDetail,
      String discountType) {
    IncludeItemStores includeItemStores = new IncludeItemStores();
    includeItemStores.setItemNo(itemDetail.itemNo());
    includeItemStores.setModelNo(itemDetail.modelNo());
    includeItemStores.setVendorNo(itemDetail.vendorNo());
    includeItemStores.setDiscountValue(itemDetail.value());
    includeItemStores.setDiscountType(discountType);
    includeItemStores.setItemQualificationType(CONDITION_REWARD_ITEM.name());

    setLocationDetails(includeItemStores, itemDetail.locations());
    return includeItemStores;
  }

  private IncludeItemStores createIncludeItemStores(ExternalCatalogItemPayloadDto uci) {
    IncludeItemStores includeItemStores = new IncludeItemStores();
    includeItemStores.setItemNo(uci.getItemNumber());
    includeItemStores.setStores(new HashSet<>(uci.getStores()));
    includeItemStores.setPatches(new HashSet<>(uci.getPatches()));
    includeItemStores.setOfferPrice(uci.getOfferPrice());
    includeItemStores.setDiscountType(uci.getDiscountType());
    includeItemStores.setDiscountValue(uci.getDiscountValue());
    includeItemStores.setItemQualificationType(CONDITION_REWARD_ITEM.name());
    return includeItemStores;
  }

  private void setLocationDetails(IncludeItemStores includeItemStores,
      PriceCatalogItemLocationsPayloadDto locations) {
    if (Objects.nonNull(locations)) {
      if (!CollectionUtils.isEmpty(locations.stores())) {
        includeItemStores.setStores(new HashSet<>(locations.stores()));
      }
      if (!CollectionUtils.isEmpty(locations.patches())) {
        includeItemStores.setPatches(new HashSet<>(locations.patches()));
      }
    }
  }

  private void mapIncludeExternalCatalog(SpotlightOfferPayloadDto spotlightOfferDto,
      PromotionStore promotionStore) {
    if (Objects.nonNull(spotlightOfferDto.priceCatalogProducts())) {
      return;
    }
    Set<IncludeItemStores> includeItemStores = new HashSet<>();

    getClearanceExternalCatalogues(spotlightOfferDto, promotionStore, includeItemStores);
    getSprAndNdoExternalCatalog(spotlightOfferDto, includeItemStores);

    if (isItemLevelOffer(spotlightOfferDto)) {
      promotionStore.setPatchOffer(isPatchOffer(includeItemStores));
      promotionStore.setIncludeAllStores(isNationalOffer(includeItemStores));
    }

    promotionStore.getIncludeItemStores().addAll(includeItemStores);
  }

  private void getSprAndNdoExternalCatalog(
      SpotlightOfferPayloadDto dto,
      Set<IncludeItemStores> includeItemStores
  ) {
    final var offerTypeId = dto.offerTypeId();
    if (!isNdoOrSpr(offerTypeId)) {
      return;
    }

    Optional.ofNullable(dto.tiers())
        .stream()
        .flatMap(Collection::stream)
        .findFirst() // first tier
        .flatMap(tier -> Optional.ofNullable(tier.conditionGroups())
            .stream()
            .flatMap(Collection::stream)
            .findFirst()) // first condition group
        .map(ConditionGroupPayloadDto::iloConditionAttributes)
        .map(ILOConditionAttributesPayloadDto::validationRequestId)
        .filter(StringUtils::hasText)
        .ifPresent(requestId -> fetchAndAddExternalCatalog(dto, offerTypeId, requestId,
            includeItemStores));
  }

  private boolean isNdoOrSpr(Long offerTypeId) {
    return ApplicationConstants.NDO_OFFER_TYPES.contains(offerTypeId)
        || ApplicationConstants.SPR_OFFER_TYPES.contains(offerTypeId);
  }

  private void fetchAndAddExternalCatalog(
      SpotlightOfferPayloadDto dto,
      Long offerTypeId,
      String requestId,
      Set<IncludeItemStores> includeItemStores
  ) {
    try {
      var response = spotlightApiRepository.getExternalCatalogueItems(dto.id(), requestId);

      if (response == null) {
        log.error(
            "External catalog response is null for offerTypeId={}, promotionId={}, requestId={}",
            offerTypeId, dto.id(), requestId);
        return;
      }

      var mapped = mapItemExternalCatalog(response);
      if (mapped != null && !mapped.isEmpty()) {
        includeItemStores.addAll(mapped);
      }
    } catch (Exception e) {
      log.error(
          "Error while getting external catalog for offerTypeId={}, promotionId={}, requestId={}",
          offerTypeId, dto.id(), requestId, e);
    }
  }

  private void getClearanceExternalCatalogues(SpotlightOfferPayloadDto spotlightOfferDto,
      PromotionStore promotionStore,
      Set<IncludeItemStores> includeItemStores) {
    if (ApplicationConstants.CLEARANCE_OFFER_TYPES.contains(spotlightOfferDto.offerTypeId())) {
      spotlightOfferDto.catalogs().forEach(catalog -> {
        var fileRef = catalog.catalogFileRef();
        if (Objects.nonNull(fileRef) && StringUtils.hasText(fileRef.uploadName())) {
          String uploadName = fileRef.uploadName();
          String offerTypeLabel = resolveOfferTypeLabel(spotlightOfferDto.offerTypeId());
          try {
            UploadFileDtoPayloadDto uploadFileDto = coreDataRepository.getUploadedItems(
                Long.valueOf(promotionStore.getId()),
                uploadName,
                offerTypeLabel);
            includeItemStores.addAll(mapIncludeItemFromUploadCatalog(uploadFileDto));
          } catch (Exception e) {
            log.error(
                "Error while getting external catalog for offerTypeId={}, promotionId={}",
                promotionStore.getId(), spotlightOfferDto.id(), e);
          }

        }
      });
    }
  }


  private String resolveOfferTypeLabel(Long offerTypeId) {
    if (ApplicationConstants.CLEARANCE_OFFER_TYPES.contains(offerTypeId)) {
      return "CLE";
    } else if (ApplicationConstants.NDO_OFFER_TYPES.contains(offerTypeId)) {
      return "Non-Discounted";
    }
    return null;
  }

  private boolean isItemLevelOffer(SpotlightOfferPayloadDto spotlightOffer) {
    return ApplicationConstants.CLEARANCE_OFFER_TYPES.contains(spotlightOffer.offerTypeId())
        || ApplicationConstants.NDO_OFFER_TYPES.contains(
        spotlightOffer.offerTypeId()) || ApplicationConstants.SPR_OFFER_TYPES.contains(
        spotlightOffer.offerTypeId());
  }

  private Map<String, CatalogQualificationTypeEnum> getcatalogRefMap(
      SpotlightOfferPayloadDto spotlightOfferDto) {
    List<TierPayloadDto> tiers = spotlightOfferDto.tiers();
    Map<String, CatalogQualificationTypeEnum> catalogRefMap = new HashMap<>(
        Collections.emptyMap());

    if (!CollectionUtils.isEmpty(tiers)) {

      tiers.get(0).conditionGroups().forEach(conditionGroup -> {
        if (!CollectionUtils.isEmpty(conditionGroup.itemConditionAttributes())) {
          String catalogRef = conditionGroup.itemConditionAttributes().get(0).catalogRef();
          CatalogQualificationTypeEnum catalogQualificationTypeEnum =
              checkConditionCatalogType(catalogRef, tiers.get(0).rewardGroups());
          catalogRefMap.put(conditionGroup.itemConditionAttributes().get(0).catalogRef(),
              catalogQualificationTypeEnum);
        }

        if (Objects.nonNull(conditionGroup.iloConditionAttributes())) {
          catalogRefMap.put(conditionGroup.iloConditionAttributes().catalogRef(),
              CONDITION_REWARD_ITEM);
        }
      });

      tiers.get(0).rewardGroups().forEach(rewardGroup -> {
        if (!CollectionUtils.isEmpty(rewardGroup.itemConditionAttributes())) {
          String rewardCatalogRef =
              rewardGroup.itemConditionAttributes().get(0).catalogRef();
          if (!catalogRefMap.containsKey(rewardCatalogRef)) {
            catalogRefMap.put(rewardCatalogRef, REWARD_ITEM);
          }
        }
      });
    }
    return catalogRefMap;
  }

  private CatalogQualificationTypeEnum checkConditionCatalogType(
      String conditionCatalogRef,
      List<RewardGroupPayloadDto> rewardGroups) {
    boolean isRewardHavingItemsOnCondition =
        rewardGroups.stream().map(RewardGroupPayloadDto::rewardOn)
            .anyMatch(ITEMS_ON_CONDITION::equals);

    List<String> rewardCatalogRefs =
        rewardGroups.stream()
            .filter(rewardGroup -> !CollectionUtils.isEmpty(rewardGroup.itemConditionAttributes()))
            .map(rewardGroup -> rewardGroup.itemConditionAttributes().get(0).catalogRef()).toList();

    if (isRewardHavingItemsOnCondition || rewardCatalogRefs.contains(conditionCatalogRef)) {
      return CONDITION_REWARD_ITEM;
    } else {
      return CONDITION_ITEM;
    }
  }

  private void mapExcludeProducts(List<CatalogPayloadDto> catalogs,
      Map<String, CatalogQualificationTypeEnum> catalogRefMap,
      PromotionStore promotionStore) {
    List<CatalogPayloadDto> catalogsWithExclude = catalogs.stream()
        .filter(catalog -> Objects.nonNull(catalog.products()) &&
            Objects.nonNull(catalog.products().exclude()))
        .toList();

    promotionStore.setExcludeProductTypes(catalogsWithExclude.stream()
        .map(catalog -> catalog.products().exclude().productType())
        .collect(Collectors.toSet()));
    mapExcludeBrands(promotionStore, catalogsWithExclude);
    mapExcludeMerchBuckets(promotionStore, catalogsWithExclude);
    mapExcludeDigitalTaxonomies(promotionStore, catalogsWithExclude);
    mapExcludeItemDetails(promotionStore, catalogsWithExclude, catalogRefMap);
  }

  private void mapIncludeProducts(List<CatalogPayloadDto> catalogs,
      Map<String, CatalogQualificationTypeEnum> catalogRefMap,
      PromotionStore promotionStore) {
    List<CatalogPayloadDto> catalogsWithInclude = catalogs.stream()
        .filter(catalog -> Objects.nonNull(catalog.products()) &&
            Objects.nonNull(catalog.products().include()))
        .toList();

    mapProductType(promotionStore, catalogsWithInclude);
    mapIncludeBrands(promotionStore, catalogsWithInclude);
    mapIncludePcrs(promotionStore, catalogsWithInclude);
    mapIncludeMerchBuckets(promotionStore, catalogsWithInclude);
    mapIncludeDigitalTaxonomies(promotionStore, catalogsWithInclude);
    mapIncludeItemDetails(promotionStore, catalogsWithInclude, catalogRefMap);
  }

  private static void mapProductType(PromotionStore promotionStore,
      List<CatalogPayloadDto> catalogsWithInclude) {
    promotionStore.setIncludeProductTypes(catalogsWithInclude.stream()
        .map(catalog -> catalog.products().include().productType())
        .collect(
            Collectors.toSet()));
  }

  private void mapIncludeItemDetails(PromotionStore promotionStore,
      List<CatalogPayloadDto> catalogsWithInclude,
      Map<String, CatalogQualificationTypeEnum> catalogRefMap) {

    Set<IncludeItemStores> includeItemStores = new HashSet<>(Collections.emptySet());

    catalogsWithInclude.forEach(catalog -> {
      String catalogId = catalog.catalogId();
      CatalogQualificationTypeEnum catalogQualificationTypeEnum = catalogRefMap.get(
          catalogId);
      includeItemStores.addAll(mapIncludeItemStores(catalog.products().include().itemDetails(),
          catalogQualificationTypeEnum));
    });

    promotionStore.setIncludeItemStores(includeItemStores);
  }

  private Boolean isNationalOffer(Set<IncludeItemStores> includeItemStores) {
    return includeItemStores.stream()
        .noneMatch(offer -> !CollectionUtils.isEmpty(offer.getStores()) ||
            !CollectionUtils.isEmpty(offer.getPatches()));
  }

  private List<IncludeItemStores> mapIncludeItemFromUploadCatalog(
      UploadFileDtoPayloadDto uploadFileDto) {

    List<ExternalCatalogItemPayloadDto> uploadCatalogItems = createUploadCatalogItems(
        uploadFileDto);
    return uploadCatalogItems.stream().map(this::createIncludeItemStores).toList();
  }

  private Set<IncludeItemStores> mapItemExternalCatalog(ValidationResponse validationResponse) {
    if (!CollectionUtils.isEmpty(validationResponse.successItems())) {
      List<ExternalCatalogItemPayloadDto> uploadCatalogItems = createExternalCatalogItems(
          validationResponse);
      return uploadCatalogItems.stream().map(this::createIncludeItemStores)
          .collect(Collectors.toSet());
    }
    return Collections.emptySet();
  }

  private boolean isPatchOffer(Set<IncludeItemStores> itemStores) {
    boolean noneHaveStores = itemStores.stream()
        .noneMatch(itemStore -> !CollectionUtils.isEmpty(itemStore.getStores()));
    boolean atLeastOneHasPatch = itemStores.stream()
        .anyMatch(itemStore -> !CollectionUtils.isEmpty(itemStore.getPatches()));
    return noneHaveStores && atLeastOneHasPatch;
  }

  private void mapExcludeItemDetails(PromotionStore promotionStore,
      List<CatalogPayloadDto> catalogsWithExclude,
      Map<String, CatalogQualificationTypeEnum> catalogRefMap) {

    Set<ExcludeItem> excludeItems = new HashSet<>(Collections.emptySet());

    catalogsWithExclude.forEach(catalog -> {
      String catalogId = catalog.catalogId();
      CatalogQualificationTypeEnum catalogQualificationTypeEnum = catalogRefMap.get(
          catalogId);
      excludeItems.addAll(mapExcludeItems(catalog.products().exclude().itemDetails(),
          catalogQualificationTypeEnum));
    });

    promotionStore.setExcludeItems(excludeItems);
  }

  private void mapIncludeBrands(PromotionStore promotionStore,
      List<CatalogPayloadDto> catalogsWithInclude) {
    List<KeyValuePayloadDto> includeBrands =
        catalogsWithInclude.stream()
            .flatMap(catalog -> catalog.products().include().brands().stream()).toList();

    promotionStore.setIncludeBrandIds(mapKeyFromKeyValues(includeBrands));
    promotionStore.setIncludeBrandNames(mapValueFromKeyValues(includeBrands));
  }

  private void mapExcludeBrands(PromotionStore promotionStore,
      List<CatalogPayloadDto> catalogsWithExclude) {
    List<KeyValuePayloadDto> excludeBrands =
        catalogsWithExclude.stream()
            .flatMap(catalog -> catalog.products().exclude().brands().stream()).toList();

    promotionStore.setExcludeBrandIds(mapKeyFromKeyValues(excludeBrands));
    promotionStore.setExcludeBrandNames(mapValueFromKeyValues(excludeBrands));
  }

  private void mapIncludeMerchBuckets(PromotionStore promotionStore,
      List<CatalogPayloadDto> catalogsWithInclude) {
    List<KeyValuePayloadDto> includeMerchBuckets =
        catalogsWithInclude.stream()
            .flatMap(catalog -> catalog.products().include().merchBuckets().stream())
            .toList();

    promotionStore.setIncludeMerchBucketIds(mapKeyFromKeyValues(includeMerchBuckets));
    promotionStore.setIncludeMerchBucketNames(mapValueFromKeyValues(includeMerchBuckets));
  }

  private void mapExcludeMerchBuckets(PromotionStore promotionStore,
      List<CatalogPayloadDto> catalogsWithExclude) {
    List<KeyValuePayloadDto> excludeMerchBuckets =
        catalogsWithExclude.stream()
            .flatMap(catalog -> catalog.products().exclude().merchBuckets().stream())
            .toList();

    promotionStore.setExcludeMerchBucketIds(mapKeyFromKeyValues(excludeMerchBuckets));
    promotionStore.setExcludeMerchBucketNames(mapValueFromKeyValues(excludeMerchBuckets));
  }

  private void mapIncludeDigitalTaxonomies(PromotionStore promotionStore,
      List<CatalogPayloadDto> catalogsWithInclude) {
    List<KeyValuePayloadDto> includeDigitalTaxonomies =
        catalogsWithInclude.stream()
            .flatMap(catalog -> catalog.products().include().digitalTaxonomies().stream())
            .toList();

    promotionStore.setIncludeDigitalTaxonomyIds(mapKeyFromKeyValues(includeDigitalTaxonomies));
    promotionStore.setIncludeDigitalTaxonomyNames(mapValueFromKeyValues(includeDigitalTaxonomies));
  }

  private void mapExcludeDigitalTaxonomies(PromotionStore promotionStore,
      List<CatalogPayloadDto> catalogsWithExclude) {
    List<DigitalTaxonomyExcludePayloadDto> excludeDigitalTaxonomies =
        catalogsWithExclude.stream()
            .flatMap(catalog -> catalog.products().exclude().digitalTaxonomies().stream())
            .toList();

    promotionStore.setExcludeDigitalTaxonomyIds(excludeDigitalTaxonomies.stream()
        .map(DigitalTaxonomyExcludePayloadDto::id)
        .collect(
            Collectors.toSet()));
    promotionStore.setExcludeDigitalTaxonomyNames(excludeDigitalTaxonomies.stream()
        .map(DigitalTaxonomyExcludePayloadDto::value)
        .collect(
            Collectors.toSet()));
  }

  private void mapIncludePcrs(PromotionStore promotionStore,
      List<CatalogPayloadDto> catalogsWithInclude) {
    Set<String> includePcrs =
        catalogsWithInclude.stream()
            .flatMap(catalog -> catalog.products().include().pcrs().stream()).collect(
                Collectors.toSet());

    promotionStore.setIncludePcrs(includePcrs);
  }


  private Set<String> mapKeyFromKeyValues(List<KeyValuePayloadDto> keyValues) {
    return keyValues.stream()
        .map(KeyValuePayloadDto::id)
        .collect(Collectors.toSet());
  }

  private Set<String> mapValueFromKeyValues(List<KeyValuePayloadDto> keyValues) {
    return keyValues.stream().map(KeyValuePayloadDto::value)
        .collect(Collectors.toSet());
  }

  private void mapTiers(SpotlightOfferPayloadDto spotlightOfferDTO,
      PromotionStore promotionStore) {
    List<TierPayloadDto> tiers = spotlightOfferDTO.tiers();
    if (!CollectionUtils.isEmpty(tiers)) {

      mapFieldsFromFirstTier(promotionStore, tiers);
      mapTierSpecificFields(promotionStore, tiers);
    }
  }

  private void mapTierSpecificFields(PromotionStore promotionStore,
      List<TierPayloadDto> tiers) {
    if (!CollectionUtils.isEmpty(tiers)) {

      promotionStore.setConditionGroupQuantity(tiers.stream()
          .filter(tier -> !CollectionUtils.isEmpty(tier.conditionGroups()))
          .flatMap(tier -> tier.conditionGroups()
              .stream())
          .filter(
              conditionGroup -> !CollectionUtils.isEmpty(conditionGroup.itemConditionAttributes()))
          .filter(conditionGroup -> conditionGroup.itemConditionAttributes()
              .get(0)
              .unit() ==
              UnitEnum.QUANTITY)
          .map(conditionGroup -> conditionGroup.itemConditionAttributes()
              .get(0)
              .value())
          .collect(Collectors.toSet()));

      promotionStore.setConditionGroupSpend(tiers.stream()
          .filter(tier -> !CollectionUtils.isEmpty(tier.conditionGroups()))
          .flatMap(tier -> tier.conditionGroups()
              .stream())
          .filter(
              conditionGroup -> !CollectionUtils.isEmpty(conditionGroup.itemConditionAttributes()))
          .filter(conditionGroup -> conditionGroup.itemConditionAttributes()
              .get(0)
              .unit() ==
              UnitEnum.SPEND)
          .map(conditionGroup -> conditionGroup.itemConditionAttributes()
              .get(0)
              .value())
          .collect(Collectors.toSet()));

      promotionStore.setRewardGroupsItemAttrQuantity(tiers.stream()
          .filter(tier -> !CollectionUtils.isEmpty(tier.rewardGroups()))
          .flatMap(tier -> tier.rewardGroups().stream())
          .filter(rewardGroup -> !CollectionUtils.isEmpty(rewardGroup.itemConditionAttributes()))
          .map(rewardGroup -> rewardGroup.itemConditionAttributes()
              .get(0))
          .filter(rewardItemAttributes -> rewardItemAttributes.unit() ==
              UnitEnum.QUANTITY)
          .map(RewardItemAttributesPayloadDto::value)
          .collect(Collectors.toSet()));

      promotionStore.setRewardGroupsItemAttrSpend(tiers.stream()
          .filter(tier -> !CollectionUtils.isEmpty(tier.rewardGroups()))
          .flatMap(tier -> tier.rewardGroups().stream())
          .filter(rewardGroup -> !CollectionUtils.isEmpty(rewardGroup.itemConditionAttributes()))
          .map(rewardGroup -> rewardGroup.itemConditionAttributes().get(0))
          .filter(rewardItemAttributes -> rewardItemAttributes.unit() ==
              UnitEnum.SPEND)
          .map(RewardItemAttributesPayloadDto::value).collect(Collectors.toSet()));

      promotionStore.setRewardAttrQuantity(tiers.stream()
          .filter(tier -> !CollectionUtils.isEmpty(tier.rewardGroups()))
          .flatMap(tier -> tier.rewardGroups().stream())
          .filter(rewardGroup -> Objects.nonNull(rewardGroup.rewardAttributes()))
          .map(rewardGroup -> rewardGroup.rewardAttributes().rewardQuantity())
          .collect(Collectors.toSet()));

      promotionStore.setRewardAttrDiscountValue(tiers.stream()
          .filter(tier -> !CollectionUtils.isEmpty(tier.rewardGroups()))
          .flatMap(tier -> tier.rewardGroups().stream())
          .filter(rewardGroup -> Objects.nonNull(rewardGroup.rewardAttributes()))
          .map(rewardGroup -> rewardGroup.rewardAttributes().discountValue())
          .collect(Collectors.toSet()));

      promotionStore.setRewardAttrQuantityValue(tiers.stream()
          .filter(tier -> !CollectionUtils.isEmpty(tier.rewardGroups()))
          .flatMap(tier -> tier.rewardGroups().stream())
          .filter(rewardGroup -> Objects.nonNull(rewardGroup.rewardAttributes()))
          .map(rewardGroup -> rewardGroup.rewardAttributes().quantityValue())
          .collect(Collectors.toSet()));
    }
  }

  private void mapFieldsFromFirstTier(PromotionStore promotionStore,
      List<TierPayloadDto> tiers) {
    TierPayloadDto firstTier = tiers.get(0);
    mapConditionFieldsFromFirstTier(firstTier, promotionStore);
    mapRewardFieldsFromFirstTier(firstTier, promotionStore);
  }

  private void mapRewardFieldsFromFirstTier(TierPayloadDto firstTier,
      PromotionStore promotionStore) {

    promotionStore.setRewardGroupsRewardType(firstTier.rewardGroups()
        .stream()
        .map(RewardGroupPayloadDto::rewardType)
        .filter(Objects::nonNull)
        .collect(Collectors.toSet()));
    promotionStore.setRewardGroupsRewardOn(firstTier.rewardGroups()
        .stream()
        .map(RewardGroupPayloadDto::rewardOn)
        .filter(Objects::nonNull)
        .collect(Collectors.toSet()));

    promotionStore.setRewardAttrDiscountType(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.rewardAttributes()))
        .map(rewardGroup -> rewardGroup.rewardAttributes().discountType())
        .collect(Collectors.toSet()));
    promotionStore.setRewardAttrDiscountOn(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.rewardAttributes()))
        .map(rewardGroup -> rewardGroup.rewardAttributes().discountOn())
        .collect(Collectors.toSet()));

    promotionStore.setRewardGroupsShippingMethod(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.shippingAttributes()))
        .flatMap(rewardGroup -> rewardGroup.shippingAttributes()
            .shippingTypes()
            .stream())
        .map(ShippingTypeFieldsPayloadDto::shippingMethod)
        .collect(Collectors.toSet()));
    promotionStore.setRewardGroupsShippingCategory(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.shippingAttributes()))
        .flatMap(rewardGroup -> rewardGroup.shippingAttributes()
            .shippingTypes()
            .stream())
        .map(ShippingTypeFieldsPayloadDto::category)
        .collect(Collectors.toSet()));
    promotionStore.setRewardGroupsShippingType(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.shippingAttributes()))
        .flatMap(rewardGroup -> rewardGroup.shippingAttributes()
            .shippingTypes()
            .stream())
        .map(ShippingTypeFieldsPayloadDto::type)
        .collect(Collectors.toSet()));
    promotionStore.setRewardGroupsShippingFulfillmentType(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.shippingAttributes()))
        .flatMap(rewardGroup -> rewardGroup.shippingAttributes()
            .shippingTypes()
            .stream())
        .map(ShippingTypeFieldsPayloadDto::fulfillmentType)
        .collect(Collectors.toSet()));
    promotionStore.setRewardGroupsFinanceType(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.financeAttributes()))
        .map(rewardGroup -> rewardGroup.financeAttributes().financeType())
        .collect(Collectors.toSet()));
    promotionStore.setRewardGroupsFinanceMonths(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.financeAttributes()))
        .map(rewardGroup -> rewardGroup.financeAttributes().months())
        .collect(Collectors.toSet()));
    promotionStore.setRewardGroupsFinanceTermType(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.financeAttributes()))
        .map(rewardGroup -> rewardGroup.financeAttributes()
            .termType())
        .collect(Collectors.toSet()));
    promotionStore.setRewardGroupsFinanceBlockCode(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.financeAttributes()))
        .map(rewardGroup -> rewardGroup.financeAttributes()
            .blockCode())
        .collect(Collectors.toSet()));
    promotionStore.setRewardGroupsFinanceAnnualPercentRate(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.financeAttributes()))
        .map(rewardGroup -> rewardGroup.financeAttributes()
            .annualPercentRate())
        .collect(Collectors.toSet()));
    promotionStore.setRewardGroupsFinanceTermIdentifier(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> Objects.nonNull(rewardGroup.financeAttributes()))
        .map(rewardGroup -> rewardGroup.financeAttributes()
            .termIdentifier())
        .collect(Collectors.toSet()));

    promotionStore.setRewardGroupsItemAttrCatalogRef(firstTier.rewardGroups()
        .stream()
        .filter(rewardGroup -> !CollectionUtils.isEmpty(
            rewardGroup.itemConditionAttributes()))
        .map(rewardGroup -> rewardGroup.itemConditionAttributes()
            .get(0)
            .catalogRef())
        .collect(Collectors.toSet()));

  }

  private void mapConditionFieldsFromFirstTier(TierPayloadDto firstTier,
      PromotionStore promotionStore) {
    promotionStore.setConditionGroupConditionType(firstTier.conditionGroups()
        .stream()
        .map(ConditionGroupPayloadDto::conditionType)
        .filter(Objects::nonNull)
        .collect(
            Collectors.toSet()));
    promotionStore.setConditionGroupConditionOn(firstTier.conditionGroups()
        .stream()
        .map(ConditionGroupPayloadDto::conditionOn)
        .filter(Objects::nonNull)
        .collect(
            Collectors.toSet()));
    promotionStore.setConditionGroupPurchaseMode(firstTier.conditionGroups()
        .stream()
        .filter(conditionGroup -> !CollectionUtils.isEmpty(
            conditionGroup.itemConditionAttributes()))
        .map(conditionGroup -> conditionGroup.itemConditionAttributes()
            .get(0)
            .purchaseMode())
        .filter(Objects::nonNull)
        .collect(
            Collectors.toSet()));
    promotionStore.setConditionGroupPaymentModes(firstTier.conditionGroups()
        .stream()
        .filter(conditionGroup -> !CollectionUtils.isEmpty(
            conditionGroup.itemConditionAttributes()))
        .map(conditionGroup -> conditionGroup.itemConditionAttributes()
            .get(0).paymentModes())
        .filter(Objects::nonNull)
        .flatMap(List::stream)
        .collect(Collectors.toSet()));
    promotionStore.setConditionGroupCatalogRef(firstTier.conditionGroups()
        .stream()
        .filter(conditionGroup -> !CollectionUtils.isEmpty(
            conditionGroup.itemConditionAttributes()))
        .map(conditionGroup -> conditionGroup.itemConditionAttributes()
            .get(0)
            .catalogRef())
        .filter(Objects::nonNull)
        .collect(Collectors.toSet()));

    promotionStore.getConditionGroupCatalogRef().addAll(firstTier.conditionGroups()
        .stream()
        .filter(conditionGroup -> Objects.nonNull(
            conditionGroup.iloConditionAttributes()))
        .map(conditionGroup -> conditionGroup.iloConditionAttributes()
            .catalogRef())
        .filter(Objects::nonNull)
        .collect(Collectors.toSet()));

    promotionStore.setConditionGroupDiscountType(firstTier.conditionGroups()
        .stream()
        .filter(conditionGroup -> Objects.nonNull(
            conditionGroup.iloConditionAttributes()))
        .map(conditionGroup -> conditionGroup.iloConditionAttributes()
            .discountType())
        .filter(Objects::nonNull)
        .collect(Collectors.toSet()));
  }

  private void setForecastAccuracyIndicator(PromotionStore promotionStore,
      OfferIntegrationCompatibilityPayloadDto offerIntegrationCompatibilityPayloadDto) {
    if (Objects.nonNull(offerIntegrationCompatibilityPayloadDto)
        && !offerIntegrationCompatibilityPayloadDto.isSupportedByCalc()) {
      promotionStore.setAccuracyIndicator(ApplicationConstants.FORECAST_UNSUPPORTED_INDICATOR);
    }
  }

}