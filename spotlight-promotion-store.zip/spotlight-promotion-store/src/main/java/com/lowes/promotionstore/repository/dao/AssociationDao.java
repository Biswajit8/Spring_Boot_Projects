package com.lowes.promotionstore.repository.dao;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowes.promotionstore.component.publisher.OfferAmplificationPublisher;
import com.lowes.promotionstore.entity.amplification.ActivityAssociation;
import com.lowes.promotionstore.entity.amplification.ActivityAssociationType;
import com.lowes.promotionstore.entity.amplification.AssociationState;
import com.lowes.promotionstore.entity.amplification.OfferActivityEvent;
import com.lowes.promotionstore.entity.amplification.RelationType;
import com.lowes.promotionstore.model.record.feedback.BlockPayloadDto;
import com.lowes.promotionstore.model.record.feedback.OfferEventPayloadDto;
import com.lowes.promotionstore.model.record.feedback.PagePayloadDto;
import com.lowes.promotionstore.repository.postgres.ActivityAssociationRepository;
import com.lowes.promotionstore.repository.postgres.OfferActivityEventRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import static com.lowes.promotionstore.entity.amplification.AssociationState.ADDED;

@Slf4j
@Service
@RequiredArgsConstructor
public class AssociationDao {

  private final ActivityAssociationRepository associationRepo;
  private final OfferActivityEventRepository offerStatusRepo;
  private final OfferAmplificationPublisher publisher;
  private final ObjectMapper objectMapper;
  private final PageDao pageDao;
  private final BlockDao blockDao;

  /**
   * Convenience: persist whatever associations are present on ACTIVITY/CREATE.
   */
  public Optional<RelationType> persistAssociationsOnActivityCreate(OfferEventPayloadDto payload)
      throws BadRequestException {
    String activityId = payload.getActivity() != null ? payload.getActivity().getId() : null;
    log.info("assoc.persistOnActivityCreate start activityId={}", activityId);

    Optional<RelationType> transition = Optional.empty();

    if (Objects.nonNull(activityId)) {
      if (Objects.nonNull(payload.getOffer())
          && Objects.nonNull(payload.getOffer().getOfferId())
          && Objects.nonNull(payload.getOffer().getAllocationId())) {
        transition = upsertOfferAssociation(payload);
      }
      if (Objects.nonNull(payload.getCampaign()) && Objects.nonNull(
          payload.getCampaign().getId())) {
        String pageId = payload.getPage() != null ? payload.getPage().getId() : null;
        String blockId = payload.getBlock() != null ? payload.getBlock().getId() : null;
        upsertGenericAssociation(
            activityId,
            ActivityAssociationType.CAMPAIGN,
            payload.getCampaign().getId(),
            null,
            payload.getCampaign(),
            pageId,
            blockId
        );
      }
    }

    log.info("assoc.persistOnActivityCreate end activityId={} transition={}",
        activityId, transition.orElse(null));
    return transition;
  }

  /**
   * ---------- OFFER (lock/unlock aware) ----------
   **/
  @Transactional
  public Optional<RelationType> upsertOfferAssociation(OfferEventPayloadDto payload)
      throws BadRequestException {
    String offerId = req(payload.getOffer()).getOfferId();
    String activityId = req(payload.getActivity()).getId();
    String allocationId = req(payload.getOffer()).getAllocationId();
    String pageId = payload.getPage() != null ? payload.getPage().getId() : null;
    String blockId = payload.getBlock() != null ? payload.getBlock().getId() : null;

    if (offerId == null || activityId == null || allocationId == null) {
      log.warn(
          "Rejecting offer upsert due to missing ids. activityId={} offerId={} alloc={} pageId={} blockId={}",
          activityId, offerId, allocationId, pageId, blockId);
      throw new BadRequestException(
          "Invalid payload: activity.id, offer.offerId, offer.allocationId, offer.pageId and offer.blockId are required");
    }

    log.info("offer.assoc.upsert start activityId={} offerId={} alloc={} pageId={} blockId={}",
        activityId, offerId,
        allocationId, pageId, blockId);

    boolean hadActive = associationRepo.existsByEntityTypeAndEntityIdAndState(
        ActivityAssociationType.OFFER, offerId, ADDED);

    var row = associationRepo
        .findByActivityIdAndEntityTypeAndEntityIdAndAllocationId(
            activityId, ActivityAssociationType.OFFER, offerId, allocationId)
        .orElseGet(() -> ActivityAssociation.builder()
            .activityId(activityId)
            .entityType(ActivityAssociationType.OFFER)
            .entityId(offerId)
            .allocationId(allocationId)
            .state(ADDED)
            .createdAt(LocalDateTime.now(ZoneOffset.UTC))
            .build());

    row.setPageId(pageId);
    row.setBlockId(blockId);
    row.setState(ADDED);
    row.setUpdatedAt(LocalDateTime.now(ZoneOffset.UTC));
    try {
      row.setPayload(objectMapper.writeValueAsString(payload.getOffer()));
    } catch (Exception e) {
      log.warn("Failed to serialize offer payload for activityId={} offerId={} alloc={}",
          activityId, offerId, allocationId, e);
      row.setPayload(null);
    }

    pageDao.upsertPage(payload);
    blockDao.upsertBlock(payload);
    try {
      associationRepo.saveAndFlush(row);
    } catch (DataIntegrityViolationException dup) {
      log.debug("Duplicate during upsert; re-reading activityId={} offerId={} alloc={}", activityId,
          offerId, allocationId);
      row = associationRepo.findByActivityIdAndEntityTypeAndEntityIdAndAllocationId(
          activityId, ActivityAssociationType.OFFER, offerId, allocationId).orElse(row);
    }

    boolean hasActive = associationRepo.existsByEntityTypeAndEntityIdAndState(
        ActivityAssociationType.OFFER, offerId, ADDED);

    if (!hadActive && hasActive) {
      log.info("offer.lock transition ACTIVE 0→1 activityId={} offerId={} alloc={}", activityId,
          offerId, allocationId);
      // record event but DO NOT publish
      recordOfferStatus(offerId, RelationType.LOCKED);
      log.info("offer.assoc.upsert end activityId={} offerId={} alloc={}", activityId, offerId,
          allocationId);
      return Optional.of(RelationType.LOCKED);
    }

    log.info("offer.assoc.upsert end activityId={} offerId={} alloc={}", activityId, offerId,
        allocationId);
    return Optional.empty();
  }

  @Transactional
  public Optional<RelationType> deleteOfferAssociation(OfferEventPayloadDto payload) {
    String offerId = req(payload.getOffer()).getOfferId();
    String activityId = req(payload.getActivity()).getId();
    String allocationId = req(payload.getOffer()).getAllocationId();

    log.info("offer.assoc.delete start activityId={} offerId={} alloc={}", activityId, offerId,
        allocationId);

    boolean hadActive = associationRepo.existsByEntityTypeAndEntityIdAndState(
        ActivityAssociationType.OFFER, offerId, AssociationState.ADDED);

    associationRepo.findByActivityIdAndEntityTypeAndEntityIdAndAllocationId(
            activityId, ActivityAssociationType.OFFER, offerId, allocationId)
        .ifPresent(row -> {
          if (row.getState() != AssociationState.DELETED) {
            row.setState(AssociationState.DELETED);
            row.setUpdatedAt(LocalDateTime.now(ZoneOffset.UTC));
            associationRepo.save(row);
          }
        });

    boolean hasActive = associationRepo.existsByEntityTypeAndEntityIdAndState(
        ActivityAssociationType.OFFER, offerId, AssociationState.ADDED);

    if (hadActive && !hasActive) {
      log.info("offer.unlock transition ACTIVE 1→0 activityId={} offerId={} alloc={}", activityId,
          offerId, allocationId);
      // record event but DO NOT publish
      recordOfferStatus(offerId, RelationType.UNLOCKED);
      log.info("offer.assoc.delete end activityId={} offerId={} alloc={}", activityId, offerId,
          allocationId);
      return Optional.of(RelationType.UNLOCKED);
    }

    log.info("offer.assoc.delete end activityId={} offerId={} alloc={}", activityId, offerId,
        allocationId);
    return Optional.empty();
  }

  // Replace previous upsertOfferStatusAndPublishAfterCommit with record-only
  private void recordOfferStatus(String offerId, RelationType type) {
    var ev = offerStatusRepo.findById(offerId)
        .orElse(OfferActivityEvent.builder()
            .offerId(offerId)
            .relationType(type)
            .occurredAt(nowUtc())
            .build());
    ev.setRelationType(type);
    ev.setOccurredAt(nowUtc());
    offerStatusRepo.save(ev);
    log.info("Offer status recorded (no publish here): offerId={}, {}", offerId, type);
  }


  @Transactional
  public void upsertGenericAssociation(
      String activityId,
      ActivityAssociationType type,
      String entityId,
      String allocationId,
      Object snapshotJsonable,
      String pageId,
      String blockId
  ) {
    if (type == ActivityAssociationType.OFFER) {
      throw new IllegalArgumentException(
          "Use upsertOfferAssociation(...) for OFFER to preserve lock/unlock behavior.");
    }

    log.info("assoc.generic.upsert start activityId={} type={} entityId={} alloc={}", activityId,
        type, entityId, allocationId);

    Optional<ActivityAssociation> existing;
    ActivityAssociation row;
    if (type.equals(ActivityAssociationType.CAMPAIGN)) {
      existing = associationRepo.findByActivityIdAndEntityType(req(activityId), type);
    } else {
      existing = associationRepo.findByActivityIdAndEntityTypeAndEntityIdAndAllocationId(
          req(activityId), req(type), req(entityId), allocationId);
    }

    row = existing.orElseGet(() -> ActivityAssociation.builder()
        .activityId(activityId)
        .entityType(type)
        .allocationId(allocationId)
        .state(ADDED)
        .createdAt(LocalDateTime.now(ZoneOffset.UTC))
        .build());

    row.setPageId(pageId);
    row.setBlockId(blockId);
    row.setEntityId(entityId);
    row.setState(ADDED);
    row.setUpdatedAt(LocalDateTime.now(ZoneOffset.UTC));
    try {
      row.setPayload(
          snapshotJsonable == null ? null : objectMapper.writeValueAsString(snapshotJsonable));
    } catch (Exception e) {
      log.warn("Failed to serialize {} payload for entityId={}", type, entityId, e);
      row.setPayload(null);
    }

    if (Objects.isNull(existing) && type.equals(ActivityAssociationType.CAMPAIGN)) {
      associationRepo.updateCampaignAssoc(activityId, row.getEntityType(), row.getState(),
          row.getPayload());
      log.info("assoc.generic.upsert end activityId={} type={} entityId={} alloc={}", activityId,
          type, entityId, allocationId);
      return;
    }

    associationRepo.saveAndFlush(row);
    log.info("assoc.generic.upsert end activityId={} type={} entityId={} alloc={}", activityId,
        type, entityId, allocationId);
  }


  @Transactional
  public void deleteGenericAssociation(
      String activityId,
      ActivityAssociationType type,
      String entityId,
      String allocationId
  ) {
    if (type == ActivityAssociationType.OFFER) {
      throw new IllegalArgumentException(
          "Use deleteOfferAssociation(...) for OFFER to preserve lock/unlock behavior.");
    }

    log.info("assoc.generic.delete start activityId={} type={} entityId={} alloc={}", activityId,
        type, entityId, allocationId);

    associationRepo.findByActivityIdAndEntityTypeAndEntityIdAndAllocationId(
            req(activityId), req(type), req(entityId), allocationId)
        .ifPresent(row -> {
          if (row.getState() != AssociationState.DELETED) {
            row.setState(AssociationState.DELETED);
            row.setUpdatedAt(LocalDateTime.now(ZoneOffset.UTC));
            associationRepo.save(row);
          }
        });

    log.info("assoc.generic.delete end activityId={} type={} entityId={} alloc={}", activityId,
        type, entityId, allocationId);
  }

  @Transactional
  public Map<String, RelationType> bulkLinkDelinkActivity(String activityId, RelationType type) {
    var id = Objects.requireNonNull(activityId, "activityId");
    var now = LocalDateTime.now(ZoneOffset.UTC);
    Map<String, RelationType> transitions = new java.util.LinkedHashMap<>();

    List<String> impactedOffers = associationRepo.findExclusiveEntityIdsForActivityNative(
        ActivityAssociationType.OFFER.toString(),
        ADDED.toString(), id);

    for (String offerId : impactedOffers) {
      if (Objects.nonNull(offerId)) {
        recordOfferStatus(offerId, type);
        transitions.put(offerId, type);
        log.info("offer.unlock ACTIVE 1→0 activityId={} offerId={}", id, offerId);
      }
    }

    return transitions;
  }


  private static <T> T req(T v) {
    if (v == null) {
      throw new IllegalArgumentException("Required value is null");
    }
    return v;
  }

  private static LocalDateTime nowUtc() {
    return LocalDateTime.now(ZoneOffset.UTC);
  }

  @Transactional
  public void deletePageAssociation(String activityId, PagePayloadDto page) {
    String pageId = page.getId();
    log.info("deletePageAssociation activityId={}, pageId={}", activityId, pageId);

    List<ActivityAssociation> associations = associationRepo.findByActivityIdAndPageIdAndState(
        activityId, pageId, AssociationState.ADDED);

    if (associations.isEmpty()) {
      log.warn("No ADDED association found for activityId={}, pageId={}", activityId, pageId);
    } else {
      associations.forEach(association -> {
        association.setState(AssociationState.DELETED);
        association.setUpdatedAt(LocalDateTime.now(ZoneOffset.UTC));
        associationRepo.save(association);
        log.info(
            "Page association marked as DELETED for activityId={}, pageId={}, associationId={}",
            activityId, pageId, association.getId());
      });
      log.info("Total {} page association(s) marked as DELETED for activityId={}, pageId={}",
          associations.size(), activityId, pageId);
    }
  }

  public void deleteBlockAssociation(String activityId, String pageId, BlockPayloadDto block) {
    String blockId = block.getId();
    log.info("deleteBlockAssociation activityId={}, pageId={}, blockId={}", activityId, pageId,
        blockId);

    List<ActivityAssociation> associations = associationRepo.findByActivityIdAndPageIdAndBlockIdAndState(
        activityId, pageId, blockId, AssociationState.ADDED);

    if (associations.isEmpty()) {
      log.warn("No ADDED association found for activityId={}, pageId={}, blockId={}",
          activityId, pageId, blockId);
    } else {
      associations.forEach(association -> {
        association.setState(AssociationState.DELETED);
        association.setUpdatedAt(LocalDateTime.now(ZoneOffset.UTC));
        associationRepo.save(association);
        log.info(
            "Block association marked as DELETED for activityId={}, blockId={}, associationId={}",
            activityId, blockId, association.getId());
      });
      log.info(
          "Total {} block association(s) marked as DELETED for activityId={}, pageId={}, blockId={}",
          associations.size(), activityId, pageId, blockId);
    }
  }

  public List<ActivityAssociation> findAllAssociatedPage(String activityId, PagePayloadDto page) {
    return associationRepo.findByActivityIdAndPageIdAndStateAndEntityType(activityId, page.getId(),
        AssociationState.ADDED, ActivityAssociationType.OFFER);
  }

  public List<String> getAllLockedOffers() {
    return offerStatusRepo.findOfferIdsByRelationType(RelationType.LOCKED.name());
  }
}