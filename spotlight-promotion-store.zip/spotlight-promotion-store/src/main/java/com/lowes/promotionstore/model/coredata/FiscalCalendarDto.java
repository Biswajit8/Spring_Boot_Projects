package com.lowes.promotionstore.model.coredata;

import com.lowes.promotionstore.constants.enums.CalendarUnitType;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Data
@Getter
@Setter
public class FiscalCalendarDto {

  private Long calId;

  @NotBlank
  private String name;

  @NotNull
  private LocalDate startDate;

  @NotNull
  private LocalDate endDate;

  @Min(1)
  @Max(52)
  private Integer weekId;

  @Min(2000)
  @Max(9999)
  private Integer promoYear;

  @Min(2000)
  @Max(9999)
  private Integer fiscalYear;

  @Min(1)
  @Max(4)
  private Integer fiscalQuarter;

  private CalendarUnitType calendarUnitType;

}