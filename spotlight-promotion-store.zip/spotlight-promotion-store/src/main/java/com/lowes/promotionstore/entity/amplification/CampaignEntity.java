package com.lowes.promotionstore.entity.amplification;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@SuppressWarnings("java:S1068")
@Builder
@Getter
@Setter
public class CampaignEntity {

  private String campaignId;
  private String campaignName;

}