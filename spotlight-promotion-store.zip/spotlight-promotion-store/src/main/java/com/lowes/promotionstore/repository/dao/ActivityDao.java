package com.lowes.promotionstore.repository.dao;

import com.lowes.promotionstore.constants.ApplicationConstants;
import com.lowes.promotionstore.entity.amplification.Activity;
import com.lowes.promotionstore.entity.amplification.ActivityPayloadJson;
import com.lowes.promotionstore.model.record.feedback.ActivityPayloadDto;
import com.lowes.promotionstore.model.record.feedback.OfferEventPayloadDto;
import com.lowes.promotionstore.repository.postgres.ActivityRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.coyote.BadRequestException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.List;
import java.util.Optional;

import static java.util.Objects.requireNonNull;

@Slf4j
@Service
@RequiredArgsConstructor
public class ActivityDao {

  private final ActivityRepository activityRepository;

  @Transactional(readOnly = true)
  public boolean activityExists(String activityId) {
    String id = requireNonNull(activityId, "activityId");
    boolean exists = activityRepository.existsById(id);
    log.debug("activity.exists id={} -> {}", id, exists);
    return exists;
  }

  public boolean activityExistsWithCancelledOrOnHold(String activityId) {
    String id = java.util.Objects.requireNonNull(activityId, "activityId");
    boolean exists = activityRepository.existsWithStatusIn(id, java.util.Set.of(
        ApplicationConstants.CANCELLED, ApplicationConstants.ON_HOLD));
    log.debug("activity.existsWithCancelledOrOnHold id={} -> {}", id, exists);
    return exists;
  }


  @Transactional
  public void createActivity(OfferEventPayloadDto payload) {
    ActivityPayloadDto a = ensureActivity(payload);
    String id = req(a.getId());
    log.info("activity.create start activityId={}", id);

    ActivityPayloadJson pj = ActivityPayloadJson.builder()
        .channel(payload.getChannel())
        .eventType(payload.getType())
        .activityOperation(payload.getOperation())
        .alias(a.getAlias())
        .name(nvl(a.getName(), ""))
        .status(req(a.getStatus()))
        .startDate(req(a.getStartDate()))
        .endDate(req(a.getEndDate()))
        .customers(copyOrEmpty(a.getCustomers()))
        .distribution(copyOrEmpty(a.getDistribution()))
        .build();

    Activity entity = Activity.builder()
        .activityId(id)
        .payload(pj)
        .startDate(pj.getStartDate())
        .endDate(pj.getEndDate())
        .status(pj.getStatus())
        .createdAt(nowUtc())
        .updatedAt(nowUtc())
        .build();

    activityRepository.save(entity);
    log.info("activity.create end activityId={}", id);
  }

  @Transactional
  public String updateActivityFields(OfferEventPayloadDto payload) throws BadRequestException {
    String previousStatus;
    ActivityPayloadDto a = ensureActivity(payload);
    String id = req(a.getId());
    log.info("activity.update start activityId={}", id);
    Activity entity = activityRepository.findById(id)
        .orElseThrow(() ->
            new IllegalStateException("Activity not found for id=" + id));
    if (entity.getStatus().equalsIgnoreCase(ApplicationConstants.CANCELLED) && payload.getActivity()
        .getStatus().equalsIgnoreCase(
            ApplicationConstants.ON_HOLD)) {
      throw new BadRequestException(
          "Cancelled to On-HOLD not possible activity id: " + id);
    }
    ActivityPayloadJson pj = Optional.ofNullable(entity.getPayload())
        .orElse(new ActivityPayloadJson());
    previousStatus = entity.getStatus();
    if (payload.getChannel() != null) {
      pj.setChannel(payload.getChannel());
    }
    if (payload.getType() != null) {
      pj.setEventType(payload.getType());
    }
    if (payload.getOperation() != null) {
      pj.setActivityOperation(payload.getOperation());
    }
    if (a.getAlias() != null) {
      pj.setAlias(a.getAlias());
    }
    if (a.getName() != null) {
      pj.setName(a.getName());
    }
    if (a.getStatus() != null) {
      pj.setStatus(a.getStatus());
    }
    if (a.getStartDate() != null) {
      pj.setStartDate(a.getStartDate());
    }
    if (a.getEndDate() != null) {
      pj.setEndDate(a.getEndDate());
    }
    if (a.getCustomers() != null) {
      pj.setCustomers(copyOrEmpty(a.getCustomers()));
    }
    if (a.getDistribution() != null) {
      pj.setDistribution(copyOrEmpty(a.getDistribution()));
    }

    if (a.getStatus() != null) {
      entity.setStatus(a.getStatus());
    }
    if (a.getStartDate() != null) {
      entity.setStartDate(a.getStartDate());
    }
    if (a.getEndDate() != null) {
      entity.setEndDate(a.getEndDate());
    }

    entity.setPayload(pj);
    entity.setUpdatedAt(nowUtc());

    activityRepository.save(entity);

    log.info("activity.update end activityId={}", id);
    return previousStatus;
  }


  /**
   * Mark the Activity payload as UPDATED due to a campaign change.
   */
  @Transactional
  public void markActivityUpdatedFromCampaign(String activityId, String channel) {
    String id = req(activityId);
    log.info("activity.markUpdatedFromCampaign start activityId={}", id);

    Activity entity = activityRepository.findById(id)
        .orElseThrow(() -> new IllegalStateException("Activity not found for id=" + id));

    ActivityPayloadJson pj = Optional.ofNullable(entity.getPayload())
        .orElse(new ActivityPayloadJson());
    if (channel != null) {
      pj.setChannel(channel);
    }
    pj.setEventType("ACTIVITY");
    pj.setActivityOperation("UPDATE");

    entity.setPayload(pj);
    entity.setUpdatedAt(nowUtc());
    activityRepository.save(entity);

    log.info("activity.markUpdatedFromCampaign end activityId={}", id);
  }

  // -------- helpers --------
  private static <T> T req(T v) {
    if (v == null) {
      throw new IllegalArgumentException("Required value is null");
    }
    return v;
  }


  private static String nvl(String v, String def) {
    return v == null ? def : v;
  }

  private static List<String> copyOrEmpty(List<String> src) {
    return src == null ? List.of() : List.copyOf(src);
  }

  private static LocalDateTime nowUtc() {
    return LocalDateTime.now(ZoneOffset.UTC);
  }

  private static ActivityPayloadDto ensureActivity(OfferEventPayloadDto p) {
    if (p.getActivity() == null) {
      throw new IllegalArgumentException("payload.activity is required");
    }
    return p.getActivity();
  }

  /**
   * Mark the Activity payload as UPDATED due to a page change.
   */
  @Transactional
  public void markActivityUpdatedFromPage(String activityId, String channel) {
    String id = req(activityId);
    log.info("activity.markUpdatedFromPage start activityId={}", id);

    Activity entity = activityRepository.findById(id)
        .orElseThrow(() -> new IllegalStateException("Activity not found for id=" + id));

    ActivityPayloadJson pj = Optional.ofNullable(entity.getPayload())
        .orElse(new ActivityPayloadJson());
    if (channel != null) {
      pj.setChannel(channel);
    }
    pj.setEventType(ApplicationConstants.ACTIVITY);
    pj.setActivityOperation(ApplicationConstants.UPDATE);

    entity.setPayload(pj);
    entity.setUpdatedAt(nowUtc());
    activityRepository.save(entity);

    log.info("activity.markUpdatedFromPage end activityId={}", id);
  }
}




