package com.lowes.promotionstore.repository.postgres;

import com.lowes.promotionstore.entity.amplification.OfferActivityEvent;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface OfferActivityEventRepository extends JpaRepository<OfferActivityEvent, String> {
  // If you model events without surrogate key, change the ID type and methods accordingly.
  @Query(value = "select offer_id from offers_activities_events where relation_type = :relationType", nativeQuery = true)
  List<String> findOfferIdsByRelationType(@Param("relationType") String relationType);
}
