package com.lowes.promotionstore.configuration.properties;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Data
@Configuration
@ConfigurationProperties(prefix = "application.kafka")
public class KafkaProps {

  /**
   * Common SSL/SASL for all clients
   */
  private String trustStoreLocation;
  private String trustStorePassword;
  private String securityProtocol;
  private String saslMechanism;

  private SaslCredentials saslCredentials;
  private Defaults defaults;

  private Consumer consumer;
  private Producer producer;

  // ========= Nested classes =========

  @Data
  public static class Defaults {

    /**
     * Global bootstrap servers for all consumers/producers unless overridden.
     */
    private String bootstrapServers;

    /**
     * Global schema registry URL (for Avro) unless overridden per listener/producer.
     */
    private String schemaRegistryUrl;

    /**
     * Global bootstrap servers for all consumers/producers unless overridden.
     */
    private String bootstrapServerOnprem;
  }

  @Data
  public static class SaslCredentials {

    private UserCredentials onPremUser;
    private UserCredentials spotlightUser;

    @Data
    public static class UserCredentials {

      private String username;
      private String password;
    }
  }

  @Data
  public static class Consumer {

    private ConsumerSpec spotlightPromotionListener;
    private ConsumerSpec spotlightPromotionFullLoadListener;
    private ConsumerSpec offerProductListener;
    private ConsumerSpec offerEventsListener;
    private ConsumerSpec offerFeedbackListener;
  }

  @Data
  public static class Producer {

    private ProducerSpec amplificationFeedbackProducer;
  }

  @Data
  public static class ConsumerSpec {

    private String topic;
    private String groupId;
    private int concurrency = 1;

    private String keyDeserializer;
    private String valueDeserializer;

    private String dtoClass; // (optional for JSON default type)

    private Boolean enabled = Boolean.TRUE;   // <— NEW: flag to create bean or not
    private Boolean batch = Boolean.TRUE;
    private String ackMode = "BATCH";       // RECORD, BATCH, TIME, COUNT, MANUAL, MANUAL_IMMEDIATE
    private String autoOffsetReset = "latest";
    private Boolean observationEnabled = Boolean.FALSE;
    private PayloadFormat format = PayloadFormat.JSON;
    private Boolean enableAutoCommit = Boolean.FALSE;

    private Map<String, String> properties = new HashMap<>();
  }

  @Data
  public static class ProducerSpec {

    private String topic;
    private String keySerializer;
    private String valueSerializer;
    private String valueDefaultType;

    private String acks = "all";
    private Boolean idempotence = Boolean.TRUE;
    private String compressionType = "lz4";
    private Integer lingerMs = 5;
    private Integer batchSize = 1000;

    private Boolean enableTransactions = Boolean.FALSE;
    private String transactionIdPrefix;

    private String schemaRegistryUrl;

    private Map<String, String> extra = new HashMap<>();
  }

  public enum PayloadFormat {
    JSON, AVRO
  }
}
