package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonPropertyOrder({"id", "name", "offerTypeId", "status", "active"})
public record SpotlightOfferPayloadDto(Long id, Long offerTypeId,
                                       PromotionMetaDataPayloadDto metaData, String name,
                                       String offerType,
                                       String offerTypeName, String offerSubType,
                                       String offerSubTypeName,
                                       String shortDescription,
                                       SchedulePayloadDto schedule,
                                       PromotionPayloadEnums.MarketScopeEnum marketScope,
                                       LocationsPayloadDto locations,
                                       CustomerPayloadDto customer,
                                       PromotionPayloadEnums.RedemptionTypeEnum redemptionType,
                                       String couponCode, String autoApplyCode,
                                       PromotionPayloadEnums.StatusEnum status,
                                       List<TierPayloadDto> tiers,
                                       List<CatalogPayloadDto> catalogs,
                                       MarketingInfoPayloadDto marketingInfo, String createdTs,
                                       String createdBy, String modifiedTs, String modifiedBy,
                                       String activatedTs, String activatedBy, Boolean active,
                                       int version,
                                       int activeCounter, String deactivatedTs,
                                       String deactivatedBy,
                                       String termsAndConditions, String sourceSystem,
                                       String offerTactic,
                                       LabelInfoResponse labelInfo,
                                       ForecastDataDto forecastData,
                                       OfferSalesPayloadDto salesData,
                                       OfferGroupDetailsPayloadDto offerGroup, String blackoutDate,
                                       boolean isApprovedAndLocked,
                                       PriceCatalogProductsPayloadDto priceCatalogProducts,
                                       List<VendorFundingInfoPayloadDto> vendorFundingInfo,
                                       List<CommentsPayloadDto> comments,
                                       PromotionPayloadEnums.ExecutionMessageTypeEnum executionMessageType,
                                       StackingGroupPayloadDto stackingGroup, String previousStatus,
                                       String enrichedStatus, AlertsPayloadDto alerts,
                                       OfferIntegrationCompatibilityPayloadDto offerIntegrationCompatibility,
                                       String amplificationChannel,
                                       String createdByEmailId,
                                       String modifiedByEmailId,
                                       String catalogUrl,
                                       Boolean dualMaintenance,
                                       Boolean editingInProgress,
                                       Boolean signage,
                                       ForecastOverridesPayloadDto forecastOverrides,
                                       RebateInfoPayloadDto rebateInfo,
                                       VersionChangesPayloadDto versionChanges,
                                       Integer patchesCount,
                                       Integer featuredItemsCount,
                                       List<String> derivedPatches) {

  public SpotlightOfferPayloadDto {
    if (CollectionUtils.isEmpty(tiers)) {
      tiers = new ArrayList<>();
    }
    if (CollectionUtils.isEmpty(catalogs)) {
      catalogs = new ArrayList<>();
    }
    if (Objects.isNull(alerts)) {
      alerts = new AlertsPayloadDto(Boolean.FALSE, Boolean.FALSE);
    }
  }
}