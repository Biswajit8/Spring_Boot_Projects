package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record TierPayloadDto(int tierId, List<ConditionGroupPayloadDto> conditionGroups,
                             List<RewardGroupPayloadDto> rewardGroups) {

  public TierPayloadDto {
    if (CollectionUtils.isEmpty(conditionGroups)) {
      conditionGroups = new ArrayList<>();
    }

    if (CollectionUtils.isEmpty(rewardGroups)) {
      rewardGroups = new ArrayList<>();
    }

  }
}
