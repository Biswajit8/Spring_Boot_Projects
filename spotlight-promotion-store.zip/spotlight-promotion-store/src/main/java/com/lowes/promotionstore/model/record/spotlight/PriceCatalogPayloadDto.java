package com.lowes.promotionstore.model.record.spotlight;

import java.util.List;

/**
 * Mirrors OfferEventPublishDto.priceCatalog (Avro record "PriceCatalog")
 */
public record PriceCatalogPayloadDto(
    CatalogFileRefDto catalogFileRef,
    String catalogId,
    PriceCatalogProductsDto products
) {

  public record CatalogFileRefDto(
      String originalName,
      String uploadName
  ) {

  }

  public record PriceCatalogProductsDto(
      PriceCatalogProductsIncludeDto include,
      // This points to: com.lowes.generated.model.offerevent.ProductTypeEnum
      com.lowes.generated.model.offerevent.ProductTypeEnum productType,
      PriceCatalogType priceCatalogType
  ) {

  }

  public record PriceCatalogProductsIncludeDto(
      List<PriceCatalogItemDetailDto> itemDetails
  ) {

  }

  public record PriceCatalogItemDetailDto(
      String id,
      String itemDesc,
      String itemNo,
      LocationsDto locations,
      String value,
      Boolean isoFlag,
      // Avro default is false, but keep nullable to match union ["null","boolean"]
      String futureBasePrice,
      String ecpPrice,
      String pmap,
      String housePromo,
      String inOutCart,
      String onlineNowPrice,
      String storePrice
  ) {

  }

  public record LocationsDto(
      boolean includeAllStores,
      List<String> patches,
      List<String> stores
  ) {

  }

  public enum PriceCatalogType {
    STOCK, SOS
  }
}

