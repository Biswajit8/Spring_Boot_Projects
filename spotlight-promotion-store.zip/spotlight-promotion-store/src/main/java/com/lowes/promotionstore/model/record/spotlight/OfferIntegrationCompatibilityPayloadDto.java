package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.Set;

@JsonIgnoreProperties(ignoreUnknown = true)
public record OfferIntegrationCompatibilityPayloadDto(boolean isSupportedByCalc,
                                                      boolean isSupportedByVendorFunding,
                                                      Set<String> indicators) {

}
