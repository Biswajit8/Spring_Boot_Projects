package com.lowes.promotionstore.model.coredata.uploaditems;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@SuppressWarnings("java:S1068")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ExternalCatalogItemPayloadDto implements Serializable {

  private static final long serialVersionUID = 9215250887215568287L;

  private String itemNumber;
  private String offerPrice;
  private String discountType;
  private String discountValue;
  private List<String> patches;
  private List<String> stores;
}


