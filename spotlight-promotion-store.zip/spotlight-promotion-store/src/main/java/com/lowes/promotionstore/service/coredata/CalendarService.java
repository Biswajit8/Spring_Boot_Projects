package com.lowes.promotionstore.service.coredata;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lowes.promotionstore.constants.enums.CalendarUnitType;
import com.lowes.promotionstore.repository.rest.CoreDataRepository;
import jakarta.annotation.PostConstruct;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ClassPathResource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Service
public class CalendarService {

  private final CoreDataRepository spotlightCoreDataRepository;
  @Getter
  private List<com.lowes.promotionstore.model.coredata.FiscalCalendarDto> cachedWeeks = new ArrayList<>();

  private final Object lock = new Object();
  ObjectMapper mapper = new ObjectMapper();

  public CalendarService(CoreDataRepository spotlightCoreDataRepository) {
    this.spotlightCoreDataRepository = spotlightCoreDataRepository;
    mapper.registerModule(new JavaTimeModule());
  }

  @PostConstruct
  public void initializeCache() {
    try {
      refreshCache(List.of(CalendarUnitType.PROMO_WEEK, CalendarUnitType.FISCAL_QUARTER));
      log.info("Cache initialized successfully for calendars");
    } catch (Exception ex) {
      log.error("Failed to initialize cache from SpotlightCoreDataRepository: {}", ex.getMessage());
      loadFromJsonBackup();
    }
  }

  public void refreshCache(List<CalendarUnitType> types) {
    synchronized (lock) {
      cachedWeeks = spotlightCoreDataRepository.getAllCalendarData(types);
    }
  }

  private void loadFromJsonBackup() {
    synchronized (lock) {
      try {
        InputStream is = new ClassPathResource("json/fiscal_calendar.json").getInputStream();
        cachedWeeks = mapper.readValue(is, new TypeReference<>() {
        });
        log.info("Loaded {} records from fallback JSON", cachedWeeks.size());
      } catch (IOException e) {
        log.error("Failed to load fallback fiscal calendar JSON: {}", e.getMessage(), e);
        cachedWeeks = List.of();
      }
    }
  }
}
