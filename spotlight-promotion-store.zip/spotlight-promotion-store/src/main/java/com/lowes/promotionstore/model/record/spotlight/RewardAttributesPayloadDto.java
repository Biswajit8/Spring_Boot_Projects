package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record RewardAttributesPayloadDto(PromotionPayloadEnums.RewardQuantityEnum rewardQuantity,
                                         Double quantityValue,
                                         PromotionPayloadEnums.DiscountTypeEnum discountType,
                                         PromotionPayloadEnums.DiscountOnEnum discountOn,
                                         Double discountValue, Double maxDiscount) {

}
