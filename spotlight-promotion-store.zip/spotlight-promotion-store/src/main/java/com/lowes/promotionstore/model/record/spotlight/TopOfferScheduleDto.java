package com.lowes.promotionstore.model.record.spotlight;


import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.ScheduleTypeEnum;

import java.util.List;

public record TopOfferScheduleDto(
        ScheduleTypeEnum scheduleType,
        List<String> promoWeeks,
        List<String> fiscalQuarters
) {}
