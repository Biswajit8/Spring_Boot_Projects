package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record ShippingTypeFieldsPayloadDto(String type, String category, String shippingMethod,
                                           String fulfillmentType) {

}
