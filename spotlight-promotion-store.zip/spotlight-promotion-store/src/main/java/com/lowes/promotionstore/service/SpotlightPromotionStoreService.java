package com.lowes.promotionstore.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lowes.promotionstore.component.MemoryMetrics;
import com.lowes.promotionstore.component.MemoryMonitor;
import com.lowes.promotionstore.component.MicrometerEventRegister;
import com.lowes.promotionstore.component.SpotlightPromoStoreEntityMapper;
import com.lowes.promotionstore.entity.spotlight.PromotionJsonField;
import com.lowes.promotionstore.exception.constants.ErrorEnums;
import com.lowes.promotionstore.model.record.micrometer.RegistryEvent;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import com.lowes.promotionstore.repository.dao.SpotlightPromoStoreElasticSearchDao;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import static com.lowes.promotionstore.component.SpotlightPromoStoreEntityMapper.enrichSpotlightOfferDto;

@Service
@AllArgsConstructor
@Slf4j
public class SpotlightPromotionStoreService {

  private final SpotlightPromoStoreElasticSearchDao spotlightPromoStoreElasticSearchDao;
  private final SpotlightPromoStoreEntityMapper spotlightPromoStoreEntityMapper;
  private final MicrometerEventRegister registryService;
  private final MemoryMonitor memoryMonitor;

  private static final String REGISTRY_EVENT_NAME = "kafka_consumer_process_failure";

  public void process(List<SpotlightOfferPayloadDto> spotlightOffers, String topic) {
    if (CollectionUtils.isEmpty(spotlightOffers)) {
      log.warn("No SpotlightOffer records to process (topic={})", topic);
      return;
    }

    // Memory monitoring before processing
    MemoryMetrics initialMemory = memoryMonitor.checkMemoryUsage("process_start",
        spotlightOffers.size());

    // Check if we have sufficient memory for this batch
    int estimatedPayloadSize =
        spotlightOffers.size() * 1024 * 1024; // Rough estimate: 1MB per offer
    if (!memoryMonitor.hasSufficientMemory(estimatedPayloadSize)) {
      log.warn("Insufficient memory for batch processing (topic={}, batchSize={})", topic,
          spotlightOffers.size());
      registryService.incrementCounter(RegistryEvent.builder()
          .event("memory_insufficient")
          .source(topic)
          .message("Batch size too large for available memory")
          .build());
    }

    var processingStats = new ProcessingStats();
    var safeOffers = filterNonNullOffers(spotlightOffers, processingStats);

    processingStats.setTotal(safeOffers.size());

    var documentsToSave = processOffersToDocuments(safeOffers, topic, processingStats);

    if (documentsToSave.isEmpty()) {
      log.warn("No valid docs to save (topic={}, incomingChunkSize={})", topic,
          spotlightOffers.size());
      return;
    }

    saveDocuments(documentsToSave, topic, processingStats);

    // Memory monitoring after processing
    MemoryMetrics finalMemory = memoryMonitor.checkMemoryUsage("process_complete",
        spotlightOffers.size());
    logProcessingSummary(topic, processingStats, initialMemory, finalMemory);
  }

  private List<SpotlightOfferPayloadDto> filterNonNullOffers(
      List<SpotlightOfferPayloadDto> spotlightOffers,
      ProcessingStats stats) {
    var safeOffers = spotlightOffers.stream()
        .filter(Objects::nonNull)
        .toList();

    stats.setSkippedNull(spotlightOffers.size() - safeOffers.size());
    return safeOffers;
  }

  private List<Map<String, Object>> processOffersToDocuments(
      List<SpotlightOfferPayloadDto> safeOffers,
      String topic,
      ProcessingStats stats) {
    var documentsToSave = new ArrayList<Map<String, Object>>();

    for (var dto : safeOffers) {
      try {
        var document = processOfferToDocument(dto, topic);
        if (document != null) {
          documentsToSave.add(document);
          stats.incrementMapped();
        }
      } catch (JsonProcessingException e) {
        handleMappingException(dto, topic, e, ErrorEnums.ErrorCodeEnum.PARSING_FAILURE, stats);
      } catch (Exception e) {
        handleMappingException(dto, topic, e, ErrorEnums.ErrorCodeEnum.PROCESSING_FAILURE, stats);
      }
    }

    return documentsToSave;
  }

  private Map<String, Object> processOfferToDocument(
      SpotlightOfferPayloadDto dto,
      String topic) throws JsonProcessingException {
    log.info("Processing id={} dto={}", dto.id(), dto);

    var enriched = enrichSpotlightOfferDto(dto);
    var promotionStore = spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(enriched);

    if (promotionStore == null) {
      log.warn("Mapped PromotionStore is null, skipping dtoId={}", dto.id());
      incrementFailureCounter(topic, "MAPPING_NULL_DOC");
      return null;
    }

    if (promotionStore.getId() == null) {
      log.warn("Skipping PromotionStore with null id (dtoId={})", dto.id());
      incrementFailureCounter(topic, "NULL_ID_DOC_SKIPPED");
      return null;
    }

    return spotlightPromoStoreEntityMapper.ruleSetsEnrichment(promotionStore, enriched);
  }

  private void handleMappingException(
      SpotlightOfferPayloadDto dto,
      String topic,
      Exception e,
      ErrorEnums.ErrorCodeEnum errorCode,
      ProcessingStats stats) {
    stats.incrementMapFailures();
    log.error("""
        {} during mapping dtoId={}: {}
        """, errorCode.getMessage(), dto.id(), e.getMessage(), e);

    registryService.incrementCounter(RegistryEvent.builder()
        .event(REGISTRY_EVENT_NAME)
        .source(topic)
        .message(errorCode.getMessage())
        .build());
  }

  private void incrementFailureCounter(String topic, String message) {
    registryService.incrementCounter(RegistryEvent.builder()
        .event(REGISTRY_EVENT_NAME)
        .source(topic)
        .message(message)
        .build());
  }

  private void saveDocuments(
      List<Map<String, Object>> documentsToSave,
      String topic,
      ProcessingStats stats) {
    try {
      spotlightPromoStoreElasticSearchDao.upsertPartialBulkInOrder(documentsToSave);
      stats.setSavedBulk(documentsToSave.size());
      log.info("Bulk-saved {} docs (topic={})", documentsToSave.size(), topic);
    } catch (Exception bulkEx) {
      log.error("""
          Bulk save failed (topic={}); falling back to per-record. Cause: {}
          """, topic, bulkEx.getMessage(), bulkEx);

      saveDocumentsIndividually(documentsToSave, topic, stats);
    }
  }

  private void saveDocumentsIndividually(
      List<Map<String, Object>> documentsToSave,
      String topic,
      ProcessingStats stats) {
    for (var doc : documentsToSave) {
      var id = extractDocumentId(doc);

      try {
        if (id != null) {
          spotlightPromoStoreElasticSearchDao.upsertPartial(doc, id);
          stats.incrementSavedFallback();
        }
      } catch (Exception e) {
        stats.incrementSaveFailures();
        log.error("""
            Fallback save failed for id={} (topic={}): {}
            """, id, topic, e.getMessage(), e);

        incrementFailureCounter(topic, "FALLBACK_SAVE_FAILURE");
      }
    }
  }

  private String extractDocumentId(Map<String, Object> doc) {
    return doc.containsKey(PromotionJsonField.id.name()) &&
        doc.getOrDefault(PromotionJsonField.id.name(), null) != null
        ? doc.get(PromotionJsonField.id.name()).toString()
        : null;
  }

  private void logProcessingSummary(String topic, ProcessingStats stats,
      MemoryMetrics initialMemory, MemoryMetrics finalMemory) {
    log.info("""
            Chunk summary (topic={}): total={}, mapped={}, bulkSaved={}, fallbackSaved={}, 
            skippedNullDTOs={}, skippedNullIds={}, mapFailures={}, saveFailures={}
            Memory: Initial {:.1f}% ({}MB), Final {:.1f}% ({}MB), Delta {:.1f}%
            """,
        topic, stats.total(), stats.mapped(), stats.savedBulk(), stats.savedFallback(),
        stats.skippedNull(), stats.skippedNullId(), stats.mapFailures(), stats.saveFailures(),
        initialMemory.getHeapUsagePercent() * 100, initialMemory.getHeapUsed() / 1024 / 1024,
        finalMemory.getHeapUsagePercent() * 100, finalMemory.getHeapUsed() / 1024 / 1024,
        (finalMemory.getHeapUsagePercent() - initialMemory.getHeapUsagePercent()) * 100);
  }

  private static class ProcessingStats {

    private int total = 0;
    private int mapped = 0;
    private int savedBulk = 0;
    private int savedFallback = 0;
    private int skippedNull = 0;
    private int skippedNullId = 0;
    private int mapFailures = 0;
    private int saveFailures = 0;

    // Getters
    public int total() {
      return total;
    }

    public int mapped() {
      return mapped;
    }

    public int savedBulk() {
      return savedBulk;
    }

    public int savedFallback() {
      return savedFallback;
    }

    public int skippedNull() {
      return skippedNull;
    }

    public int skippedNullId() {
      return skippedNullId;
    }

    public int mapFailures() {
      return mapFailures;
    }

    public int saveFailures() {
      return saveFailures;
    }

    // Setters
    public void setTotal(int total) {
      this.total = total;
    }

    public void setSavedBulk(int savedBulk) {
      this.savedBulk = savedBulk;
    }

    public void setSkippedNull(int skippedNull) {
      this.skippedNull = skippedNull;
    }

    // Increment methods
    public void incrementMapped() {
      mapped++;
    }

    public void incrementSavedFallback() {
      savedFallback++;
    }

    public void incrementMapFailures() {
      mapFailures++;
    }

    public void incrementSaveFailures() {
      saveFailures++;
    }
  }
}
