package com.lowes.promotionstore.component.publisher;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lowes.generated.model.amplification.OfferAmplifiedPublishDto;
import org.apache.kafka.common.serialization.Serializer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class OfferAmplificationDtoSerializer implements Serializer<OfferAmplifiedPublishDto> {

  private ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

  public OfferAmplificationDtoSerializer() {
  }

  @Autowired
  public OfferAmplificationDtoSerializer(ObjectMapper objectMapper) {
    this.objectMapper = objectMapper.registerModule(new JavaTimeModule());
  }

  @Override
  public void configure(Map<String, ?> configs,
      boolean isKey) {
    // No additional configuration required
  }

  @Override
  public byte[] serialize(String topic, OfferAmplifiedPublishDto data) {
    try {
      return objectMapper.writeValueAsBytes(data);
    } catch (JsonProcessingException e) {
      throw new RuntimeException();
    }
  }

  @Override
  public void close() {
    // No resources to be released
  }
}