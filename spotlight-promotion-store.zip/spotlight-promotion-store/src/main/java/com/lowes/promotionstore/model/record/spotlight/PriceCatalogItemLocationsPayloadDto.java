package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.util.List;

@SuppressWarnings("java:S1068")
@JsonInclude(JsonInclude.Include.NON_NULL)
public record PriceCatalogItemLocationsPayloadDto(
    boolean includeAllStores,
    List<String> patches,
    List<String> stores
) {

}
