package com.lowes.promotionstore.repository.rest;

import com.lowes.promotionstore.component.MicrometerEventRegister;
import com.lowes.promotionstore.configuration.properties.AppRestProperties;
import com.lowes.promotionstore.exception.constants.ErrorEnums;
import com.lowes.promotionstore.exception.types.custom.SpotlightApplicationException;
import com.lowes.promotionstore.model.coredata.validationresponse.ValidationResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;


@Repository
@Slf4j
public class SpotlightApiRepository {

  private final WebClientRepository webClientRepository;
  private final AppRestProperties appRestProperties;
  private final MicrometerEventRegister micrometerEventRegister;

  public SpotlightApiRepository(AppRestProperties appRestProperties,
      WebClientRepository webClientRepository, MicrometerEventRegister micrometerEventRegister) {
    this.webClientRepository = webClientRepository;
    this.appRestProperties = appRestProperties;
    this.micrometerEventRegister = micrometerEventRegister;
  }

  public ValidationResponse getExternalCatalogueItems(Long promotionId, String requestId) {
    try {
      AppRestProperties.SpotlightApi spotlightApi = appRestProperties.getSpotlightApi();
      String path =
          spotlightApi.getDomain() + spotlightApi.getPath().getGetExternalItemCatalogue();

      UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(path);

      URI uri = builder.buildAndExpand(promotionId, requestId).toUri();

      return webClientRepository.exchange(uri, HttpMethod.GET, null, null,
          new ParameterizedTypeReference<ValidationResponse>() {
          });

    } catch (Exception ex) {
      String errorType = "GETTING_EXTERNAL_CATALOGUE_ERROR";
      String errorMessage = ex.getMessage();

      if (ex instanceof WebClientResponseException webClientResponseException) {
        errorType = "WEB_CLIENT_ERROR";
        errorMessage = webClientResponseException.getStatusCode().toString();
        log.error(
            "Error response from Get External Catalogue Items for spotlight API (promotion={}, requestId={}): {}",
            promotionId, requestId, webClientResponseException.getResponseBodyAsString());
      }

      recordFailureMetric(errorType, errorMessage);

      throw new SpotlightApplicationException(
          ErrorEnums.ErrorCodeEnum.INTERNAL_SERVER_ERROR,
          "Error while connecting to External Catalogue Items for spotlight API (promotionId="
              + promotionId + ", requestId=" + requestId + ")",
          HttpStatus.INTERNAL_SERVER_ERROR,
          ex
      );

    }
  }

  private void recordFailureMetric(String errorType, String errorMessage) {
    micrometerEventRegister.incrementCounter(
        com.lowes.promotionstore.model.record.micrometer.RegistryEvent.builder()
            .event("spotlight.api.external.catalogue.items.failure")
            .source("SpotlightApiRepository")
            .message(errorType + ": " + errorMessage)
            .build()
    );
  }


}
