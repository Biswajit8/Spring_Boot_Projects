package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

@JsonIgnoreProperties(ignoreUnknown = true)
public record ForecastDataDto(@NotNull(message = "PromotionId cannot be null")
                              @JsonProperty("promotionId")
                              String promotionId,

                              @JsonProperty("caseCost")
                              Double caseCost,

                              @JsonProperty("netUnitCost")
                              Double netUnitCost,

                              @JsonProperty("totalEveryDayCost")
                              Double totalEveryDayCost,

                              @JsonProperty("unitCost")
                              BigDecimal unitCost,

                              @JsonProperty("fundingCoverage")
                              Double fundingCoverage,

                              @JsonProperty("totalFundingCapped")
                              Double totalFundingCapped,

                              @JsonProperty("totalPromotionFundingPerUnit")
                              BigDecimal totalPromotionFundingPerUnit,

                              @JsonProperty("baselineMarginWithFunding")
                              BigDecimal baselineMarginWithFunding,

                              @JsonProperty("cannibalizedMargin")
                              Double cannibalizedMargin,

                              @JsonProperty("promotedMarginWithFunding")
                              Double promotedMarginWithFunding,

                              @JsonProperty("pantryLoadingMargin")
                              Double pantryLoadingMargin,

                              @JsonProperty("haloMargin")
                              Double haloMargin,

                              @JsonProperty("incrementalMarginWithHalo")
                              Double incrementalMarginWithHalo,

                              @JsonProperty("incrementalMargin")
                              Double incrementalMargin,

                              @JsonProperty("switchingAdjustedIncrementalMargin")
                              BigDecimal switchingAdjustedIncrementalMargin,

                              @JsonProperty("regPriceMarginPercentWithoutFunding")
                              Double regPriceMarginPercentWithoutFunding,

                              @JsonProperty("targetMarginPerUnitWithoutFunding")
                              Double targetMarginPerUnitWithoutFunding,

                              @JsonProperty("discountPercent")
                              BigDecimal discountPercent,

                              @JsonProperty("totalMarkdown")
                              BigDecimal totalMarkdown,

                              @JsonProperty("averagePrice")
                              Double averagePrice,

                              @JsonProperty("baselinePrice")
                              Double baselinePrice,

                              @JsonProperty("promotedPrice")
                              BigDecimal promotedPrice,

                              @JsonProperty("regularPrice")
                              BigDecimal regularPrice,

                              @JsonProperty("quadrant")
                              String quadrant,

                              @JsonProperty("quadrantIncludingHalo")
                              String quadrantIncludingHalo,

                              @JsonProperty("promotionROI")
                              BigDecimal promotionROI,

                              @JsonProperty("baselineSales")
                              Double baselineSales,

                              @JsonProperty("promotedSales")
                              Double promotedSales,

                              @JsonProperty("pantryLoadingSales")
                              Double pantryLoadingSales,

                              @JsonProperty("cannibalizedSales")
                              Double cannibalizedSales,

                              @JsonProperty("haloSales")
                              Double haloSales,

                              @JsonProperty("incrementalSalesWithHalo")
                              Double incrementalSalesWithHalo,

                              @JsonProperty("incrementalSales")
                              Double incrementalSales,

                              @JsonProperty("switchingAdjustedIncrementalSales")
                              Double switchingAdjustedIncrementalSales,

                              @JsonProperty("caseSize")
                              BigDecimal caseSize,

                              @JsonProperty("totalSpendMarkdown")
                              BigDecimal totalSpendMarkdown,

                              @JsonProperty("percentUpliftMarginWithFunding")
                              BigDecimal percentUpliftMarginWithFunding,

                              @JsonProperty("percentUpLiftSales")
                              BigDecimal percentUpLiftSales,

                              @JsonProperty("percentUpLiftUnits")
                              BigDecimal percentUpLiftUnits,

                              @JsonProperty("promotedVolume")
                              Double promotedVolume,

                              @JsonProperty("pantryLoadingVolume")
                              Double pantryLoadingVolume,

                              @JsonProperty("cannibalizedVolume")
                              BigDecimal cannibalizedVolume,

                              @JsonProperty("haloVolume")
                              Double haloVolume,

                              @JsonProperty("baselineVolume")
                              Double baselineVolume,

                              @JsonProperty("incrementalUnitsWithHalo")
                              Double incrementalUnitsWithHalo,

                              @JsonProperty("incrementalUnits")
                              Double incrementalUnits,

                              @JsonProperty("switchingAdjustedIncrementalVolume")
                              Double switchingAdjustedIncrementalVolume,

                              @JsonProperty("netCouponExpense")
                              Double netCouponExpense,

                              @JsonProperty("fundingGapPerUnit")
                              Double fundingGapPerUnit,

                              @JsonProperty("fundingGapPct")
                              BigDecimal fundingGapPct,

                              @JsonProperty("accuracyIndicator")
                              String accuracyIndicator,

                              @JsonProperty("totalFundingGap")
                              Double totalFundingGap,

                              @JsonProperty("percentUpliftSalesWithHalo")
                              BigDecimal percentUpliftSalesWithHalo,

                              @JsonProperty("percentUpliftMarginWithHalo")
                              BigDecimal percentUpliftMarginWithHalo,

                              @JsonProperty("createdTs")
                              String createdTs,

                              @JsonProperty("modifiedTs")
                              String modifiedTs
) {

}