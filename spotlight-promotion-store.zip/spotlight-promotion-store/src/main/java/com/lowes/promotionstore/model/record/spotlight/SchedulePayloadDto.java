package com.lowes.promotionstore.model.record.spotlight;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("java:S1068")
@JsonIgnoreProperties(ignoreUnknown = true)
public record SchedulePayloadDto(String startDate, String endDate, boolean noEndDate, int calendarWeek,
                                 List<String> daysOfWeek, String activeStartDate, String activeEndDate) {

  public SchedulePayloadDto {
    if (CollectionUtils.isEmpty(daysOfWeek)) {
      daysOfWeek = new ArrayList<>();
    }
  }
}
