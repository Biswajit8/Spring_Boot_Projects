package com.lowes.promotionstore.component;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.MapperFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.lowes.promotionstore.configuration.ObjectMapperConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.BiPredicate;

@Component
@RequiredArgsConstructor
@Slf4j
public class PartialMapBuilders {

  // Inject a single ObjectMapper bean (or your ObjectMapperConfig can expose one @Bean)
  private final ObjectMapperConfig objectMapper;

  /**
   * Start a new builder session for a given doc (keeps nulls so you can re-add them later).
   */
  public <T> Builder<T> from(T doc) {
    if (doc == null) {
      return new Builder<>(new LinkedHashMap<>());
    }

    ObjectMapper m = objectMapper.objectMapper().copy()
        .setSerializationInclusion(JsonInclude.Include.ALWAYS)
        .configure(SerializationFeature.WRITE_NULL_MAP_VALUES, true)
        .enable(MapperFeature.USE_ANNOTATIONS);

    Map<String, Object> full = m
        .convertValue(doc, new TypeReference<Map<String, Object>>() {
        });
    return new Builder<>(full);
  }

  /**
   * The order-sensitive fluent builder (NOT a Spring bean).
   */
  public static final class Builder<T> {

    private final Map<String, Object> full;
    private final Map<String, Object> current;

    private Builder(Map<String, Object> full) {
      this.full = new LinkedHashMap<>(full);
      this.current = new LinkedHashMap<>(full);
    }

    public Builder<T> startEmpty() {
      current.clear();
      return this;
    }

    public Builder<T> include(Collection<String> keys) {
      if (keys != null && !keys.isEmpty()) {
        for (String k : keys) {
          current.put(k, full.get(k));
        }
      }
      return this;
    }

    public Builder<T> keepOnly(Collection<String> keys) {
      if (keys != null) {
        current.keySet().retainAll(new HashSet<>(keys));
      }
      return this;
    }

    public Builder<T> exclude(Collection<String> keys) {
      if (keys != null && !keys.isEmpty()) {
        current.keySet().removeAll(keys);
      }
      return this;
    }

    public Builder<T> dropNulls() {
      current.values().removeIf(Objects::isNull);
      return this;
    }

    public Builder<T> dropEmpties() {
      current.entrySet().removeIf(e -> isEmptyValue(e.getValue()));
      return this;
    }

    public Builder<T> filter(BiPredicate<String, Object> keep) {
      if (keep != null) {
        current.entrySet().removeIf(e -> !keep.test(e.getKey(), e.getValue()));
      }
      return this;
    }

    public Map<String, Object> build() {
      return new LinkedHashMap<>(current);
    }

    // helpers
    private static boolean isEmptyValue(Object v) {
      if (v == null) {
        return true;
      }
      if (v instanceof CharSequence cs) {
        return cs.isEmpty();
      }
      if (v instanceof Collection<?> c) {
        return c.isEmpty();
      }
      if (v instanceof Map<?, ?> m) {
        return m.isEmpty();
      }
      if (v instanceof Optional<?> o) {
        return o.isEmpty();
      }
      if (v.getClass().isArray()) {
        return java.lang.reflect.Array.getLength(v) == 0;
      }
      return false;
    }
  }
}

