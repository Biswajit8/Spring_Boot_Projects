package com.lowes.promotionstore.component;

import com.lowes.promotionstore.model.record.micrometer.RegistryEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;

@Slf4j
@Component
public class MemoryMonitor {

  private final MemoryMXBean memoryBean = ManagementFactory.getMemoryMXBean();
  private final MicrometerEventRegister registryService;

  // Memory thresholds (configurable)
  private static final double MEMORY_WARNING_THRESHOLD = 0.75; // 75%
  private static final double MEMORY_CRITICAL_THRESHOLD = 0.85; // 85%
  private static final long LARGE_PAYLOAD_THRESHOLD_BYTES = 10 * 1024 * 1024; // 10MB

  public MemoryMonitor(MicrometerEventRegister registryService) {
    this.registryService = registryService;
  }

  /**
   * Monitor memory usage during payload processing
   */
  public MemoryMetrics checkMemoryUsage(String operation, int payloadCount) {
    MemoryUsage heapUsage = memoryBean.getHeapMemoryUsage();
    MemoryUsage nonHeapUsage = memoryBean.getNonHeapMemoryUsage();

    double heapUsagePercent = (double) heapUsage.getUsed() / heapUsage.getMax();
    long freeMemory = heapUsage.getMax() - heapUsage.getUsed();

    MemoryMetrics metrics = MemoryMetrics.builder()
        .operation(operation)
        .payloadCount(payloadCount)
        .heapUsed(heapUsage.getUsed())
        .heapMax(heapUsage.getMax())
        .heapUsagePercent(heapUsagePercent)
        .freeMemory(freeMemory)
        .nonHeapUsed(nonHeapUsage.getUsed())
        .timestamp(System.currentTimeMillis())
        .build();

    // Log warnings and register metrics
    if (heapUsagePercent > MEMORY_CRITICAL_THRESHOLD) {
      logMemoryAlert(metrics, "CRITICAL");
      registryService.incrementCounter(createMemoryEvent(operation, "MEMORY_CRITICAL"));
    } else if (heapUsagePercent > MEMORY_WARNING_THRESHOLD) {
      logMemoryAlert(metrics, "WARNING");
      registryService.incrementCounter(createMemoryEvent(operation, "MEMORY_WARNING"));
    }

    // Log detailed metrics for large payloads
    if (payloadCount > 50 || heapUsage.getUsed() > LARGE_PAYLOAD_THRESHOLD_BYTES) {
      logDetailedMemoryMetrics(metrics);
    }

    return metrics;
  }

  /**
   * Check if system has enough memory for processing
   */
  public boolean hasSufficientMemory(int estimatedPayloadSize) {
    MemoryUsage heapUsage = memoryBean.getHeapMemoryUsage();
    long freeMemory = heapUsage.getMax() - heapUsage.getUsed();

    // Require 3x the estimated payload size as free memory
    long requiredMemory = estimatedPayloadSize * 3L;

    if (freeMemory < requiredMemory) {
      log.warn("Insufficient memory for payload processing. Required: {}MB, Available: {}MB",
          requiredMemory / 1024 / 1024, freeMemory / 1024 / 1024);
      return false;
    }

    return true;
  }

  /**
   * Get current memory status
   */
  public MemoryStatus getMemoryStatus() {
    MemoryUsage heapUsage = memoryBean.getHeapMemoryUsage();
    double heapUsagePercent = (double) heapUsage.getUsed() / heapUsage.getMax();

    if (heapUsagePercent > MEMORY_CRITICAL_THRESHOLD) {
      return MemoryStatus.CRITICAL;
    } else if (heapUsagePercent > MEMORY_WARNING_THRESHOLD) {
      return MemoryStatus.WARNING;
    } else {
      return MemoryStatus.HEALTHY;
    }
  }

  private void logMemoryAlert(MemoryMetrics metrics, String level) {
    log.warn("""
            Memory Alert [{}] - Operation: {}, Payloads: {}, 
            Heap Usage: {:.1f}% ({}MB/{}MB), Free: {}MB
            """,
        level, metrics.getOperation(), metrics.getPayloadCount(),
        metrics.getHeapUsagePercent() * 100,
        metrics.getHeapUsed() / 1024 / 1024,
        metrics.getHeapMax() / 1024 / 1024,
        metrics.getFreeMemory() / 1024 / 1024);
  }

  private void logDetailedMemoryMetrics(MemoryMetrics metrics) {
    log.info("""
            Memory Metrics - Operation: {}, Payloads: {},
            Heap: {}MB/{}MB ({:.1f}%), Free: {}MB, Non-Heap: {}MB
            """,
        metrics.getOperation(), metrics.getPayloadCount(),
        metrics.getHeapUsed() / 1024 / 1024,
        metrics.getHeapMax() / 1024 / 1024,
        metrics.getHeapUsagePercent() * 100,
        metrics.getFreeMemory() / 1024 / 1024,
        metrics.getNonHeapUsed() / 1024 / 1024);
  }

  private RegistryEvent createMemoryEvent(String operation, String alertType) {
    return RegistryEvent.builder()
        .event("memory_monitoring")
        .source(operation)
        .message(alertType)
        .build();
  }

  public enum MemoryStatus {
    HEALTHY, WARNING, CRITICAL
  }
}
