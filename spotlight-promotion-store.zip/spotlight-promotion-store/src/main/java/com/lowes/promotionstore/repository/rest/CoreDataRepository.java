package com.lowes.promotionstore.repository.rest;

import com.lowes.promotionstore.configuration.properties.AppRestProperties;
import com.lowes.promotionstore.configuration.properties.AppRestProperties.CoreData;
import com.lowes.promotionstore.constants.enums.CalendarUnitType;
import com.lowes.promotionstore.exception.constants.ErrorEnums;
import com.lowes.promotionstore.exception.constants.ErrorEnums.ErrorCodeEnum;
import com.lowes.promotionstore.exception.constants.ErrorEnums.ErrorTypeEnum;
import com.lowes.promotionstore.exception.types.custom.RepositoryException;
import com.lowes.promotionstore.exception.types.custom.SpotlightApplicationException;
import com.lowes.promotionstore.model.coredata.FiscalCalendarDto;
import com.lowes.promotionstore.model.coredata.uploaditems.UploadFileDtoPayloadDto;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Repository;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.util.List;

@Repository
@Slf4j
public class CoreDataRepository {

  private final WebClientRepository webClientRepository;
  private final CoreData coreDataProps;

  public CoreDataRepository(AppRestProperties appRestProperties,
      WebClientRepository webClientRepository) {
    this.webClientRepository = webClientRepository;
    this.coreDataProps = appRestProperties.getCoreData();
  }

  public UploadFileDtoPayloadDto getUploadedItems(Long promotionId,
      String uploadFileName,
      String discountTypeLabel) {
    try {
      String path =
          coreDataProps.getDomain() + coreDataProps.getPath().getGetExternalItemCatalogue();

      UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(path);

      URI uri = builder.buildAndExpand(promotionId, uploadFileName, discountTypeLabel).toUri();

      return webClientRepository.exchange(uri, HttpMethod.GET, null, null,
          new ParameterizedTypeReference<UploadFileDtoPayloadDto>() {
          });

    } catch (Exception ex) {
      if (ex instanceof WebClientResponseException webClientResponseException) {
        log.error("Error response from Get Uploaded Items API (label={}): {}",
            discountTypeLabel, webClientResponseException.getResponseBodyAsString());
      }
      throw new SpotlightApplicationException(ErrorCodeEnum.INTERNAL_SERVER_ERROR,
          "Error while connecting to Get Uploaded Items API (" + discountTypeLabel + ")",
          HttpStatus.INTERNAL_SERVER_ERROR,
          ex);
    }
  }

  public List<FiscalCalendarDto> getAllCalendarData(List<CalendarUnitType> types) {
    try {
      URI uri = UriComponentsBuilder
          .fromUriString(coreDataProps.getDomain() + coreDataProps.getPath().getCalendar())
          .build()
          .toUri();

      return webClientRepository.exchange(uri, HttpMethod.POST, null, types,
          new ParameterizedTypeReference<List<FiscalCalendarDto>>() {
          });

    } catch (Exception e) {
      log.error("Failed to fetch fiscal weeks from coredata API", e);
      throw new RepositoryException(
          ErrorTypeEnum.APPLICATION_ERROR,
          ErrorCodeEnum.DATABASE_ERROR,
          "Failed to fetch fiscal weeks from coredata",
          HttpStatus.INTERNAL_SERVER_ERROR
      );
    }
  }


}
