package com.lowes.promotionstore.model.coredata.validationresponse;

import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValidationErrorResponse {

  // Basic item info
  private Integer rowId;
  private String itemNumber;
  private String vendorNumber;
  private String modelNumber;
  private String itemDescription;
  private String locations;
  private PromotionPayloadEnums.DiscountTypeEnum discountType;
  private BigDecimal discountValue;
  private String wasPrice;
  private String offerPrice;
  private String errorCode;
  private String message;
  private Integer missingPriceCount;
  private String missingPriceStores;
  private List<String> missingPriceStoreList;

  private Integer failedStoreCount;
  private String failedStores;
  private List<FailedStoreDetail> failedStoreDetails;
  private Boolean perStoreValidationPerformed;
  private String safeZoneResult;
  private LocalDateTime validatedAt;

  /**
   * Detail of a single store validation failure
   */
  @Data
  @Builder
  @NoArgsConstructor
  @AllArgsConstructor
  public static class FailedStoreDetail {

    private String storeId;
    private BigDecimal basePrice;
    private BigDecimal offerPrice;
    private List<String> violations;

    /**
     * Convert to map for JSON serialization
     */
    public Map<String, Object> toMap() {
      return Map.of(
          "storeId", storeId,
          "basePrice", basePrice != null ? basePrice : BigDecimal.ZERO,
          "offerPrice", offerPrice != null ? offerPrice : BigDecimal.ZERO,
          "violations", violations != null ? violations : List.of()
      );
    }
  }

  /**
   * Build summary string for failed stores (for report display)
   */
  public String buildFailedStoresSummary() {
    if (failedStoreDetails == null || failedStoreDetails.isEmpty()) {
      return "";
    }

    List<String> storeIds = failedStoreDetails.stream()
        .map(FailedStoreDetail::getStoreId)
        .toList();

    if (storeIds.size() <= 10) {
      return String.join(", ", storeIds);
    }

    return String.join(", ", storeIds.subList(0, 10))
        + " and " + (storeIds.size() - 10) + " more";
  }

  /**
   * Build summary string for missing price stores
   */
  public String buildMissingStoresSummary() {
    if (missingPriceStoreList == null || missingPriceStoreList.isEmpty()) {
      return "";
    }

    if (missingPriceStoreList.size() <= 10) {
      return String.join(", ", missingPriceStoreList);
    }

    return String.join(", ", missingPriceStoreList.subList(0, 10))
        + " and " + (missingPriceStoreList.size() - 10) + " more";
  }
}