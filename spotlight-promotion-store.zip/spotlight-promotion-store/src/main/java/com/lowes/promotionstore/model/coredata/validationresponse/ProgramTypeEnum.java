package com.lowes.promotionstore.model.coredata.validationresponse;

import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Getter;

@Getter
public enum ProgramTypeEnum {

  STOCK("Stock"),

  CONSUMER_SOS("Consumer-SOS");

  private final String value;

  ProgramTypeEnum(String value) {
    this.value = value;
  }

  @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
  public static ProgramTypeEnum fromString(String value) {
    if (value == null) {
      return null;
    }
    for (ProgramTypeEnum type : values()) {
      if (type.name().equalsIgnoreCase(value) || type.value.equalsIgnoreCase(value)) {
        return type;
      }
    }
    return null;
  }
}
