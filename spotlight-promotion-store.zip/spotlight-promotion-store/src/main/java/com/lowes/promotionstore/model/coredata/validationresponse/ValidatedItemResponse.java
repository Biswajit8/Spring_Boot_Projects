package com.lowes.promotionstore.model.coredata.validationresponse;

import com.lowes.generated.model.offerevent.DiscountTypeEnum;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ValidatedItemResponse {

  private String rowId;
  private String itemNumber;
  private String itemDescription;
  private String locations;
  private String resolvedLocations;

  private DiscountTypeEnum discountType;
  private BigDecimal discountValue;

  private String wasPrice;
  private String offerPrice;

  private String vendorNumber;
  private String modelNumber;

  private List<String> overlappingPromotionIds;
  private AppliancePriceAttributes appliancePriceAttributes;
  private LocalDateTime validatedAt;
}