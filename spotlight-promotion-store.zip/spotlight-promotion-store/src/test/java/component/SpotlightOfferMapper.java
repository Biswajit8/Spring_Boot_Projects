package component;

import com.lowes.promotionstore.component.SpotlightOfferMapper;
import com.lowes.promotionstore.model.record.spotlight.ForecastDataDto;
import com.lowes.promotionstore.model.record.spotlight.OfferSalesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import util.TestUtil;

import static com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.MarketScopeEnum.OMNI;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

class SpotlightOfferMapperTest {

  private SpotlightOfferMapper spotlightOfferMapper;
  private TestUtil testUtil;

  @BeforeEach
  void setup() {
    spotlightOfferMapper = new SpotlightOfferMapper();
    testUtil = new TestUtil();
  }

  @Test
  void testMapSpotlightOffer_withUpdatedForecastData() {

    SpotlightOfferPayloadDto spotlightOffer = testUtil.mockSpotlightOffer();
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();

    SpotlightOfferPayloadDto result = spotlightOfferMapper.withUpdatedForecastData(spotlightOffer,
        forecastDataDto);

    assertNotNull(result);
    assertEquals("Test-Creation", result.name());
    assertEquals("CONDITIONAL_PRODUCT_DISCOUNTS", result.offerType());
    assertEquals("Conditional Product Discounts", result.offerTypeName());
    assertEquals("PRODUCT_DISCOUNTS", result.offerSubType());
    assertEquals(OMNI, result.marketScope());
    assertEquals(forecastDataDto, result.forecastData());

  }

  @Test
  void testMapSpotlightOffer_withUpdatedOfferSalesMetrics() {
    SpotlightOfferPayloadDto spotlightOffer = testUtil.mockSpotlightOffer();
    OfferSalesPayloadDto newSalesData = testUtil.mockOfferSalesDto();

    SpotlightOfferPayloadDto result = spotlightOfferMapper.withUpdatedOfferSalesMetrics(
        spotlightOffer,
        newSalesData);

    assertNotNull(result);
    assertEquals(spotlightOffer.id(), result.id());
    assertEquals(spotlightOffer.name(), result.name());
    assertEquals(spotlightOffer.offerType(), result.offerType());
    assertEquals(spotlightOffer.offerTypeName(), result.offerTypeName());
    assertEquals(spotlightOffer.offerSubType(), result.offerSubType());
    assertEquals(spotlightOffer.marketScope(), result.marketScope());
    assertEquals(spotlightOffer.forecastData(), result.forecastData());
    assertEquals(newSalesData, result.salesData());
  }

}