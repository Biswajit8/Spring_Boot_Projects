package component;

import com.lowes.generated.model.offerevent.Alerts;
import com.lowes.generated.model.offerevent.AmplificationSignal;
import com.lowes.generated.model.offerevent.Catalog;
import com.lowes.generated.model.offerevent.CatalogFileRef;
import com.lowes.generated.model.offerevent.Comment;
import com.lowes.generated.model.offerevent.Customer;
import com.lowes.generated.model.offerevent.CustomerEnum;
import com.lowes.generated.model.offerevent.ExecutionMessageTypeEnum;
import com.lowes.generated.model.offerevent.LabelInfo;
import com.lowes.generated.model.offerevent.Locations;
import com.lowes.generated.model.offerevent.MarketScopeEnum;
import com.lowes.generated.model.offerevent.MarketingInfo;
import com.lowes.generated.model.offerevent.OfferEventPublishDto;
import com.lowes.generated.model.offerevent.OfferGroup;
import com.lowes.generated.model.offerevent.OfferIntegrationCompatibility;
import com.lowes.generated.model.offerevent.PromotionMetaData;
import com.lowes.generated.model.offerevent.RebateInfo;
import com.lowes.generated.model.offerevent.RedemptionTypeEnum;
import com.lowes.generated.model.offerevent.Schedule;
import com.lowes.generated.model.offerevent.SourceSystemEnum;
import com.lowes.generated.model.offerevent.StackingGroup;
import com.lowes.generated.model.offerevent.StatusEnum;
import com.lowes.generated.model.offerevent.Tier;
import com.lowes.generated.model.offerevent.VersionChangesDto;
import com.lowes.promotionstore.component.OfferEventMapper;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(MockitoExtension.class)
class OfferEventMapperTest {

  private OfferEventMapper offerEventMapper;

  @BeforeEach
  void setUp() {
    offerEventMapper = new OfferEventMapper();
  }

  @Test
  void testToSpotlightOffer_withNullDto_shouldReturnNull() {
    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(null);
    assertNull(result);
  }

  @Test
  void testToSpotlightOffer_withBasicFields_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertEquals(12345L, result.id());
    assertEquals(101L, result.offerTypeId());
    assertEquals("Test Offer", result.name());
    assertEquals("CONDITIONAL_PRODUCT_DISCOUNTS", result.offerType());
    assertEquals("Conditional Product Discounts", result.offerTypeName());
    assertEquals("PRODUCT_DISCOUNTS", result.offerSubType());
    assertEquals("Product Discounts", result.offerSubTypeName());
    assertEquals("Short description", result.shortDescription());
  }

  @Test
  void testToSpotlightOffer_withSchedule_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    Schedule schedule = new Schedule();
    schedule.setStartDate(LocalDateTime.of(2025, 1, 1, 10, 0, 0));
    schedule.setEndDate(LocalDateTime.of(2025, 12, 31, 23, 59, 59));
    schedule.setNoEndDate(false);
    schedule.setCalendarWeek(1);
    schedule.setDaysOfWeek(List.of("MONDAY", "TUESDAY"));
    dto.setSchedule(schedule);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.schedule());
    assertEquals("2025-01-01 10:00:00", result.schedule().startDate());
    assertEquals("2025-12-31 23:59:59", result.schedule().endDate());
    assertFalse(result.schedule().noEndDate());
    assertEquals(1, result.schedule().calendarWeek());
  }

  @Test
  void testToSpotlightOffer_withLocations_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    Locations locations = new Locations();
    locations.setIncludeAllStores(true);
    locations.setStores(List.of("1633", "1234"));
    locations.setPatches(List.of("LL", "FC"));
    dto.setLocations(locations);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.locations());
    assertTrue(result.locations().includeAllStores());
    assertEquals(2, result.locations().stores().size());
    assertEquals(2, result.locations().patches().size());
  }

  @Test
  void testToSpotlightOffer_withNullLocations_shouldReturnDefaultLocations() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setLocations(null);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.locations());
    assertFalse(result.locations().includeAllStores());
  }

  @Test
  void testToSpotlightOffer_withCustomer_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    Customer customer = new Customer();
    customer.setCustomerType(CustomerEnum.PRO);
    dto.setCustomer(customer);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.customer());
    assertEquals(PromotionPayloadEnums.CustomerEnum.PRO, result.customer().customerType());
  }

  @Test
  void testToSpotlightOffer_withMarketScope_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setMarketScope(MarketScopeEnum.OMNI);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertEquals(PromotionPayloadEnums.MarketScopeEnum.OMNI, result.marketScope());
  }

  @Test
  void testToSpotlightOffer_withRedemptionType_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setRedemptionType(RedemptionTypeEnum.INSTANT);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertEquals(PromotionPayloadEnums.RedemptionTypeEnum.INSTANT, result.redemptionType());
  }

  @Test
  void testToSpotlightOffer_withStatus_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setStatus(StatusEnum.COMPLETE);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertEquals(PromotionPayloadEnums.StatusEnum.COMPLETE, result.status());
  }

  @Test
  void testToSpotlightOffer_withExecutionMessageType_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setExecutionMessageType(ExecutionMessageTypeEnum.REGULAR);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertEquals(PromotionPayloadEnums.ExecutionMessageTypeEnum.REGULAR,
        result.executionMessageType());
  }

  @Test
  void testToSpotlightOffer_withTimestamps_shouldConvertCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setCreatedTs(LocalDateTime.of(2025, 4, 16, 3, 49, 17));
    dto.setModifiedTs(LocalDateTime.of(2025, 4, 16, 4, 9, 51));
    dto.setActivatedTs(LocalDateTime.of(2025, 4, 16, 4, 9, 51));
    dto.setDeactivatedTs(null);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertEquals("2025-04-16 03:49:17", result.createdTs());
    assertEquals("2025-04-16 04:09:51", result.modifiedTs());
    assertEquals("2025-04-16 04:09:51", result.activatedTs());
    assertNull(result.deactivatedTs());
  }

  @Test
  void testToSpotlightOffer_withSourceSystem_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setSourceSystem(SourceSystemEnum.SPOTLIGHT);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertEquals("SPOTLIGHT", result.sourceSystem());
  }

  @Test
  void testToSpotlightOffer_withLabelInfo_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    LabelInfo labelInfo = new LabelInfo();
    labelInfo.setLabelEligible(true);
    labelInfo.setLabelCode(123);
    labelInfo.setLabelType("TYPE_A");
    dto.setLabelInfo(labelInfo);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.labelInfo());
    assertTrue(result.labelInfo().labelEligible());
    assertEquals(123, result.labelInfo().labelCode());
    assertEquals("TYPE_A", result.labelInfo().labelType());
  }

  @Test
  void testToSpotlightOffer_withOfferGroup_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    OfferGroup offerGroup = new OfferGroup();
    offerGroup.setId(123L);
    offerGroup.setName("Test Group");
    dto.setOfferGroup(offerGroup);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.offerGroup());
    assertEquals(123, result.offerGroup().id());
    assertEquals("Test Group", result.offerGroup().name());
  }

  @Test
  void testToSpotlightOffer_withStackingGroup_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    StackingGroup stackingGroup = new StackingGroup();
    stackingGroup.setStackWithOtherOffers(true);
    dto.setStackingGroup(stackingGroup);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.stackingGroup());
    assertTrue(result.stackingGroup().stackWithOtherOffers());
  }

  @Test
  void testToSpotlightOffer_withAlerts_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    Alerts alerts = new Alerts();
    alerts.setHasError(true);
    alerts.setHasWarning(false);
    dto.setAlerts(alerts);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.alerts());
    assertTrue(result.alerts().hasError());
    assertFalse(result.alerts().hasWarning());
  }

  @Test
  void testToSpotlightOffer_withOfferIntegrationCompatibility_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    OfferIntegrationCompatibility oic = new OfferIntegrationCompatibility();
    oic.setIsSupportedByCalc(true);
    oic.setIsSupportedByVendorFunding(false);
    oic.setIndicators(List.of("IND1", "IND2"));
    dto.setOfferIntegrationCompatibility(oic);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.offerIntegrationCompatibility());
    assertTrue(result.offerIntegrationCompatibility().isSupportedByCalc());
    assertFalse(result.offerIntegrationCompatibility().isSupportedByVendorFunding());
    assertEquals(2, result.offerIntegrationCompatibility().indicators().size());
  }

  @Test
  void testToSpotlightOffer_withAmplificationChannel_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setAmplificationChannel(AmplificationSignal.TAB);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertEquals("TAB", result.amplificationChannel());
  }

  @Test
  void testToSpotlightOffer_withNullAmplificationChannel_shouldReturnNull() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setAmplificationChannel(null);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNull(result.amplificationChannel());
  }

  @Test
  void testToSpotlightOffer_withComments_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    Comment comment = new Comment();
    comment.setCommentId("comment-123");
    comment.setCommentText("Test comment");
    comment.setCreatedBy("user1");
    comment.setCreatedTs("2025-01-01 10:00:00");
    comment.setModifiedTs("2025-01-02 10:00:00");
    comment.setModifiedBy("user2");
    comment.setSpotlightUserRole("ADMIN");
    dto.setComments(List.of(comment));

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.comments());
    assertEquals(1, result.comments().size());
    assertEquals("comment-123", result.comments().get(0).commentId());
    assertEquals("Test comment", result.comments().get(0).commentText());
  }

  @Test
  void testToSpotlightOffer_withEmptyComments_shouldReturnEmptyList() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setComments(List.of());

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.comments());
    assertTrue(result.comments().isEmpty());
  }

  @Test
  void testToSpotlightOffer_withPromotionMetaData_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    PromotionMetaData metaData = new PromotionMetaData();
    metaData.setEventIds(List.of(1, 2, 3));
    metaData.setDivisions(List.of(10, 20));
    metaData.setSubDivisions(List.of(100, 200));
    metaData.setPromoTrackerLink("http://tracker.link");
    dto.setMetaData(metaData);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.metaData());
    assertEquals(3, result.metaData().eventIds().size());
    assertEquals(2, result.metaData().divisions().size());
    assertEquals(2, result.metaData().subDivisions().size());
    assertEquals("http://tracker.link", result.metaData().promoTrackerLink());
  }

  @Test
  void testToSpotlightOffer_withNullPromotionMetaData_shouldReturnDefaultMetaData() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setMetaData(null);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.metaData());
  }

  @Test
  void testToSpotlightOffer_withTiers_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    Tier tier = new Tier();
    tier.setTierId(1);
    tier.setConditionGroups(List.of());
    tier.setRewardGroups(List.of());
    dto.setTiers(List.of(tier));

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.tiers());
    assertEquals(1, result.tiers().size());
    assertEquals(1, result.tiers().get(0).tierId());
  }

  @Test
  void testToSpotlightOffer_withCatalogs_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    Catalog catalog = new Catalog();
    catalog.setCatalogId("catalog-123");

    CatalogFileRef fileRef = new CatalogFileRef();
    fileRef.setOriginalName("original.csv");
    fileRef.setUploadName("upload.csv");
    catalog.setCatalogFileRef(fileRef);

    dto.setCatalogs(List.of(catalog));

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.catalogs());
    assertEquals(1, result.catalogs().size());
    assertEquals("catalog-123", result.catalogs().get(0).catalogId());
    assertNotNull(result.catalogs().get(0).catalogFileRef());
    assertEquals("original.csv", result.catalogs().get(0).catalogFileRef().originalName());
  }

  @Test
  void testToSpotlightOffer_withMarketingInfo_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    MarketingInfo marketingInfo = new MarketingInfo();
    marketingInfo.setMarketingEligible(true);
    marketingInfo.setDealOfTheDay(false);
    marketingInfo.setOfferIntent(List.of("INTENT1", "INTENT2"));
    dto.setMarketingInfo(marketingInfo);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.marketingInfo());
    assertTrue(result.marketingInfo().marketingEligible());
    assertFalse(result.marketingInfo().dealOfTheDay());
    assertEquals(2, result.marketingInfo().offerIntent().size());
  }

  @Test
  void testToSpotlightOffer_withRebateInfo_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    RebateInfo rebateInfo = new RebateInfo();
    rebateInfo.setRebate(true);
    rebateInfo.setRebateProgramName("Rebate Program");
    dto.setRebateInfo(rebateInfo);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.rebateInfo());
    assertTrue(result.rebateInfo().rebate());
    assertEquals("Rebate Program", result.rebateInfo().rebateProgramName());
  }

  @Test
  void testToSpotlightOffer_withVersionChanges_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    VersionChangesDto versionChanges = new VersionChangesDto();
    versionChanges.setSections(List.of("section1", "section2"));
    versionChanges.setPromotionSections(List.of("promo1"));
    versionChanges.setForecastSections(List.of("forecast1"));
    versionChanges.setMarketingSections(List.of("marketing1"));
    dto.setVersionChanges(versionChanges);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertNotNull(result.versionChanges());
    assertEquals(2, result.versionChanges().sections().size());
    assertEquals(1, result.versionChanges().promotionSections().size());
    assertEquals(1, result.versionChanges().forecastSections().size());
    assertEquals(1, result.versionChanges().marketingSections().size());
  }

  @Test
  void testToSpotlightOffer_withBooleanFields_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setActive(true);
    dto.setIsApprovedAndLocked(true);
    dto.setDualMaintenance(false);
    dto.setEditingInProgress(true);
    dto.setSignage(false);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertTrue(result.active());
    assertTrue(result.isApprovedAndLocked());
    assertFalse(result.dualMaintenance());
    assertTrue(result.editingInProgress());
    assertFalse(result.signage());
  }

  @Test
  void testToSpotlightOffer_withVersionAndCounters_shouldMapCorrectly() {
    OfferEventPublishDto dto = createBasicOfferEventDto();
    dto.setVersion(5);
    dto.setPatchesCount(10);
    dto.setFeaturedItemsCount(20);

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffer(dto);

    assertNotNull(result);
    assertEquals(5, result.version());
    assertEquals(0, result.activeCounter()); // Always 0 as per mapper
    assertEquals(10, result.patchesCount());
    assertEquals(20, result.featuredItemsCount());
  }

  @Test
  void testToSpotlightOffers_shouldDelegateToToSpotlightOffer() {
    OfferEventPublishDto dto = createBasicOfferEventDto();

    SpotlightOfferPayloadDto result = offerEventMapper.toSpotlightOffers(dto);

    assertNotNull(result);
    assertEquals(12345L, result.id());
  }

  @Test
  void testConvertLocalDateTimeToString_withValidDateTime_shouldFormatCorrectly() {
    LocalDateTime dateTime = LocalDateTime.of(2025, 4, 16, 3, 49, 17);
    String result = OfferEventMapper.convertLocalDateTimeToString(dateTime);
    assertEquals("2025-04-16 03:49:17", result);
  }

  @Test
  void testConvertLocalDateTimeToString_withNull_shouldReturnNull() {
    String result = OfferEventMapper.convertLocalDateTimeToString(null);
    assertNull(result);
  }

  private OfferEventPublishDto createBasicOfferEventDto() {
    OfferEventPublishDto dto = new OfferEventPublishDto();
    dto.setId(12345L);
    dto.setOfferTypeId(101);
    dto.setName("Test Offer");
    dto.setOfferType("CONDITIONAL_PRODUCT_DISCOUNTS");
    dto.setOfferTypeName("Conditional Product Discounts");
    dto.setOfferSubType("PRODUCT_DISCOUNTS");
    dto.setOfferSubTypeName("Product Discounts");
    dto.setShortDescription("Short description");
    dto.setVersion(1);
    dto.setCreatedBy("TestUser");
    dto.setModifiedBy("TestUser");
    dto.setTermsAndConditions("Terms and Conditions");
    dto.setOfferTactic("TACTIC1");
    dto.setEnrichedStatus("ENRICHED");
    dto.setPreviousStatus("PREVIOUS");
    dto.setCreatedByEmailId("creator@test.com");
    dto.setModifiedByEmailId("modifier@test.com");
    dto.setCatalogUrl("http://catalog.url");

    Alerts alerts = new Alerts();
    alerts.setHasError(false);
    alerts.setHasWarning(false);
    dto.setAlerts(alerts);

    return dto;
  }
}
