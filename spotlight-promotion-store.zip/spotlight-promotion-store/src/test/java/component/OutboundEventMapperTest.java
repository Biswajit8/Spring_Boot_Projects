package component;

import com.lowes.genie.avro.outboundEvent.Activity;
import com.lowes.genie.avro.outboundEvent.Block;
import com.lowes.genie.avro.outboundEvent.Campaign;
import com.lowes.genie.avro.outboundEvent.Criteria;
import com.lowes.genie.avro.outboundEvent.FeaturedItem;
import com.lowes.genie.avro.outboundEvent.Metadata;
import com.lowes.genie.avro.outboundEvent.Offer;
import com.lowes.genie.avro.outboundEvent.OfferItem;
import com.lowes.genie.avro.outboundEvent.OutboundEvent;
import com.lowes.genie.avro.outboundEvent.Page;
import com.lowes.genie.avro.outboundEvent.Reward;
import com.lowes.promotionstore.component.OutboundEventMapper;
import com.lowes.promotionstore.model.record.feedback.ActivityPayloadDto;
import com.lowes.promotionstore.model.record.feedback.BlockPayloadDto;
import com.lowes.promotionstore.model.record.feedback.CampaignPayloadDto;
import com.lowes.promotionstore.model.record.feedback.OfferDto;
import com.lowes.promotionstore.model.record.feedback.OfferEventPayloadDto;
import com.lowes.promotionstore.model.record.feedback.PagePayloadDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

class OutboundEventMapperTest {

  private OutboundEventMapper outboundEventMapper;

  @BeforeEach
  void setUp() {
    outboundEventMapper = new OutboundEventMapper();
  }

  @Test
  void testToDto_withNullSource_shouldReturnNull() {
    OfferEventPayloadDto result = outboundEventMapper.toDto(null);
    assertNull(result);
  }

  @Test
  void testToDto_withValidOutboundEvent_shouldMapBasicFields() {
    OutboundEvent event = createBasicOutboundEvent();

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertEquals("event-123", result.getId());
    assertEquals("OFFER", result.getType());
    assertEquals("CREATE", result.getOperation());
    assertEquals("WEB", result.getChannel());
  }

  @Test
  void testToDto_withCampaign_shouldMapCampaignCorrectly() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");

    Campaign campaign = new Campaign();
    campaign.setId("campaign-123");
    campaign.setName("Test Campaign");
    event.setCampaign(campaign);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNotNull(result.getCampaign());
    assertEquals("campaign-123", result.getCampaign().getId());
    assertEquals("Test Campaign", result.getCampaign().getName());
  }

  @Test
  void testToDto_withNullCampaign_shouldReturnNullCampaign() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");
    event.setCampaign(null);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNull(result.getCampaign());
  }

  @Test
  void testToDto_withActivity_shouldMapActivityCorrectly() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");

    Activity activity = new Activity();
    activity.setId("activity-123");
    activity.setAlias("activity-alias");
    activity.setName("Test Activity");
    activity.setStatus("ACTIVE");
    activity.setStartDate("2025-01-01 10:00:00");
    activity.setEndDate("2025-12-31 23:59:59");
    activity.setCustomers(List.of("customer1", "customer2"));
    activity.setDistribution(List.of("dist1", "dist2"));
    event.setActivity(activity);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNotNull(result.getActivity());
    assertEquals("activity-123", result.getActivity().getId());
    assertEquals("activity-alias", result.getActivity().getAlias());
    assertEquals("Test Activity", result.getActivity().getName());
    assertEquals("ACTIVE", result.getActivity().getStatus());
    assertNotNull(result.getActivity().getStartDate());
    assertNotNull(result.getActivity().getEndDate());
    assertEquals(2, result.getActivity().getCustomers().size());
    assertEquals(2, result.getActivity().getDistribution().size());
  }

  @Test
  void testToDto_withNullActivity_shouldReturnNullActivity() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");
    event.setActivity(null);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNull(result.getActivity());
  }

  @Test
  void testToDto_withOffer_shouldMapOfferCorrectly() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");

    Offer offer = new Offer();
    offer.setOfferId("offer-123");
    offer.setAllocationId("allocation-123");
    offer.setPatches(List.of("patch1", "patch2"));
    event.setOffer(offer);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNotNull(result.getOffer());
    assertEquals("offer-123", result.getOffer().getOfferId());
    assertEquals("allocation-123", result.getOffer().getAllocationId());
    assertEquals(2, result.getOffer().getPatches().size());
  }

  @Test
  void testToDto_withNullOffer_shouldReturnNullOffer() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");
    event.setOffer(null);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNull(result.getOffer());
  }

  @Test
  void testToDto_withPage_shouldMapPageCorrectly() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");

    Page page = new Page();
    page.setId("page-123");
    page.setAlias("page-alias");
    page.setType("HOME");
    page.setNumber(1);
    event.setPage(page);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNotNull(result.getPage());
    assertEquals("page-123", result.getPage().getId());
    assertEquals("page-alias", result.getPage().getAlias());
    assertEquals("HOME", result.getPage().getType());
    assertEquals(1, result.getPage().getNumber());
  }

  @Test
  void testToDto_withBlock_shouldMapBlockCorrectly() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");

    Block block = new Block();
    block.setId("block-123");
    block.setAlias("block-alias");
    block.setNumber(5);
    event.setBlock(block);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNotNull(result.getBlock());
    assertEquals("block-123", result.getBlock().getId());
    assertEquals("block-alias", result.getBlock().getAlias());
    assertEquals("5", result.getBlock().getNumber());
  }

  @Test
  void testToDto_withOfferMetadata_shouldMapMetadataCorrectly() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");

    Offer offer = new Offer();
    offer.setOfferId("offer-123");

    Metadata metadata = new Metadata();
    metadata.setMetadataId(456);

    Criteria criteria = new Criteria();
    criteria.setCriteriaId(789);

    FeaturedItem featuredItem = new FeaturedItem();
    featuredItem.setItem("item-123");
    featuredItem.setVendor("vendor-123");
    featuredItem.setModel("model-123");
    featuredItem.setPatches(List.of("patch1"));

    criteria.setFeaturedItems(List.of(featuredItem));
    metadata.setCriteria(List.of(criteria));

    Reward reward = new Reward();
    reward.setRewardId(101);

    OfferItem offerItem = new OfferItem();
    offerItem.setItem("reward-item-123");
    offerItem.setVendor("reward-vendor-123");
    offerItem.setModel("reward-model-123");
    offerItem.setPatches(List.of("reward-patch1"));

    reward.setFeaturedItems(List.of(offerItem));
    metadata.setRewards(List.of(reward));

    offer.setMetadata(List.of(metadata));
    event.setOffer(offer);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNotNull(result.getOffer());
    assertNotNull(result.getOffer().getMetadata());
    assertEquals(1, result.getOffer().getMetadata().size());
    assertEquals("456", result.getOffer().getMetadata().get(0).getMetadataId());
    assertEquals(1, result.getOffer().getMetadata().get(0).getCriteria().size());
    assertEquals("789", result.getOffer().getMetadata().get(0).getCriteria().get(0).getCriteriaId());
    assertEquals(1, result.getOffer().getMetadata().get(0).getRewards().size());
    assertEquals("101", result.getOffer().getMetadata().get(0).getRewards().get(0).getRewardId());
  }

  @Test
  void testToDto_withInvalidDateFormat_shouldHandleGracefully() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");

    Activity activity = new Activity();
    activity.setId("activity-123");
    activity.setStartDate("invalid-date-format");
    activity.setEndDate("also-invalid");
    event.setActivity(activity);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNotNull(result.getActivity());
    assertNull(result.getActivity().getStartDate());
    assertNull(result.getActivity().getEndDate());
  }

  @Test
  void testToDto_withIsoDateFormat_shouldParseCorrectly() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");

    Activity activity = new Activity();
    activity.setId("activity-123");
    activity.setStartDate("2025-01-01T10:00:00");
    event.setActivity(activity);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNotNull(result.getActivity());
    assertNotNull(result.getActivity().getStartDate());
  }

  @Test
  void testToDto_withEmptyDateString_shouldReturnNull() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");

    Activity activity = new Activity();
    activity.setId("activity-123");
    activity.setStartDate("");
    activity.setEndDate("   ");
    event.setActivity(activity);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNotNull(result.getActivity());
    assertNull(result.getActivity().getStartDate());
  }

  @Test
  void testToDto_withNullCustomersAndDistribution_shouldReturnNull() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");

    Activity activity = new Activity();
    activity.setId("activity-123");
    activity.setCustomers(null);
    activity.setDistribution(null);
    event.setActivity(activity);

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNotNull(result.getActivity());
    assertNull(result.getActivity().getCustomers());
    assertNull(result.getActivity().getDistribution());
  }

  @Test
  void testToDto_withFullyPopulatedEvent_shouldMapAllFields() {
    OutboundEvent event = createFullyPopulatedOutboundEvent();

    OfferEventPayloadDto result = outboundEventMapper.toDto(event);

    assertNotNull(result);
    assertNotNull(result.getId());
    assertNotNull(result.getType());
    assertNotNull(result.getOperation());
    assertNotNull(result.getChannel());
    assertNotNull(result.getCampaign());
    assertNotNull(result.getActivity());
    assertNotNull(result.getOffer());
    assertNotNull(result.getPage());
    assertNotNull(result.getBlock());
  }

  private OutboundEvent createBasicOutboundEvent() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");
    event.setType("OFFER");
    event.setOperation("CREATE");
    event.setChannel("WEB");
    return event;
  }

  private OutboundEvent createFullyPopulatedOutboundEvent() {
    OutboundEvent event = new OutboundEvent();
    event.setId("event-123");
    event.setType("OFFER");
    event.setOperation("CREATE");
    event.setChannel("WEB");

    Campaign campaign = new Campaign();
    campaign.setId("campaign-123");
    campaign.setName("Test Campaign");
    event.setCampaign(campaign);

    Activity activity = new Activity();
    activity.setId("activity-123");
    activity.setAlias("activity-alias");
    activity.setName("Test Activity");
    activity.setStatus("ACTIVE");
    activity.setStartDate("2025-01-01 10:00:00");
    activity.setEndDate("2025-12-31 23:59:59");
    event.setActivity(activity);

    Offer offer = new Offer();
    offer.setOfferId("offer-123");
    offer.setAllocationId("allocation-123");
    event.setOffer(offer);

    Page page = new Page();
    page.setId("page-123");
    page.setAlias("page-alias");
    page.setType("HOME");
    page.setNumber(1);
    event.setPage(page);

    Block block = new Block();
    block.setId("block-123");
    block.setAlias("block-alias");
    block.setNumber(5);
    event.setBlock(block);

    return event;
  }
}
