package component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lowes.promotionstore.component.ForecastDataMapper;
import com.lowes.promotionstore.component.PartialMapBuilders;
import com.lowes.promotionstore.component.SalesDataMapper;
import com.lowes.promotionstore.component.SpotlightPromoStoreEntityMapper;
import com.lowes.promotionstore.component.search.CalendarRangeResolver;
import com.lowes.promotionstore.configuration.ObjectMapperConfig;
import com.lowes.promotionstore.entity.spotlight.IncludeItemStores;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.DiscountTypeEnum;
import com.lowes.promotionstore.repository.rest.CoreDataRepository;
import com.lowes.promotionstore.repository.rest.SpotlightApiRepository;
import com.lowes.promotionstore.service.coredata.CalendarService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import util.TestUtil;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

import static java.util.Comparator.naturalOrder;
import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SpotlightPromoStoreEntityMapperTest {

  private TestUtil testUtil;

  private SpotlightPromoStoreEntityMapper spotlightPromoStoreEntityMapper;

  private CalendarService calendarService;

  public CalendarRangeResolver calendarRangeResolver;

  @Mock
  private CoreDataRepository coreDataRepository;

  @Mock
  private ForecastDataMapper forecastDataMapper;

  @Mock
  private SalesDataMapper salesDataMapper;

  @Mock
  private PartialMapBuilders partialMapBuilders;

  @Mock
  private SpotlightApiRepository spotlightApiRepository;

  private ObjectMapperConfig objectMapper;

  @BeforeEach
  void setUp() {
    testUtil = new TestUtil();
    partialMapBuilders = new PartialMapBuilders(objectMapper);
    calendarRangeResolver = new CalendarRangeResolver(calendarService);
    calendarService = new CalendarService(coreDataRepository);
    spotlightPromoStoreEntityMapper = new SpotlightPromoStoreEntityMapper(coreDataRepository,
        forecastDataMapper, salesDataMapper, partialMapBuilders, calendarRangeResolver, spotlightApiRepository);
  }


  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_2/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType2(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_2/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_2/" + testId + "/promotionstore.json");

    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);
    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    Comparator<IncludeItemStores> cmp =
        Comparator.comparing(IncludeItemStores::getItemQualificationType,
                Comparator.nullsLast(naturalOrder()))
            .thenComparing(IncludeItemStores::getItemNo, Comparator.nullsLast(naturalOrder()))
            .thenComparing(IncludeItemStores::getModelNo, Comparator.nullsLast(naturalOrder()))
            .thenComparing(IncludeItemStores::getVendorNo, Comparator.nullsLast(naturalOrder()));

// compare the rest of the object, skipping the field we just checked
    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringFields("includeItemStores",
            "rawOffer", "indexedTs", "modifiedTs", "createdTs", "activatedTs", "deactivatedTs")
        .isEqualTo(expectedPromotionStore);


  }

  private static PromotionStore convertStringToPromotionStore(String peExpectedPromotion)
      throws JsonProcessingException {
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    return objectMapper.readValue(peExpectedPromotion, PromotionStore.class);
  }


  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_3/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType3(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_3/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_3/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringFields("rawOffer", "indexedTs", "modifiedTs", "createdTs", "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_4/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType4(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_4/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_4/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringFields("rawOffer", "includeItemStores", "indexedTs", "modifiedTs", "createdTs",
            "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_5/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType5(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_5/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_5/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringFields("rawOffer", "includeItemStores", "indexedTs", "modifiedTs", "createdTs",
            "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_6/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType6(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_6/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_6/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringFields("rawOffer", "indexedTs", "modifiedTs", "createdTs", "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_7/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType7(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_7/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_7/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringFields("rawOffer", "indexedTs", "modifiedTs", "createdTs", "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_8/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType8(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_8/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_8/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringCollectionOrderInFields("includeItemStores")
        .ignoringFields("rawOffer", "indexedTs", "includeItemStores", "modifiedTs", "createdTs",
            "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_9/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType9(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_9/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_9/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringCollectionOrderInFields("includeItemStores")
        .ignoringFields("rawOffer", "indexedTs", "modifiedTs", "createdTs", "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_10/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType10(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_10/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_10/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringCollectionOrderInFields("includeItemStores")
        .ignoringFields("rawOffer", "includeItemStores", "indexedTs", "modifiedTs", "createdTs",
            "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_11/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType11(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_11/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_11/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringCollectionOrderInFields("includeItemStores")
        .ignoringFields("rawOffer", "includeItemStores", "indexedTs", "modifiedTs", "createdTs",
            "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_103/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType103(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_103/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_103/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    when(spotlightApiRepository.getExternalCatalogueItems(anyLong(), anyString())).thenReturn(
        testUtil.createAsyncUploadFileObjectAllStores());

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));
    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringCollectionOrderInFields("includeItemStores")
        .ignoringFields("rawOffer", "indexedTs", "modifiedTs", "createdTs", "activatedTs",
            "deactivatedTs", "amplificationChannel")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_13/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType13(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_13/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_13/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringCollectionOrderInFields("includeItemStores")
        .ignoringFields("rawOffer", "includeItemStores", "indexedTs", "modifiedTs", "createdTs",
            "activatedTs",
            "deactivatedTs", "amplificationChannel")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_14/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType14(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_14/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_14/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringCollectionOrderInFields("includeItemStores")
        .ignoringFields("rawOffer", "includeItemStores", "indexedTs", "modifiedTs", "createdTs",
            "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_16/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType16(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_16/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_16/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringFields("rawOffer", "includeItemStores", "indexedTs", "modifiedTs", "createdTs",
            "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_17/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType17(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_17/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_17/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringFields("rawOffer", "includeItemStores", "indexedTs", "modifiedTs", "createdTs",
            "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @ParameterizedTest(name = "{index} {1}")
  @CsvFileSource(resources = "/mocks/offertypeid_101/test_data.csv", numLinesToSkip = 1)
  void testCreatePromotion_OfferType101(String testId,
      String testName) throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_101/" + testId + "/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_101/" + testId + "/promotionstore.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringCollectionOrderInFields("includeItemStores")
        .ignoringFields("rawOffer", "includeItemStores", "indexedTs", "modifiedTs", "createdTs",
            "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @Test
  @DisplayName("Test Patch offer on Patches")
  void testCreatePromotion_OfferType103_PatchOnly() throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_103/test1/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_103/patchonly.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    when(spotlightApiRepository.getExternalCatalogueItems(anyLong(), anyString())).thenReturn(
        testUtil.createAsyncUploadFileObjectPathcesOnly());

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));
    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringCollectionOrderInFields("includeItemStores")
        .ignoringFields("rawOffer", "indexedTs", "modifiedTs", "createdTs", "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @Test
  @DisplayName("Test Patch offer on Stores")
  void testCreatePromotion_OfferType103_StoreOnly() throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_103/test1/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_103/storeonly.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    when(spotlightApiRepository.getExternalCatalogueItems(anyLong(), anyString())).thenReturn(
        testUtil.createAsyncUploadFileObjectStores());

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));
    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringFields("rawOffer", "indexedTs", "modifiedTs", "createdTs", "activatedTs",
            "deactivatedTs", "amplificationChannel")
        .ignoringCollectionOrderInFields("includeItemStores")
        .isEqualTo(expectedPromotionStore);
  }

  @Test
  @DisplayName("Test Patch offer on Store & Patch")
  void testCreatePromotion_OfferType103_StoreAndPatch() throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_103/test1/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_103/patch_store.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    when(spotlightApiRepository.getExternalCatalogueItems(anyLong(), anyString())).thenReturn(
        testUtil.createAsyncUploadFileObjectPatchStores());

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));

    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringCollectionOrderInFields("includeItemStores")
        .ignoringFields("rawOffer", "indexedTs", "modifiedTs", "createdTs", "activatedTs",
            "deactivatedTs", "amplificationChannel")
        .isEqualTo(expectedPromotionStore);
  }

  @Test
  @DisplayName("Test Patch offer on Patch & All Stores")
  void testCreatePromotion_OfferType103_PatchAndAllStores() throws URISyntaxException,
      IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_103/test1/spotlight.json");
    String peExpectedPromotion = testUtil.readFromFile(
        "mocks/offertypeid_103/patch_allstores.json");
    PromotionStore expectedPromotionStore = convertStringToPromotionStore(peExpectedPromotion);

    when(spotlightApiRepository.getExternalCatalogueItems(anyLong(), anyString())).thenReturn(
        testUtil.createAsyncUploadFileObjectPatchAllStores());

    PromotionStore promotionStore =
        spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(
            testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion));
    assertThat(promotionStore).usingRecursiveComparison()
        .ignoringCollectionOrderInFields("includeItemStores")
        .ignoringFields("rawOffer", "indexedTs", "modifiedTs", "createdTs", "activatedTs",
            "deactivatedTs")
        .isEqualTo(expectedPromotionStore);
  }

  @Test
  @DisplayName("Test Exclude update to Forecast returns true")
  void testExcludeUpdateToForecast_ReturnsTrue() throws URISyntaxException, IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_2/test1/spotlight.json");
    SpotlightOfferPayloadDto spotlightOfferDto = testUtil.parseStringToSpotlightOfferDto(
        spotlightMockPromotion);
    boolean result = spotlightPromoStoreEntityMapper.excludeUpdateToForecast(spotlightOfferDto);
    assertTrue(result);
  }

  @Test
  @DisplayName("Test Exclude update to Forecast return false")
  void testExcludeUpdateToForecast_ReturnsFalse() throws URISyntaxException, IOException {
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_2/test2/spotlight.json");
    SpotlightOfferPayloadDto spotlightOfferDto = testUtil.parseStringToSpotlightOfferDto(
        spotlightMockPromotion);
    boolean result = spotlightPromoStoreEntityMapper.excludeUpdateToForecast(spotlightOfferDto);
    assertFalse(result);
  }
}
