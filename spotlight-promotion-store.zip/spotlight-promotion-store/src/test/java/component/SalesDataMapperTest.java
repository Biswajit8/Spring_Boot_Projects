package component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowes.promotionstore.component.SalesDataMapper;
import com.lowes.promotionstore.component.SpotlightOfferMapper;
import com.lowes.promotionstore.configuration.ObjectMapperConfig;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.model.record.spotlight.OfferSalesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import util.TestUtil;

import java.math.RoundingMode;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class SalesDataMapperTest {

  private SpotlightOfferMapper spotlightOfferMapper;
  private SalesDataMapper salesDataMapper;
  private ObjectMapper objectMapper;
  private TestUtil testUtil;

  @BeforeEach
  void setup() {
    ObjectMapperConfig objectMapperConfig = mock(ObjectMapperConfig.class);
    spotlightOfferMapper = new SpotlightOfferMapper();
    objectMapper = new ObjectMapper();
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);
    salesDataMapper = new SalesDataMapper(objectMapperConfig);
    testUtil = new TestUtil();
  }

  @Test
  void testMapOfferSalesMetrics_WithRawOffer() throws JsonProcessingException {
    PromotionStore promotionStore = new PromotionStore();
    SpotlightOfferPayloadDto spotlightOffer = testUtil.mockSpotlightOffer();
    String rawOfferJson = objectMapper.writeValueAsString(spotlightOffer);
    promotionStore.setRawOffer(rawOfferJson);

    OfferSalesPayloadDto offerSalesDto = testUtil.mockOfferSalesDto();

    salesDataMapper.mapOfferSalesMetrics(promotionStore, offerSalesDto);

    assertEquals(offerSalesDto.sales(), promotionStore.getSales());
    assertEquals(offerSalesDto.netIncrSales(), promotionStore.getIncSales());
    assertEquals(offerSalesDto.units(), promotionStore.getSalesUnits());
    assertEquals(offerSalesDto.netIncrUnits(), promotionStore.getSalesIncUnits());
    assertEquals(offerSalesDto.margin(), promotionStore.getSalesMargin());
    assertEquals(offerSalesDto.netIncrMargin(), promotionStore.getSalesIncMargin());
    assertEquals(
        offerSalesDto.netIncrSales().divide(offerSalesDto.discount(), 4, RoundingMode.HALF_UP),
        promotionStore.getSalesROI()
    );
  }

  @Test
  void testMapOfferSalesMetrics_NullRawOffer() throws JsonProcessingException {
    PromotionStore promotionStore = new PromotionStore();
    promotionStore.setRawOffer(null);

    OfferSalesPayloadDto offerSalesDto = testUtil.mockOfferSalesDto();

    salesDataMapper.mapOfferSalesMetrics(promotionStore, offerSalesDto);

    assertEquals(offerSalesDto.sales(), promotionStore.getSales());
    assertEquals(offerSalesDto.netIncrSales(), promotionStore.getIncSales());
    assertEquals(offerSalesDto.units(), promotionStore.getSalesUnits());
    assertEquals(offerSalesDto.netIncrUnits(), promotionStore.getSalesIncUnits());
    assertEquals(offerSalesDto.margin(), promotionStore.getSalesMargin());
    assertEquals(offerSalesDto.netIncrMargin(), promotionStore.getSalesIncMargin());
    assertEquals(
        offerSalesDto.netIncrSales().divide(offerSalesDto.discount(), 4, RoundingMode.HALF_UP),
        promotionStore.getSalesROI()
    );
  }
}
