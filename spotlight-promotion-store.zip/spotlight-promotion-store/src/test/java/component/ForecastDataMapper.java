package component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowes.promotionstore.component.ForecastDataMapper;
import com.lowes.promotionstore.component.SpotlightOfferMapper;
import com.lowes.promotionstore.configuration.ObjectMapperConfig;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.model.record.spotlight.ForecastDataDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import util.TestUtil;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ForecastDataMapperTest {

  @Mock
  private SpotlightOfferMapper spotlightOfferMapper;
  private ForecastDataMapper forecastDataMapper;
  private ObjectMapper objectMapper;
  private TestUtil testUtil;

  @BeforeEach
  void setup() {
    ObjectMapperConfig objectMapperConfig = mock(ObjectMapperConfig.class);
    spotlightOfferMapper = new SpotlightOfferMapper();
    objectMapper = new ObjectMapper();
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);
    forecastDataMapper = new ForecastDataMapper(objectMapperConfig);
    testUtil = new TestUtil();
  }

  @Test
  void testMapForecastData_WithRawOffer() throws JsonProcessingException {

    PromotionStore promotionStore = new PromotionStore();
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();

    PromotionStore result = forecastDataMapper.mapForecastData(promotionStore, forecastDataDto);

    assertNotNull(result);
    assertEquals(forecastDataDto.promotedMarginWithFunding(),
        result.getPromotedMarginWithFunding());
    assertEquals(forecastDataDto.switchingAdjustedIncrementalMargin(),
        result.getSwitchingAdjustedIncrementalMargin());
    assertEquals(forecastDataDto.promotedSales(), result.getPromotedSales());
    assertEquals(forecastDataDto.switchingAdjustedIncrementalSales(),
        result.getSwitchingAdjustedIncrementalSales());
    assertEquals(forecastDataDto.promotedVolume(), result.getPromotedVolume());
    assertEquals(forecastDataDto.switchingAdjustedIncrementalVolume(),
        result.getSwitchingAdjustedIncrementalVolume());
  }

  @Test
  void testMapForecastData_NullRawOffer() throws JsonProcessingException {

    PromotionStore promotionStore = new PromotionStore();
    promotionStore.setRawOffer(null);
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();

    PromotionStore result = forecastDataMapper.mapForecastData(promotionStore, forecastDataDto);

    assertNotNull(result);
    assertEquals(forecastDataDto.promotedMarginWithFunding(),
        result.getPromotedMarginWithFunding());
    assertEquals(forecastDataDto.switchingAdjustedIncrementalMargin(),
        result.getSwitchingAdjustedIncrementalMargin());
    assertEquals(forecastDataDto.promotedSales(), result.getPromotedSales());
    assertEquals(forecastDataDto.switchingAdjustedIncrementalSales(),
        result.getSwitchingAdjustedIncrementalSales());
    assertEquals(forecastDataDto.promotedVolume(), result.getPromotedVolume());
    assertEquals(forecastDataDto.switchingAdjustedIncrementalVolume(),
        result.getSwitchingAdjustedIncrementalVolume());
  }
}