package component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowes.promotionstore.component.PartialMapBuilders;
import com.lowes.promotionstore.configuration.ObjectMapperConfig;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class PartialMapBuildersTest {

  private PartialMapBuilders partialMapBuilders;

  @Mock
  private ObjectMapperConfig objectMapperConfig;

  private ObjectMapper objectMapper;

  @BeforeEach
  void setUp() {
    objectMapper = new ObjectMapper();
    partialMapBuilders = new PartialMapBuilders(objectMapperConfig);
  }

  @Test
  void testFrom_withNullDoc_shouldReturnEmptyBuilder() {
    PartialMapBuilders.Builder<?> builder = partialMapBuilders.from(null);
    Map<String, Object> result = builder.build();

    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void testFrom_withValidDoc_shouldConvertToMap() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    PartialMapBuilders.Builder<TestDoc> builder = partialMapBuilders.from(doc);
    Map<String, Object> result = builder.build();

    assertNotNull(result);
    assertEquals("value1", result.get("field1"));
    assertEquals("value2", result.get("field2"));
    assertEquals(123, result.get("field3"));
  }

  @Test
  void testBuilder_startEmpty_shouldClearAllFields() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .startEmpty()
        .build();

    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void testBuilder_include_shouldAddSpecificKeys() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .startEmpty()
        .include(List.of("field1", "field3"))
        .build();

    assertNotNull(result);
    assertEquals(2, result.size());
    assertEquals("value1", result.get("field1"));
    assertEquals(123, result.get("field3"));
    assertFalse(result.containsKey("field2"));
  }

  @Test
  void testBuilder_keepOnly_shouldRetainOnlySpecifiedKeys() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .keepOnly(List.of("field1"))
        .build();

    assertNotNull(result);
    assertEquals(1, result.size());
    assertEquals("value1", result.get("field1"));
  }

  @Test
  void testBuilder_exclude_shouldRemoveSpecifiedKeys() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .exclude(List.of("field2"))
        .build();

    assertNotNull(result);
    assertEquals(2, result.size());
    assertTrue(result.containsKey("field1"));
    assertTrue(result.containsKey("field3"));
    assertFalse(result.containsKey("field2"));
  }

  @Test
  void testBuilder_dropNulls_shouldRemoveNullValues() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", null, 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .dropNulls()
        .build();

    assertNotNull(result);
    assertFalse(result.containsKey("field2"));
    assertTrue(result.containsKey("field1"));
    assertTrue(result.containsKey("field3"));
  }

  @Test
  void testBuilder_dropEmpties_shouldRemoveEmptyValues() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDocWithCollections doc = new TestDocWithCollections(
        "value1", "", List.of(), new HashMap<>(), 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .dropEmpties()
        .build();

    assertNotNull(result);
    assertTrue(result.containsKey("field1"));
    assertFalse(result.containsKey("emptyString"));
    assertFalse(result.containsKey("emptyList"));
    assertFalse(result.containsKey("emptyMap"));
    assertTrue(result.containsKey("number"));
  }

  @Test
  void testBuilder_filter_shouldApplyCustomPredicate() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .filter((key, value) -> key.startsWith("field1"))
        .build();

    assertNotNull(result);
    assertEquals(1, result.size());
    assertTrue(result.containsKey("field1"));
  }

  @Test
  void testBuilder_chainedOperations_shouldWorkCorrectly() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .exclude(List.of("field3"))
        .dropNulls()
        .build();

    assertNotNull(result);
    assertEquals(2, result.size());
    assertTrue(result.containsKey("field1"));
    assertTrue(result.containsKey("field2"));
  }

  @Test
  void testBuilder_include_withNullKeys_shouldNotFail() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .startEmpty()
        .include(null)
        .build();

    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void testBuilder_include_withEmptyKeys_shouldNotFail() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .startEmpty()
        .include(List.of())
        .build();

    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void testBuilder_keepOnly_withNullKeys_shouldNotFail() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .keepOnly(null)
        .build();

    assertNotNull(result);
  }

  @Test
  void testBuilder_exclude_withNullKeys_shouldNotFail() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .exclude(null)
        .build();

    assertNotNull(result);
    assertEquals(3, result.size());
  }

  @Test
  void testBuilder_exclude_withEmptyKeys_shouldNotFail() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .exclude(List.of())
        .build();

    assertNotNull(result);
    assertEquals(3, result.size());
  }

  @Test
  void testBuilder_filter_withNullPredicate_shouldNotFail() {
    when(objectMapperConfig.objectMapper()).thenReturn(objectMapper);

    TestDoc doc = new TestDoc("value1", "value2", 123);

    Map<String, Object> result = partialMapBuilders.from(doc)
        .filter(null)
        .build();

    assertNotNull(result);
    assertEquals(3, result.size());
  }

  // Test helper classes
  public static class TestDoc {
    private String field1;
    private String field2;
    private int field3;

    public TestDoc() {
    }

    public TestDoc(String field1, String field2, int field3) {
      this.field1 = field1;
      this.field2 = field2;
      this.field3 = field3;
    }

    public String getField1() {
      return field1;
    }

    public void setField1(String field1) {
      this.field1 = field1;
    }

    public String getField2() {
      return field2;
    }

    public void setField2(String field2) {
      this.field2 = field2;
    }

    public int getField3() {
      return field3;
    }

    public void setField3(int field3) {
      this.field3 = field3;
    }
  }

  public static class TestDocWithCollections {
    private String field1;
    private String emptyString;
    private List<String> emptyList;
    private Map<String, String> emptyMap;
    private int number;

    public TestDocWithCollections() {
    }

    public TestDocWithCollections(String field1, String emptyString, List<String> emptyList,
        Map<String, String> emptyMap, int number) {
      this.field1 = field1;
      this.emptyString = emptyString;
      this.emptyList = emptyList;
      this.emptyMap = emptyMap;
      this.number = number;
    }

    public String getField1() {
      return field1;
    }

    public void setField1(String field1) {
      this.field1 = field1;
    }

    public String getEmptyString() {
      return emptyString;
    }

    public void setEmptyString(String emptyString) {
      this.emptyString = emptyString;
    }

    public List<String> getEmptyList() {
      return emptyList;
    }

    public void setEmptyList(List<String> emptyList) {
      this.emptyList = emptyList;
    }

    public Map<String, String> getEmptyMap() {
      return emptyMap;
    }

    public void setEmptyMap(Map<String, String> emptyMap) {
      this.emptyMap = emptyMap;
    }

    public int getNumber() {
      return number;
    }

    public void setNumber(int number) {
      this.number = number;
    }
  }
}
