package component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowes.promotionstore.component.MessageMapper;
import com.lowes.promotionstore.exception.types.custom.SpotlightApplicationException;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import util.TestUtil;

import java.io.IOException;
import java.net.URISyntaxException;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class MessageMapperTest {

  private TestUtil testUtil;

  @Mock
  private ObjectMapper objectMapper;

  @InjectMocks
  private MessageMapper messageMapper;

  private String message;
  private SpotlightOfferPayloadDto spotlightOfferDTO;

  @BeforeEach
  void setUp() {
    testUtil = new TestUtil();
  }

  @Test
  void testParseStringToPromotionPublishDtoSuccess() throws URISyntaxException, IOException {
    message = testUtil.readFromFile("mocks/offertypeid_3/test1/spotlight.json");
    spotlightOfferDTO = testUtil.parseStringToSpotlightOfferDto(message);
    SpotlightOfferPayloadDto result = messageMapper.parseStringToObject(message, SpotlightOfferPayloadDto.class);
    assertEquals(spotlightOfferDTO, result);
  }

  @Test
  void testParseStringToPromotionPublishDto_InvalidJson() {
    String invalidJson = "{id: \"100292\", name: \"BXGY\"}";
    assertThrows(SpotlightApplicationException.class, () -> {
      messageMapper.parseStringToObject(invalidJson, SpotlightOfferPayloadDto.class);
    });
  }
}
