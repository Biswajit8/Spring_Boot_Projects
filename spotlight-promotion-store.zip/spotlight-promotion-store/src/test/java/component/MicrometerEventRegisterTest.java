package component;

import com.lowes.promotionstore.component.MicrometerEventRegister;
import com.lowes.promotionstore.model.record.micrometer.RegistryEvent;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class MicrometerEventRegisterTest {

  private MicrometerEventRegister micrometerEventRegister;

  @Mock
  private MeterRegistry meterRegistry;

  @Mock
  private Counter counter;

  @BeforeEach
  void setUp() {
    micrometerEventRegister = new MicrometerEventRegister(meterRegistry);
  }

  @Test
  void testIncrementCounter_shouldCreateCounterWithCorrectTags() {
    RegistryEvent event = RegistryEvent.builder()
        .event("test_event")
        .source("test_source")
        .message("test_message")
        .build();

    when(meterRegistry.counter(
        eq("test_event"),
        eq("source"), eq("test_source"),
        eq("message"), eq("test_message")
    )).thenReturn(counter);

    micrometerEventRegister.incrementCounter(event);

    verify(meterRegistry).counter(
        eq("test_event"),
        eq("source"), eq("test_source"),
        eq("message"), eq("test_message")
    );
    verify(counter).increment();
  }

  @Test
  void testIncrementCounter_withKafkaProcessingFailure_shouldIncrementCorrectly() {
    RegistryEvent event = RegistryEvent.builder()
        .event("kafka_offer_product_consumer_process_failure")
        .source("offer-product-topic")
        .message("MESSAGE_PARSING_FAILURE")
        .build();

    when(meterRegistry.counter(
        eq("kafka_offer_product_consumer_process_failure"),
        eq("source"), eq("offer-product-topic"),
        eq("message"), eq("MESSAGE_PARSING_FAILURE")
    )).thenReturn(counter);

    micrometerEventRegister.incrementCounter(event);

    verify(meterRegistry).counter(
        eq("kafka_offer_product_consumer_process_failure"),
        eq("source"), eq("offer-product-topic"),
        eq("message"), eq("MESSAGE_PARSING_FAILURE")
    );
    verify(counter).increment();
  }

  @Test
  void testIncrementCounter_withProcessingFailure_shouldIncrementCorrectly() {
    RegistryEvent event = RegistryEvent.builder()
        .event("kafka_offer_product_consumer_process_failure")
        .source("offer-product-topic")
        .message("MESSAGE_PROCESSING_FAILURE")
        .build();

    when(meterRegistry.counter(
        eq("kafka_offer_product_consumer_process_failure"),
        eq("source"), eq("offer-product-topic"),
        eq("message"), eq("MESSAGE_PROCESSING_FAILURE")
    )).thenReturn(counter);

    micrometerEventRegister.incrementCounter(event);

    verify(meterRegistry).counter(
        eq("kafka_offer_product_consumer_process_failure"),
        eq("source"), eq("offer-product-topic"),
        eq("message"), eq("MESSAGE_PROCESSING_FAILURE")
    );
    verify(counter).increment();
  }

  @Test
  void testIncrementCounter_withDifferentEventNames_shouldCreateDifferentCounters() {
    RegistryEvent event1 = RegistryEvent.builder()
        .event("event_type_1")
        .source("source_1")
        .message("message_1")
        .build();

    RegistryEvent event2 = RegistryEvent.builder()
        .event("event_type_2")
        .source("source_2")
        .message("message_2")
        .build();

    when(meterRegistry.counter(
        eq("event_type_1"),
        eq("source"), eq("source_1"),
        eq("message"), eq("message_1")
    )).thenReturn(counter);

    when(meterRegistry.counter(
        eq("event_type_2"),
        eq("source"), eq("source_2"),
        eq("message"), eq("message_2")
    )).thenReturn(counter);

    micrometerEventRegister.incrementCounter(event1);
    micrometerEventRegister.incrementCounter(event2);

    verify(meterRegistry).counter(
        eq("event_type_1"),
        eq("source"), eq("source_1"),
        eq("message"), eq("message_1")
    );
    verify(meterRegistry).counter(
        eq("event_type_2"),
        eq("source"), eq("source_2"),
        eq("message"), eq("message_2")
    );
  }

  @Test
  void testIncrementCounter_withNullValues_shouldPassNullToRegistry() {
    RegistryEvent event = RegistryEvent.builder()
        .event("test_event")
        .source(null)
        .message(null)
        .build();

    when(meterRegistry.counter(
        eq("test_event"),
        eq("source"), eq((String) null),
        eq("message"), eq((String) null)
    )).thenReturn(counter);

    micrometerEventRegister.incrementCounter(event);

    verify(counter).increment();
  }
}
