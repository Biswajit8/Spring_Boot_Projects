package component;

import com.lowes.model.generated.ChildItemDto;
import com.lowes.model.generated.OfferProductDto;
import com.lowes.promotionstore.component.OfferProductMapper;
import com.lowes.promotionstore.entity.offerproductstore.OfferProductStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class OfferProductMapperTest {

  private OfferProductMapper offerProductMapper;

  @BeforeEach
  void setUp() {
    offerProductMapper = new OfferProductMapper();
  }

  @Test
  void testCreateItemEntities_withFullyPopulatedDto_shouldMapAllFields() {
    OfferProductDto dto = createFullOfferProductDto();
    Set<OfferProductDto> dtoSet = Set.of(dto);

    List<OfferProductStore> result = offerProductMapper.createItemEntities(dtoSet);

    assertEquals(1, result.size());
    OfferProductStore entity = result.get(0);

    assertEquals("omni-123", entity.getOmniItemId());
    assertEquals("12345", entity.getItemNumber());
    assertEquals("model-001", entity.getModelId());
    assertEquals("vendor-001", entity.getVendorNumber());
    assertEquals("ITEM", entity.getProductType());
    assertEquals("assort-001", entity.getAssortmentId());
    assertEquals("pg-001", entity.getProductGroupId());
    assertEquals("subdiv-001", entity.getSubdivisionId());
    assertEquals("div-001", entity.getDivisionId());
    assertEquals("ba-001", entity.getBusinessAreaId());
    assertEquals("brand-001", entity.getBrandId());
    assertEquals("STOCK", entity.getProgramType());
    assertEquals("true", entity.getIsPublished());
    assertEquals("true", entity.getIsBuyable());
    assertEquals(true, entity.getProductStatus());
    assertEquals("ACTIVE", entity.getStatus());
    assertNotNull(entity.getIndexedTs());
    assertNotNull(entity.getId());
  }

  @Test
  void testCreateItemEntities_withMerchBucketIds_shouldMapCorrectly() {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId("omni-123");
    dto.setItemNumber("12345");
    dto.setMerchBucketIds(List.of("mb-001", "mb-002", "mb-003"));
    dto.setDigitalTaxonomyIds(List.of());
    dto.setChildItems(List.of());

    List<OfferProductStore> result = offerProductMapper.createItemEntities(Set.of(dto));

    assertEquals(1, result.size());
    assertEquals(3, result.get(0).getMerchBucketIds().size());
    assertTrue(result.get(0).getMerchBucketIds().contains("mb-001"));
    assertTrue(result.get(0).getMerchBucketIds().contains("mb-002"));
    assertTrue(result.get(0).getMerchBucketIds().contains("mb-003"));
  }

  @Test
  void testCreateItemEntities_withDigitalTaxonomyIds_shouldMapCorrectly() {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId("omni-123");
    dto.setItemNumber("12345");
    dto.setMerchBucketIds(List.of());
    dto.setDigitalTaxonomyIds(List.of("dt-001", "dt-002"));
    dto.setChildItems(List.of());

    List<OfferProductStore> result = offerProductMapper.createItemEntities(Set.of(dto));

    assertEquals(1, result.size());
    assertEquals(2, result.get(0).getDigitalTaxonomyIds().size());
    assertTrue(result.get(0).getDigitalTaxonomyIds().contains("dt-001"));
    assertTrue(result.get(0).getDigitalTaxonomyIds().contains("dt-002"));
  }

  @Test
  void testCreateItemEntities_withChildItems_shouldMapCorrectly() {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId("omni-123");
    dto.setItemNumber("12345");
    dto.setMerchBucketIds(List.of());
    dto.setDigitalTaxonomyIds(List.of());

    ChildItemDto childItem = new ChildItemDto();
    childItem.setVbu("vbu-001");
    childItem.setItemNumber("child-item-001");
    childItem.setModelId("child-model-001");
    childItem.setOmniItemId("child-omni-001");

    dto.setChildItems(List.of(childItem));

    List<OfferProductStore> result = offerProductMapper.createItemEntities(Set.of(dto));

    assertEquals(1, result.size());
    assertEquals(1, result.get(0).getChildItems().size());
  }

  @Test
  void testCreateItemEntities_withNullChildItems_shouldHandleGracefully() {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId("omni-123");
    dto.setItemNumber("12345");
    dto.setMerchBucketIds(List.of());
    dto.setDigitalTaxonomyIds(List.of());
    dto.setChildItems(null);

    List<OfferProductStore> result = offerProductMapper.createItemEntities(Set.of(dto));

    assertEquals(1, result.size());
    assertNotNull(result.get(0).getChildItems());
    assertTrue(result.get(0).getChildItems().isEmpty());
  }

  @Test
  void testCreateItemEntities_withEmptySet_shouldReturnEmptyList() {
    Set<OfferProductDto> emptySet = new HashSet<>();

    List<OfferProductStore> result = offerProductMapper.createItemEntities(emptySet);

    assertNotNull(result);
    assertTrue(result.isEmpty());
  }

  @Test
  void testCreateItemEntities_withMultipleDtos_shouldMapAll() {
    OfferProductDto dto1 = createMinimalOfferProductDto("omni-1", "11111");
    OfferProductDto dto2 = createMinimalOfferProductDto("omni-2", "22222");
    OfferProductDto dto3 = createMinimalOfferProductDto("omni-3", "33333");

    Set<OfferProductDto> dtoSet = Set.of(dto1, dto2, dto3);

    List<OfferProductStore> result = offerProductMapper.createItemEntities(dtoSet);

    assertEquals(3, result.size());
  }

  @Test
  void testCreateItemEntities_withNullFields_shouldMapToNull() {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId(null);
    dto.setItemNumber(null);
    dto.setModelId(null);
    dto.setVendorNumber(null);
    dto.setMerchBucketIds(List.of());
    dto.setDigitalTaxonomyIds(List.of());
    dto.setChildItems(List.of());

    List<OfferProductStore> result = offerProductMapper.createItemEntities(Set.of(dto));

    assertEquals(1, result.size());
    OfferProductStore entity = result.get(0);
    assertNull(entity.getOmniItemId());
    assertNull(entity.getItemNumber());
    assertNull(entity.getModelId());
    assertNull(entity.getVendorNumber());
  }

  @Test
  void testCreateItemEntities_generatesIdWithItemNumberOnly_whenModelAndVendorNull() {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId("omni-123");
    dto.setItemNumber("12345");
    dto.setModelId(null);
    dto.setVendorNumber(null);
    dto.setMerchBucketIds(List.of());
    dto.setDigitalTaxonomyIds(List.of());
    dto.setChildItems(List.of());

    List<OfferProductStore> result = offerProductMapper.createItemEntities(Set.of(dto));

    assertEquals(1, result.size());
    assertEquals("12345", result.get(0).getId());
  }

  @Test
  void testCreateItemEntities_generatesCompositeId_whenModelAndVendorPresent() {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId("omni-123");
    dto.setItemNumber("12345");
    dto.setModelId("model-001");
    dto.setVendorNumber("vendor-001");
    dto.setMerchBucketIds(List.of());
    dto.setDigitalTaxonomyIds(List.of());
    dto.setChildItems(List.of());

    List<OfferProductStore> result = offerProductMapper.createItemEntities(Set.of(dto));

    assertEquals(1, result.size());
    assertEquals("12345_vendor-001_model-001", result.get(0).getId());
  }

  @Test
  void testCreateItemEntities_setsIndexedTimestamp() {
    OfferProductDto dto = createMinimalOfferProductDto("omni-123", "12345");

    List<OfferProductStore> result = offerProductMapper.createItemEntities(Set.of(dto));

    assertEquals(1, result.size());
    assertNotNull(result.get(0).getIndexedTs());
  }

  @Test
  void testCreateItemEntities_withNullInMerchBucketIds_shouldHandleGracefully() {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId("omni-123");
    dto.setItemNumber("12345");
    dto.setMerchBucketIds(List.of("mb-001"));
    dto.setDigitalTaxonomyIds(List.of("dt-001"));
    dto.setChildItems(List.of());

    List<OfferProductStore> result = offerProductMapper.createItemEntities(Set.of(dto));

    assertEquals(1, result.size());
    assertNotNull(result.get(0).getMerchBucketIds());
  }

  private OfferProductDto createFullOfferProductDto() {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId("omni-123");
    dto.setItemNumber("12345");
    dto.setModelId("model-001");
    dto.setVendorNumber("vendor-001");
    dto.setProductType("ITEM");
    dto.setAssortmentId("assort-001");
    dto.setProductGroupId("pg-001");
    dto.setSubdivisionId("subdiv-001");
    dto.setDivisionId("div-001");
    dto.setBusinessAreaId("ba-001");
    dto.setBrandId("brand-001");
    dto.setProgramType("STOCK");
    dto.setIsPublished("true");
    dto.setIsBuyable("true");
    dto.setProductStatus(true);
    dto.setStatus("ACTIVE");
    dto.setMerchBucketIds(List.of("mb-001", "mb-002"));
    dto.setDigitalTaxonomyIds(List.of("dt-001", "dt-002"));
    dto.setChildItems(List.of());
    return dto;
  }

  private OfferProductDto createMinimalOfferProductDto(String omniItemId, String itemNumber) {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId(omniItemId);
    dto.setItemNumber(itemNumber);
    dto.setMerchBucketIds(List.of());
    dto.setDigitalTaxonomyIds(List.of());
    dto.setChildItems(List.of());
    return dto;
  }
}
