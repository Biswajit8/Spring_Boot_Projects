package controller;/*
package controller;

import com.lowes.promotionstore.component.ForecastDataMapper;
import com.lowes.promotionstore.component.MicrometerEventRegister;
import com.lowes.promotionstore.component.SpotlightPromoStoreElasticSearchDaoMapper;
import com.lowes.promotionstore.configuration.ObjectMapperConfig;
import com.lowes.promotionstore.controller.ForecastController;
import com.lowes.promotionstore.model.record.spotlight.ForecastDataDto;
import com.lowes.promotionstore.repository.dao.SpotlightPromoStoreElasticSearchDao;
import com.lowes.promotionstore.service.ForecastService;
import com.lowes.promotionstore.service.SpotlightPromotionStoreService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.springframework.http.ResponseEntity;
import util.TestUtil;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ForecastControllerTest {

  private SpotlightPromotionStoreService spotlightPromotionStoreService;
  private ForecastService forecastService;
  private ForecastController forecastController;
  private TestUtil testUtil;
  private ForecastDataMapper forecastDataMapper;

  private SpotlightPromoStoreElasticSearchDaoMapper spotlightPromoStoreElasticSearchDaoMapper;
  private ObjectMapperConfig objectMapperConfig;

  @Mock
  private SpotlightPromoStoreElasticSearchDao spotlightPromoStoreElasticSearchDao;

  @Mock
  private MicrometerEventRegister registryService;

  @BeforeEach
  void setUp() {
    spotlightPromoStoreElasticSearchDaoMapper = mock(
        SpotlightPromoStoreElasticSearchDaoMapper.class);
    forecastDataMapper = new ForecastDataMapper(objectMapperConfig);
    forecastService = new ForecastService(forecastDataMapper, spotlightPromoStoreElasticSearchDao,
        spotlightPromoStoreElasticSearchDaoMapper, registryService);
    spotlightPromotionStoreService = mock(SpotlightPromotionStoreService.class);
    forecastController = new ForecastController(forecastService);
    testUtil = new TestUtil();
  }

  @Test
  void testSaveForecastData_ReturnsOk() {
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();

    when(forecastService.saveForecastData(forecastDataDto)).thenReturn(
        forecastDataDto.promotionId());

    ResponseEntity<String> response = forecastController.mergeForecastData(forecastDataDto);

    verify(forecastService, times(1)).saveForecastData(forecastDataDto);
    assertEquals(200, response.getStatusCode().value());
  }

  @Test*/
/**//*

  void testSaveForecastData_ReturnsBadRequest() {
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();

    when(forecastService.saveForecastData(forecastDataDto)).thenReturn("");

    ResponseEntity<String> response = forecastController.mergeForecastData(forecastDataDto);

    verify(forecastService, times(1)).saveForecastData(forecastDataDto);
    assertEquals(400, response.getStatusCode().value());
  }

  @Test
  void testSaveForecastData_Exception() {
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();

    doThrow(new RuntimeException("Exception") {
    })
        .when(forecastService).saveForecastData(forecastDataDto);

    assertThrows(RuntimeException.class,
        () -> forecastController.mergeForecastData(forecastDataDto));
  }
}*/
