package controller;

import com.lowes.promotionstore.configuration.KafkaConsumerToggleConfig;
import com.lowes.promotionstore.controller.ToggleKafkaConsumerController;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ToggleKafkaConsumerControllerUnitTest {

  @Mock
  private KafkaConsumerToggleConfig kafkaConsumerToggleConfig;

  @InjectMocks
  private ToggleKafkaConsumerController controller;

  @Test
  void shouldToggleAdapterConsumer_WhenInitiallyDisabled() {
    when(kafkaConsumerToggleConfig.isEnableAdapterConsumer()).thenReturn(false).thenReturn(true);
    ResponseEntity<Boolean> response = controller.toggleAdapterConsumer();
    verify(kafkaConsumerToggleConfig).setEnableAdapterConsumer(true);
    assertEquals(true, response.getBody(), "Expected adapter consumer to be enabled after toggle");
  }


  @Test
  void testToggleFullLoadConsumer() {
    when(kafkaConsumerToggleConfig.isEnableFullLoadConsumer()).thenReturn(true).thenReturn(false);

    ResponseEntity<Boolean> response = controller.toggleFullLoadConsumer();

    verify(kafkaConsumerToggleConfig).setEnableFullLoadConsumer(false);
    assertEquals(false, response.getBody());
  }

  @Test
  void shouldReturnToggleStatusWithCorrectFlagsAndStatusCode() {
    when(kafkaConsumerToggleConfig.isEnableAdapterConsumer()).thenReturn(true);
    when(kafkaConsumerToggleConfig.isEnableFullLoadConsumer()).thenReturn(false);
    ResponseEntity<Map<String, Boolean>> response = controller.getToggleStatus();
    assertNotNull(response, "Response should not be null");
    assertEquals(HttpStatus.OK, response.getStatusCode(), "Expected HTTP status 200 OK");
    Map<String, Boolean> body = response.getBody();
    assertNotNull(body, "Response body should not be null");
    assertTrue(body.get("Spotlight Event Consumer"), "Expected 'Adapter Consumer' to be true");
    assertFalse(body.get("Full Load Consumer"), "Expected 'Full Load Consumer' to be false");
  }

}
