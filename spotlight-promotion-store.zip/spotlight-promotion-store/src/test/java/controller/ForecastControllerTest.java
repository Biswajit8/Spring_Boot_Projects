/*
package controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowes.promotionstore.component.ForecastDataMapper;
import com.lowes.promotionstore.component.MicrometerEventRegister;
import com.lowes.promotionstore.component.PartialMapBuilders;
import com.lowes.promotionstore.configuration.ObjectMapperConfig;
import com.lowes.promotionstore.controller.ForecastController;
import com.lowes.promotionstore.model.record.spotlight.ForecastDataDto;
import com.lowes.promotionstore.repository.dao.SpotlightPromoStoreElasticSearchDao;
import com.lowes.promotionstore.service.ForecastService;
import com.lowes.promotionstore.service.SpotlightPromotionStoreService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;
import util.TestUtil;

import java.util.HashMap;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.RETURNS_SELF;
import static org.mockito.Mockito.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ForecastControllerTest {

  private SpotlightPromotionStoreService spotlightPromotionStoreService;
  private ForecastService forecastService;
  private ForecastController forecastController;
  private TestUtil testUtil;
  private ForecastDataMapper forecastDataMapper;

  private PartialMapBuilders partialMapBuilders;
  private ObjectMapperConfig objectMapperConfig;

  @Mock
  private SpotlightPromoStoreElasticSearchDao spotlightPromoStoreElasticSearchDao;

  @Mock
  private MicrometerEventRegister registryService;

  @BeforeEach
  void setUp() {
    objectMapperConfig = mock(ObjectMapperConfig.class);
    when(objectMapperConfig.objectMapper()).thenReturn(new ObjectMapper());
    
    // Mock PartialMapBuilders and its Builder
    partialMapBuilders = mock(PartialMapBuilders.class);
    PartialMapBuilders.Builder<?> builder = mock(PartialMapBuilders.Builder.class, RETURNS_SELF);
    when(partialMapBuilders.from(any())).thenReturn((PartialMapBuilders.Builder)builder);
    when(builder.build()).thenReturn(new HashMap<>());
    
    // Mock void method for registry service
    doNothing().when(registryService).incrementCounter(any());
    
    forecastDataMapper = new ForecastDataMapper(objectMapperConfig);
    forecastService = new ForecastService(forecastDataMapper, spotlightPromoStoreElasticSearchDao,
        partialMapBuilders, registryService);
    spotlightPromotionStoreService = mock(SpotlightPromotionStoreService.class);
    forecastController = new ForecastController(forecastService);
    testUtil = new TestUtil();
  }

  @Test
  void testSaveForecastData_ReturnsOk() {
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();

    when(forecastService.saveForecastData(forecastDataDto)).thenReturn(
        forecastDataDto.promotionId());

    ResponseEntity<String> response = forecastController.mergeForecastData(forecastDataDto);

    verify(forecastService, times(1)).saveForecastData(forecastDataDto);
    assertEquals(200, response.getStatusCode().value());
  }

  @Test
  void testSaveForecastData_ReturnsBadRequest() {
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();

    when(forecastService.saveForecastData(forecastDataDto)).thenReturn("");

    ResponseEntity<String> response = forecastController.mergeForecastData(forecastDataDto);

    verify(forecastService, times(1)).saveForecastData(forecastDataDto);
    assertEquals(400, response.getStatusCode().value());
  }

  @Test
  void testSaveForecastData_Exception() {
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();

    doThrow(new RuntimeException("Exception") {
    })
        .when(forecastService).saveForecastData(forecastDataDto);

    assertThrows(RuntimeException.class,
        () -> forecastController.mergeForecastData(forecastDataDto));
  }
}
*/
