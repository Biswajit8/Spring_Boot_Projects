package controller;/*
package controller;

import com.lowes.promotionstore.controller.OfferSalesMetricsController;
import com.lowes.promotionstore.model.record.spotlight.OfferSalesPayloadDto;
import com.lowes.promotionstore.service.OfferSalesMatrixService;
import com.lowes.promotionstore.service.SpotlightPromotionStoreService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;
import util.TestUtil;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class OfferSalesMetricsControllerTest {


  private SpotlightPromotionStoreService spotlightPromotionStoreService;
  private OfferSalesMetricsController offerSalesMetricsController;
  private OfferSalesMatrixService offerSalesMatrixService;
  private TestUtil testUtil;

  @BeforeEach
  void setUp() {
    spotlightPromotionStoreService = mock(SpotlightPromotionStoreService.class);
    offerSalesMetricsController = new OfferSalesMetricsController(offerSalesMatrixService);
    testUtil = new TestUtil();
  }

  @Test
  void testMergeOfferSalesData_ReturnsOk() {
    OfferSalesPayloadDto offerSalesDto = testUtil.mockOfferSalesDto();
    String expectedId = "12345";

    when(offerSalesMatrixService.saveOfferSalesMetrics(offerSalesDto)).thenReturn(
        expectedId);

    ResponseEntity<String> response = offerSalesMetricsController.mergeOfferSalesData(
        offerSalesDto);

    verify(offerSalesMatrixService, times(1)).saveOfferSalesMetrics(offerSalesDto);
    assertEquals(200, response.getStatusCode().value());
    assertEquals(expectedId, response.getBody());
  }

  @Test
  void testMergeOfferSalesData_ReturnsBadRequest_WhenEmptyId() {
    OfferSalesPayloadDto offerSalesDto = testUtil.mockOfferSalesDto();

    when(offerSalesMatrixService.saveOfferSalesMetrics(offerSalesDto)).thenReturn("");

    ResponseEntity<String> response = offerSalesMetricsController.mergeOfferSalesData(
        offerSalesDto);

    verify(offerSalesMatrixService, times(1)).saveOfferSalesMetrics(offerSalesDto);
    assertEquals(400, response.getStatusCode().value());
    assertNull(response.getBody());
  }

  @Test
  void testMergeOfferSalesData_Exception() {
    OfferSalesPayloadDto offerSalesDto = testUtil.mockOfferSalesDto();

    doThrow(new RuntimeException("Exception"))
        .when(offerSalesMatrixService).saveOfferSalesMetrics(offerSalesDto);

    assertThrows(RuntimeException.class,
        () -> offerSalesMetricsController.mergeOfferSalesData(offerSalesDto));

    verify(offerSalesMatrixService, times(1)).saveOfferSalesMetrics(offerSalesDto);
  }
}*/
