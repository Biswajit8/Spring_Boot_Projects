package listener;

import com.lowes.promotionstore.component.OfferEventMapper;
import com.lowes.promotionstore.configuration.KafkaConsumerToggleConfig;
import com.lowes.promotionstore.listener.SpotlightOfferEventsListener;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import com.lowes.promotionstore.service.SpotlightPromotionStoreService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.TopicPartition;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.support.Acknowledgment;
import util.TestUtil;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.List;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.atLeastOnce;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class KafkaConsumerServiceTest {

  private TestUtil testUtil;

  private SpotlightOfferEventsListener kafkaConsumerService;

  @Mock
  private SpotlightPromotionStoreService spotlightPromotionStoreService;

  @Mock
  private KafkaConsumerToggleConfig kafkaConsumerToggleConfig;

  @Mock
  private OfferEventMapper offerEventMapper;

  private ConsumerRecords<String, SpotlightOfferPayloadDto> consumerRecords;

  private List<SpotlightOfferPayloadDto> records;

  private ConsumerRecord<String, SpotlightOfferPayloadDto> record;

  private Acknowledgment acknowledgment;

  @BeforeEach
  void setUp() throws URISyntaxException, IOException {
    offerEventMapper = new OfferEventMapper();
    testUtil = new TestUtil();
    kafkaConsumerService = new SpotlightOfferEventsListener(kafkaConsumerToggleConfig,
        spotlightPromotionStoreService);
    String spotlightMockPromotion = testUtil.readFromFile(
        "mocks/offertypeid_3/test1/spotlight.json");
    String spotlightMockOfferProduct = testUtil.readFromFile(
        "mocks/offerproduct_1/test/offerproduct.json");
    SpotlightOfferPayloadDto spotlightOfferDto = testUtil.parseStringToSpotlightOfferDto(
        spotlightMockPromotion);
    TopicPartition topicPartition = new TopicPartition("testTopic", 1);

// K = String (key), V = SpotlightOfferPayloadDto (value)
    record =
        new ConsumerRecord<>("testTopic", 1, 1L, "key", spotlightOfferDto);
    records = List.of(spotlightOfferDto);
    java.util.Map<TopicPartition, List<ConsumerRecord<String, SpotlightOfferPayloadDto>>> map =
        java.util.Collections.singletonMap(
            topicPartition,
            java.util.Collections.singletonList(record)
        );

    consumerRecords = new ConsumerRecords<>(map);
  }

  @Test
  void testConsumeWhenConsumerIsEnabled() {
    when(kafkaConsumerToggleConfig.isEnableAdapterConsumer()).thenReturn(true);
    kafkaConsumerService.onSpotlight(consumerRecords, acknowledgment);
    verify(spotlightPromotionStoreService).process(records, record.topic());
    verify(kafkaConsumerToggleConfig).isEnableAdapterConsumer();
  }

  @Test
  void testConsumeWhenConsumerIsDisabled() {
    when(kafkaConsumerToggleConfig.isEnableAdapterConsumer()).thenReturn(false);
    kafkaConsumerService.onSpotlight(consumerRecords, acknowledgment);
    verify(spotlightPromotionStoreService, never()).process(anyList(), anyString());
    verify(kafkaConsumerToggleConfig).isEnableAdapterConsumer();
  }

  @Test
  void testPromotionFullLoadListenerWhenConsumerIsEnabled() {
    when(kafkaConsumerToggleConfig.isEnableFullLoadConsumer()).thenReturn(true);
    kafkaConsumerService.onFullLoad(consumerRecords, acknowledgment);
    verify(spotlightPromotionStoreService).process(records, record.topic());
    verify(kafkaConsumerToggleConfig, atLeastOnce()).isEnableFullLoadConsumer();
  }

  @Test
  void testPromotionFullLoadListenerWhenConsumerIsDisabled() {
    when(kafkaConsumerToggleConfig.isEnableFullLoadConsumer()).thenReturn(false);
    kafkaConsumerService.onFullLoad(consumerRecords, acknowledgment);
    verify(spotlightPromotionStoreService, never()).process(anyList(), anyString());
    verify(kafkaConsumerToggleConfig, atLeastOnce()).isEnableFullLoadConsumer();
  }
}
