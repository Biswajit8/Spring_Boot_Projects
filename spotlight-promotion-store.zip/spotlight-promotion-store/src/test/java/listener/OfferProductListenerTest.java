package listener;

import com.lowes.model.generated.OfferProductDto;
import com.lowes.promotionstore.listener.OfferProductListener;
import com.lowes.promotionstore.service.OfferProductStoreService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.kafka.support.Acknowledgment;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.lowes.promotionstore.constants.ApplicationConstants.FULL_LOAD_TYPE;
import static com.lowes.promotionstore.constants.ApplicationConstants.MESSAGE_TYPE;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class OfferProductListenerTest {

  private OfferProductListener offerProductListener;

  @Mock
  private OfferProductStoreService offerProductStoreService;

  @Mock
  private Acknowledgment acknowledgment;

  private static final String TEST_TOPIC = "test-offer-product-topic";
  private static final int TEST_PARTITION = 0;

  @BeforeEach
  void setUp() {
    offerProductListener = new OfferProductListener(offerProductStoreService);
  }

  @Test
  void testOfferProductListener_withValidRecords_shouldProcessAndAcknowledge() {
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecords(
        createOfferProductDto("item-123", "12345"));

    doNothing().when(offerProductStoreService).process(any(), eq(TEST_TOPIC));

    offerProductListener.offerProductListener(consumerRecords, acknowledgment);

    verify(offerProductStoreService).process(consumerRecords, TEST_TOPIC);
    verify(acknowledgment).acknowledge();
  }

  @Test
  void testOfferProductListener_withMultipleRecords_shouldProcessAllAndAcknowledge() {
    OfferProductDto dto1 = createOfferProductDto("item-1", "11111");
    OfferProductDto dto2 = createOfferProductDto("item-2", "22222");

    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecordsWithMultiple(
        List.of(dto1, dto2));

    doNothing().when(offerProductStoreService).process(any(), eq(TEST_TOPIC));

    offerProductListener.offerProductListener(consumerRecords, acknowledgment);

    verify(offerProductStoreService).process(consumerRecords, TEST_TOPIC);
    verify(acknowledgment).acknowledge();
  }

  @Test
  void testOfferProductListener_withEmptyRecords_shouldStillAcknowledge() {
    ConsumerRecords<String, OfferProductDto> emptyRecords = new ConsumerRecords<>(
        Collections.emptyMap());

    offerProductListener.offerProductListener(emptyRecords, acknowledgment);

    verify(offerProductStoreService).process(emptyRecords, "unknown");
    verify(acknowledgment).acknowledge();
  }

  @Test
  void testOfferProductListener_whenServiceThrowsException_shouldCatchAndAcknowledge() {
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecords(
        createOfferProductDto("item-123", "12345"));

    doThrow(new RuntimeException("Processing error"))
        .when(offerProductStoreService).process(any(), eq(TEST_TOPIC));

    offerProductListener.offerProductListener(consumerRecords, acknowledgment);

    verify(offerProductStoreService).process(consumerRecords, TEST_TOPIC);
    verify(acknowledgment).acknowledge();
  }

  @Test
  void testOfferProductListener_withFullLoadRecord_shouldProcessAndAcknowledge() {
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecordsWithFullLoadHeader(
        createOfferProductDto("item-full", "99999"));

    doNothing().when(offerProductStoreService).process(any(), eq(TEST_TOPIC));

    offerProductListener.offerProductListener(consumerRecords, acknowledgment);

    verify(offerProductStoreService).process(consumerRecords, TEST_TOPIC);
    verify(acknowledgment).acknowledge();
  }

  @Test
  void testOfferProductListener_withNullPointerException_shouldCatchAndAcknowledge() {
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecords(
        createOfferProductDto("item-123", "12345"));

    doThrow(new NullPointerException("Null value encountered"))
        .when(offerProductStoreService).process(any(), eq(TEST_TOPIC));

    offerProductListener.offerProductListener(consumerRecords, acknowledgment);

    verify(acknowledgment).acknowledge();
  }

  @Test
  void testOfferProductListener_withIllegalArgumentException_shouldCatchAndAcknowledge() {
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecords(
        createOfferProductDto("item-123", "12345"));

    doThrow(new IllegalArgumentException("Invalid argument"))
        .when(offerProductStoreService).process(any(), eq(TEST_TOPIC));

    offerProductListener.offerProductListener(consumerRecords, acknowledgment);

    verify(acknowledgment).acknowledge();
  }

  @Test
  void testOfferProductListener_topicExtraction_withMultiplePartitions() {
    TopicPartition partition1 = new TopicPartition(TEST_TOPIC, 0);
    TopicPartition partition2 = new TopicPartition(TEST_TOPIC, 1);

    OfferProductDto dto1 = createOfferProductDto("item-1", "11111");
    OfferProductDto dto2 = createOfferProductDto("item-2", "22222");

    ConsumerRecord<String, OfferProductDto> record1 = new ConsumerRecord<>(
        TEST_TOPIC, 0, 0L, "key1", dto1);
    ConsumerRecord<String, OfferProductDto> record2 = new ConsumerRecord<>(
        TEST_TOPIC, 1, 0L, "key2", dto2);

    Map<TopicPartition, List<ConsumerRecord<String, OfferProductDto>>> recordsMap = new HashMap<>();
    recordsMap.put(partition1, List.of(record1));
    recordsMap.put(partition2, List.of(record2));

    ConsumerRecords<String, OfferProductDto> consumerRecords = new ConsumerRecords<>(recordsMap);

    doNothing().when(offerProductStoreService).process(any(), eq(TEST_TOPIC));

    offerProductListener.offerProductListener(consumerRecords, acknowledgment);

    verify(offerProductStoreService).process(consumerRecords, TEST_TOPIC);
    verify(acknowledgment).acknowledge();
  }

  private OfferProductDto createOfferProductDto(String omniItemId, String itemNumber) {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId(omniItemId);
    dto.setItemNumber(itemNumber);
    dto.setVendorNumber("vendor-001");
    dto.setModelId("model-001");
    dto.setProductType("ITEM");
    dto.setAssortmentId("assort-001");
    dto.setProductGroupId("pg-001");
    dto.setSubdivisionId("subdiv-001");
    dto.setDivisionId("div-001");
    dto.setBusinessAreaId("ba-001");
    dto.setBrandId("brand-001");
    dto.setProgramType("STOCK");
    dto.setIsPublished("true");
    dto.setIsBuyable("true");
    dto.setProductStatus(true);
    dto.setStatus("ACTIVE");
    dto.setMerchBucketIds(List.of("mb-001", "mb-002"));
    dto.setDigitalTaxonomyIds(List.of("dt-001", "dt-002"));
    dto.setChildItems(List.of());
    return dto;
  }

  private ConsumerRecords<String, OfferProductDto> createConsumerRecords(OfferProductDto dto) {
    TopicPartition topicPartition = new TopicPartition(TEST_TOPIC, TEST_PARTITION);
    ConsumerRecord<String, OfferProductDto> record = new ConsumerRecord<>(
        TEST_TOPIC, TEST_PARTITION, 0L, "key", dto);

    Map<TopicPartition, List<ConsumerRecord<String, OfferProductDto>>> recordsMap =
        Collections.singletonMap(topicPartition, Collections.singletonList(record));

    return new ConsumerRecords<>(recordsMap);
  }

  private ConsumerRecords<String, OfferProductDto> createConsumerRecordsWithMultiple(
      List<OfferProductDto> dtos) {
    TopicPartition topicPartition = new TopicPartition(TEST_TOPIC, TEST_PARTITION);

    List<ConsumerRecord<String, OfferProductDto>> records = dtos.stream()
        .map(dto -> new ConsumerRecord<String, OfferProductDto>(
            TEST_TOPIC, TEST_PARTITION, 0L, "key-" + dto.getOmniItemId(), dto))
        .toList();

    Map<TopicPartition, List<ConsumerRecord<String, OfferProductDto>>> recordsMap =
        Collections.singletonMap(topicPartition, records);

    return new ConsumerRecords<>(recordsMap);
  }

  private ConsumerRecords<String, OfferProductDto> createConsumerRecordsWithFullLoadHeader(
      OfferProductDto dto) {
    TopicPartition topicPartition = new TopicPartition(TEST_TOPIC, TEST_PARTITION);

    RecordHeaders headers = new RecordHeaders();
    headers.add(new RecordHeader(MESSAGE_TYPE, FULL_LOAD_TYPE.getBytes()));

    ConsumerRecord<String, OfferProductDto> record = new ConsumerRecord<>(
        TEST_TOPIC, TEST_PARTITION, 0L, 0L, null, 0, 0, "key", dto, headers, java.util.Optional.empty());

    Map<TopicPartition, List<ConsumerRecord<String, OfferProductDto>>> recordsMap =
        Collections.singletonMap(topicPartition, Collections.singletonList(record));

    return new ConsumerRecords<>(recordsMap);
  }
}
