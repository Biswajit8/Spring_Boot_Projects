package util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.lowes.generated.model.offerevent.DiscountTypeEnum;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.model.coredata.uploaditems.RowDetailsPayloadDto;
import com.lowes.promotionstore.model.coredata.uploaditems.UploadFileDtoPayloadDto;
import com.lowes.promotionstore.model.coredata.validationresponse.ProgramTypeEnum;
import com.lowes.promotionstore.model.coredata.validationresponse.ValidatedItemResponse;
import com.lowes.promotionstore.model.coredata.validationresponse.ValidationResponse;
import com.lowes.promotionstore.model.coredata.validationresponse.ValidationStatus;
import com.lowes.promotionstore.model.record.spotlight.ForecastDataDto;
import com.lowes.promotionstore.model.record.spotlight.OfferGroupDetailsPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.OfferIntegrationCompatibilityPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.OfferSalesPayloadDto;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

import static com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.MarketScopeEnum.OMNI;
import static com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.RedemptionTypeEnum.INSTANT;
import static com.lowes.promotionstore.model.record.spotlight.enums.PromotionPayloadEnums.StatusEnum.COMPLETE;

public class TestUtil {

  public String readFromFile(String requestPath) throws URISyntaxException, IOException {
    Path filePath =
        Paths.get(Objects.requireNonNull(Objects.requireNonNull(getClass().getClassLoader())
            .getResource(requestPath)).toURI());
    return Files.readString(filePath);
  }

  public SpotlightOfferPayloadDto parseStringToSpotlightOfferDto(String message)
      throws JsonProcessingException {
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    objectMapper.registerModule(new JavaTimeModule());
    return objectMapper.readValue(message, SpotlightOfferPayloadDto.class);
  }


  public PromotionStore createPromotionStoreObject() {
    PromotionStore promotionStore = new PromotionStore();
    promotionStore.setActive(true);
    promotionStore.setStores(Set.of(1633, 1234));
    promotionStore.setCreatedBy("test");
    promotionStore.setModifiedBy("test");
    promotionStore.setDeactivatedBy("test");
    promotionStore.setIncludeAllStores(false);
    promotionStore.setId("100005675");
    return promotionStore;
  }

  public UploadFileDtoPayloadDto createUploadFileObjectAllStores() {
    UploadFileDtoPayloadDto uploadFileDto = new UploadFileDtoPayloadDto();
    uploadFileDto.setFileName("test");
    uploadFileDto.setErrors(List.of());
    uploadFileDto.setSuccess(
        List.of(
            new RowDetailsPayloadDto("1", "2742226", "1X4-8 TRIM CHARRED WOOD 2PK", "10", "",
                "success", "",
                ""),
            new RowDetailsPayloadDto("2", "2742225", "1X6-8 SHIPLAP CHARRED WOOD 4PK", "20", "",
                "errors", "",
                "")));
    return uploadFileDto;
  }


  public ValidationResponse createAsyncUploadFileObjectAllStores() {

    ValidatedItemResponse validatedItemResponse1 = new ValidatedItemResponse();
    ValidatedItemResponse validatedItemResponse2 = new ValidatedItemResponse();
    validatedItemResponse2.setRowId("2");
    validatedItemResponse2.setItemNumber("2742225");
    validatedItemResponse2.setItemDescription("1X6-8 SHIPLAP CHARRED WOOD 4PK");
    validatedItemResponse2.setLocations("");
    validatedItemResponse2.setDiscountType(DiscountTypeEnum.FIXED_PRICE);
    validatedItemResponse2.setDiscountValue(new BigDecimal(20));
    validatedItemResponse2.setOfferPrice("20");

    validatedItemResponse1.setRowId("1");
    validatedItemResponse1.setItemNumber("2742226");
    validatedItemResponse1.setItemDescription("1X4-8 TRIM CHARRED WOOD 2PK");
    validatedItemResponse1.setLocations("");
    validatedItemResponse1.setDiscountType(DiscountTypeEnum.FIXED_PRICE);
    validatedItemResponse1.setDiscountValue(new BigDecimal(10));
    validatedItemResponse1.setOfferPrice("10");
    List<ValidatedItemResponse> validatedItemResponses = new LinkedList<>();
    validatedItemResponses.add(validatedItemResponse1);
    validatedItemResponses.add(validatedItemResponse2);
    ValidationResponse validationResponse = new ValidationResponse(
        "0596efb2-6acc-41c7-8828-78250cbca430", "100000006195",
        ValidationStatus.SUCCESS, ProgramTypeEnum.STOCK, 1, 1, 0, validatedItemResponses,
        new ArrayList<>(), "", 0);
    return validationResponse;
  }


  public ValidationResponse createAsyncUploadFileObjectPathcesOnly() {

    ValidatedItemResponse validatedItemResponse1 = new ValidatedItemResponse();
    ValidatedItemResponse validatedItemResponse2 = new ValidatedItemResponse();
    validatedItemResponse2.setRowId("2");
    validatedItemResponse2.setItemNumber("2742225");
    validatedItemResponse2.setItemDescription("1X6-8 SHIPLAP CHARRED WOOD 4PK");
    validatedItemResponse2.setLocations("KP");
    validatedItemResponse2.setDiscountType(DiscountTypeEnum.FIXED_PRICE);
    validatedItemResponse2.setDiscountValue(new BigDecimal(20));
    validatedItemResponse2.setOfferPrice("20");

    validatedItemResponse1.setRowId("1");
    validatedItemResponse1.setItemNumber("2742226");
    validatedItemResponse1.setItemDescription("1X4-8 TRIM CHARRED WOOD 2PK");
    validatedItemResponse1.setLocations("LL, FC");
    validatedItemResponse1.setDiscountType(DiscountTypeEnum.FIXED_PRICE);
    validatedItemResponse1.setDiscountValue(new BigDecimal(10));
    validatedItemResponse1.setOfferPrice("10");
    List<ValidatedItemResponse> validatedItemResponses = new LinkedList<>();
    validatedItemResponses.add(validatedItemResponse1);
    validatedItemResponses.add(validatedItemResponse2);
    ValidationResponse validationResponse = new ValidationResponse(
        "0596efb2-6acc-41c7-8828-78250cbca430", "100000006195",
        ValidationStatus.SUCCESS, ProgramTypeEnum.STOCK, 1, 1, 0, validatedItemResponses,
        new ArrayList<>(), "", 0);
    return validationResponse;
  }


  public ValidationResponse createAsyncUploadFileObjectPatchAllStores() {

    ValidatedItemResponse validatedItemResponse1 = new ValidatedItemResponse();
    ValidatedItemResponse validatedItemResponse2 = new ValidatedItemResponse();
    validatedItemResponse2.setRowId("2");
    validatedItemResponse2.setItemNumber("2742225");
    validatedItemResponse2.setItemDescription("1X6-8 SHIPLAP CHARRED WOOD 4PK");
    validatedItemResponse2.setLocations("LL, FC");
    validatedItemResponse2.setDiscountType(DiscountTypeEnum.FIXED_PRICE);
    validatedItemResponse2.setDiscountValue(new BigDecimal(20));
    validatedItemResponse2.setOfferPrice("20");

    validatedItemResponse1.setRowId("1");
    validatedItemResponse1.setItemNumber("2742226");
    validatedItemResponse1.setItemDescription("1X4-8 TRIM CHARRED WOOD 2PK");
    validatedItemResponse1.setLocations("");
    validatedItemResponse1.setDiscountType(DiscountTypeEnum.FIXED_PRICE);
    validatedItemResponse1.setDiscountValue(new BigDecimal(10));
    validatedItemResponse1.setOfferPrice("10");
    List<ValidatedItemResponse> validatedItemResponses = new LinkedList<>();
    validatedItemResponses.add(validatedItemResponse1);
    validatedItemResponses.add(validatedItemResponse2);
    ValidationResponse validationResponse = new ValidationResponse(
        "0596efb2-6acc-41c7-8828-78250cbca430", "100000006195",
        ValidationStatus.SUCCESS, ProgramTypeEnum.STOCK, 1, 1, 0, validatedItemResponses,
        new ArrayList<>(), "", 0);
    return validationResponse;
  }

  public ValidationResponse createAsyncUploadFileObjectStores() {

    ValidatedItemResponse validatedItemResponse1 = new ValidatedItemResponse();
    ValidatedItemResponse validatedItemResponse2 = new ValidatedItemResponse();
    validatedItemResponse2.setRowId("2");
    validatedItemResponse2.setItemNumber("2742225");
    validatedItemResponse2.setItemDescription("1X6-8 SHIPLAP CHARRED WOOD 4PK");
    validatedItemResponse2.setLocations("5388, 4388, 1539");
    validatedItemResponse2.setDiscountType(DiscountTypeEnum.FIXED_PRICE);
    validatedItemResponse2.setDiscountValue(new BigDecimal(20));
    validatedItemResponse2.setOfferPrice("20");

    validatedItemResponse1.setRowId("1");
    validatedItemResponse1.setItemNumber("2742226");
    validatedItemResponse1.setItemDescription("1X4-8 TRIM CHARRED WOOD 2PK");
    validatedItemResponse1.setLocations("1633, 2588");
    validatedItemResponse1.setDiscountType(DiscountTypeEnum.FIXED_PRICE);
    validatedItemResponse1.setDiscountValue(new BigDecimal(10));
    validatedItemResponse1.setOfferPrice("10");
    List<ValidatedItemResponse> validatedItemResponses = new LinkedList<>();
    validatedItemResponses.add(validatedItemResponse1);
    validatedItemResponses.add(validatedItemResponse2);
    ValidationResponse validationResponse = new ValidationResponse(
        "0596efb2-6acc-41c7-8828-78250cbca430", "100000006195",
        ValidationStatus.SUCCESS, ProgramTypeEnum.STOCK, 1, 1, 0, validatedItemResponses,
        new ArrayList<>(), "", 0);
    return validationResponse;
  }

  public ValidationResponse createAsyncUploadFileObjectPatchStores() {

    ValidatedItemResponse validatedItemResponse1 = new ValidatedItemResponse();
    ValidatedItemResponse validatedItemResponse2 = new ValidatedItemResponse();
    validatedItemResponse2.setRowId("2");
    validatedItemResponse2.setItemNumber("2742225");
    validatedItemResponse2.setItemDescription("1X6-8 SHIPLAP CHARRED WOOD 4PK");
    validatedItemResponse2.setLocations("LL, FC");
    validatedItemResponse2.setDiscountType(DiscountTypeEnum.FIXED_PRICE);
    validatedItemResponse2.setDiscountValue(new BigDecimal(20));
    validatedItemResponse2.setOfferPrice("20");

    validatedItemResponse1.setRowId("1");
    validatedItemResponse1.setItemNumber("2742226");
    validatedItemResponse1.setItemDescription("1X4-8 TRIM CHARRED WOOD 2PK");
    validatedItemResponse1.setLocations("1633, 2588");
    validatedItemResponse1.setDiscountType(DiscountTypeEnum.FIXED_PRICE);
    validatedItemResponse1.setDiscountValue(new BigDecimal(10));
    validatedItemResponse1.setOfferPrice("10");
    List<ValidatedItemResponse> validatedItemResponses = new LinkedList<>();
    validatedItemResponses.add(validatedItemResponse1);
    validatedItemResponses.add(validatedItemResponse2);
    ValidationResponse validationResponse = new ValidationResponse(
        "0596efb2-6acc-41c7-8828-78250cbca430", "100000006195",
        ValidationStatus.SUCCESS, ProgramTypeEnum.STOCK, 1, 1, 0, validatedItemResponses,
        new ArrayList<>(), "", 0);
    return validationResponse;
  }

  public UploadFileDtoPayloadDto createUploadFileObjectPatchOnly() {
    UploadFileDtoPayloadDto uploadFileDto = new UploadFileDtoPayloadDto();
    uploadFileDto.setFileName("test");
    uploadFileDto.setErrors(List.of());
    uploadFileDto.setSuccess(
        List.of(
            new RowDetailsPayloadDto("1", "2742226", "1X4-8 TRIM CHARRED WOOD 2PK", "10", "LL,FC",
                "success",
                "", ""),
            new RowDetailsPayloadDto("2", "2742225", "1X6-8 SHIPLAP CHARRED WOOD 4PK", "20", "KP",
                "errors", "", "")));
    return uploadFileDto;
  }

  public UploadFileDtoPayloadDto createUploadFileObjectStoreOnly() {
    UploadFileDtoPayloadDto uploadFileDto = new UploadFileDtoPayloadDto();
    uploadFileDto.setFileName("test");
    uploadFileDto.setErrors(List.of());
    uploadFileDto.setSuccess(
        List.of(new RowDetailsPayloadDto("1", "2742226", "1X4-8 TRIM CHARRED WOOD 2PK", "10",
                "1633,2588",
                "success", "", ""),
            new RowDetailsPayloadDto("2", "2742225", "1X6-8 SHIPLAP CHARRED WOOD 4PK", "20",
                "1539,4388,5388",
                "errors", "", "")));
    return uploadFileDto;
  }

  public UploadFileDtoPayloadDto createUploadFileObjectStoreAndPatch() {
    UploadFileDtoPayloadDto uploadFileDto = new UploadFileDtoPayloadDto();
    uploadFileDto.setFileName("test");
    uploadFileDto.setErrors(List.of());
    uploadFileDto.setSuccess(
        List.of(new RowDetailsPayloadDto("1", "2742226", "1X4-8 TRIM CHARRED WOOD 2PK", "10",
                "1633,2588",
                "success", "", ""),
            new RowDetailsPayloadDto("2", "2742225", "1X6-8 SHIPLAP CHARRED WOOD 4PK", "20",
                "LL,FC",
                "errors", "", "")));
    return uploadFileDto;
  }

  public UploadFileDtoPayloadDto createUploadFileObjectPatchAndAllStores() {
    UploadFileDtoPayloadDto uploadFileDto = new UploadFileDtoPayloadDto();
    uploadFileDto.setFileName("test");
    uploadFileDto.setErrors(List.of());
    uploadFileDto.setSuccess(
        List.of(
            new RowDetailsPayloadDto("1", "2742226", "1X4-8 TRIM CHARRED WOOD 2PK", "10", "",
                "success", "",
                ""),
            new RowDetailsPayloadDto("2", "2742225", "1X6-8 SHIPLAP CHARRED WOOD 4PK", "20",
                "LL,FC",
                "errors", "", "")));
    return uploadFileDto;
  }

  public ForecastDataDto mockForecastDataDto() {
    return new ForecastDataDto(
        "100000057164", null, null, null, null, 233888.36,
        null, null, null, null,
        9362.46, null, null, 54000.56, 45346.74,
        BigDecimal.valueOf(7873.64), null, null, null,
        BigDecimal.valueOf(84738.56), null, null, null, null, "1B", "1B",
        BigDecimal.valueOf(35675.67), null, 7789.0, null, null, null,
        5374.0, 0.0, 1452.0, null, null,
        BigDecimal.valueOf(54747.56), BigDecimal.valueOf(34738.56), BigDecimal.valueOf(64747.56),
        35859.0, null,
        null, null, null, 21456.0, 98345.0, 3454958.0, 3456.77,
        345.46, BigDecimal.valueOf(209264.208), "High", 454.88, BigDecimal.valueOf(53516.56),
        BigDecimal.valueOf(4534.57), "2025-11-07 10:28:21.067", "2025-11-07 10:35:21.68");
  }

  public OfferSalesPayloadDto mockOfferSalesDto() {
    return new OfferSalesPayloadDto(
        100000057164L, BigDecimal.valueOf(233888.36), BigDecimal.valueOf(12345.67),
        BigDecimal.valueOf(2345.89), BigDecimal.valueOf(9876.54),
        BigDecimal.valueOf(4567.12), BigDecimal.valueOf(8765.43), BigDecimal.valueOf(9362.46),
        BigDecimal.valueOf(654.32), BigDecimal.valueOf(234.56),
        BigDecimal.valueOf(345.78), BigDecimal.valueOf(123.45), BigDecimal.valueOf(543.21),
        BigDecimal.valueOf(54000.56), BigDecimal.valueOf(45346.74),
        BigDecimal.valueOf(7873.64), BigDecimal.valueOf(84738.56), BigDecimal.valueOf(35675.67),
        BigDecimal.valueOf(7789.00), BigDecimal.valueOf(5374.00),
        BigDecimal.valueOf(1452.00), BigDecimal.valueOf(54747.56), BigDecimal.valueOf(34738.56),
        BigDecimal.valueOf(64747.56), BigDecimal.valueOf(35859.00),
        BigDecimal.valueOf(21456.00), "2025-11-07 10:28:21.064", "2025-11-07 10:35:21.065"
    );
  }

  public OfferIntegrationCompatibilityPayloadDto mockOfferIntegrationCompatibility() {
    return new OfferIntegrationCompatibilityPayloadDto(true, true, new HashSet<>());
  }

  public SpotlightOfferPayloadDto mockSpotlightOffer() {
    return new SpotlightOfferPayloadDto(
        12345L, 101L, null, "Test-Creation", "CONDITIONAL_PRODUCT_DISCOUNTS",
        "Conditional Product Discounts", "PRODUCT_DISCOUNTS", "Product Discounts", null, null, OMNI,
        null,
        null, INSTANT, null, null, COMPLETE, null, null, null, "2025-04-16 03:49:17",
        "TestAccessor", "2025-04-16 04:09:51",
        "TestAccessor", "2025-04-16 04:09:51", "TestAccessor", true, 1, 0, null, null,
        "While Supplies Last. Discount Taken at Time of Purchase. See Associate for Details.",
        "SPOTLIGHT", null, null, mockForecastDataDto(), mockOfferSalesDto(),
        new OfferGroupDetailsPayloadDto(123, "GROUP_NAME"), null, false, null, null, null, null,
        null, null, null, null, mockOfferIntegrationCompatibility(), "TAB",
        null, null, null, null, null, null, null, null, null, 0, 0, List.of());
  }
}
