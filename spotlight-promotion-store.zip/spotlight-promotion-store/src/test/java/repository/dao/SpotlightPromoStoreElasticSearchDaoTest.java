package repository.dao;

import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.repository.es.SpotlightPromoStoreRepository;
import com.lowes.promotionstore.repository.dao.SpotlightPromoStoreElasticSearchDao;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import util.TestUtil;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
class SpotlightPromoStoreElasticSearchDaoTest {

  private TestUtil testUtil;
  @Mock
  private SpotlightPromoStoreRepository spotlightPromoStoreRepository;

  @InjectMocks
  private SpotlightPromoStoreElasticSearchDao spotlightPromoStoreElasticSearchDao;

  private PromotionStore promotionStore;

  @BeforeEach
  void setUp() {
    testUtil = new TestUtil();
    promotionStore = testUtil.createPromotionStoreObject();
  }

  @Test
  void testSavePromotionStoreDocumentSuccess() {
    spotlightPromoStoreElasticSearchDao.savePromotionStoreDocument(promotionStore);
    verify(spotlightPromoStoreRepository).save(promotionStore);
  }

  @Test
  void testSavePromotionStoreDocumentNull() {
    spotlightPromoStoreElasticSearchDao.savePromotionStoreDocument(null);
    verify(spotlightPromoStoreRepository, never()).save(any());
  }

  @Test
  void testFindPromotionStoreDataByIdSuccess() {
    String promotionId="100000056723";
    spotlightPromoStoreElasticSearchDao.getPromotionStoreDataById(promotionId);
    verify(spotlightPromoStoreRepository).findById(promotionId);
  }

  @Test
  void testFindPromotionStoreDataByIdNull() {
    String promotionId=null;
    spotlightPromoStoreElasticSearchDao.getPromotionStoreDataById(null);
    verify(spotlightPromoStoreRepository, never()).findById(promotionId);
  }


}
