package service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.lowes.promotionstore.component.MicrometerEventRegister;
import com.lowes.promotionstore.component.PartialMapBuilders;
import com.lowes.promotionstore.component.SalesDataMapper;
import com.lowes.promotionstore.configuration.ObjectMapperConfig;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.model.record.spotlight.OfferSalesPayloadDto;
import com.lowes.promotionstore.repository.dao.SpotlightPromoStoreElasticSearchDao;
import com.lowes.promotionstore.service.OfferSalesMatrixService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import util.TestUtil;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

public class OfferSalesMatrixServiceTest {

  private SalesDataMapper salesDataMapper;

  private SalesDataMapper salesDataMapperMock;

  private OfferSalesMatrixService offerSalesMatrixService;

  @Mock
  private MicrometerEventRegister registryService;

  private SpotlightPromoStoreElasticSearchDao spotlightPromoStoreElasticSearchDao;

  private PartialMapBuilders PartialMapBuilders;

  private ObjectMapper objectMapper;

  private ObjectMapperConfig objectMapperConfig;

  private TestUtil testUtil;

  @BeforeEach
  void setUp() {
    objectMapper = new ObjectMapper();
    salesDataMapperMock = mock(SalesDataMapper.class);
    PartialMapBuilders = new PartialMapBuilders(objectMapperConfig);
    registryService = mock(MicrometerEventRegister.class);
    spotlightPromoStoreElasticSearchDao = mock(SpotlightPromoStoreElasticSearchDao.class);
    testUtil = new TestUtil();
    salesDataMapper = new SalesDataMapper(objectMapperConfig);
    offerSalesMatrixService = new OfferSalesMatrixService(registryService,
        spotlightPromoStoreElasticSearchDao, PartialMapBuilders,
        salesDataMapper);
  }

//  @Test
//  void testSaveOfferSalesMetrics_WhenDataExists() throws JsonProcessingException {
//    OfferSalesPayloadDto offerSalesDto = testUtil.mockOfferSalesDto();
//    String offerId = String.valueOf(offerSalesDto.offerId());
//
//    PromotionStore existingPromotion = new PromotionStore();
//    existingPromotion.setId("100000057164");
//    salesDataMapper.mapOfferSalesMetrics(existingPromotion, offerSalesDto);
//
//    PromotionStore updatedPromotion = new PromotionStore();
//    updatedPromotion.setId("100000057164");
//
//    String result = offerSalesMatrixService.saveOfferSalesMetrics(offerSalesDto);
//    existingPromotion.setId(offerId);
//
//    Set<String> eligibleFields = Arrays.stream(SalesSearchEnum.values()).map(Enum::name)
//        .collect(Collectors.toSet());
//
//    Map<String, Object> nonNullValues = spotlightPromoStoreElasticSearchDao.toPartialMapWithNonEmpty(
//        updatedPromotion, eligibleFields);
//
//    verify(spotlightPromoStoreElasticSearchDao).upsertPartial(updatedPromotion, nonNullValues);
//    assertEquals("123", result);
//  }

  @Test
  void testSaveOfferSalesMetrics_WhenDataDoesNotExist() {
    OfferSalesPayloadDto offerSalesDto = testUtil.mockOfferSalesDto();
    String offerId = String.valueOf(offerSalesDto.offerId());

    when(spotlightPromoStoreElasticSearchDao.getPromotionStoreDataById(offerId))
        .thenReturn(Optional.empty());

    String result = offerSalesMatrixService.saveOfferSalesMetrics(offerSalesDto);

    verify(spotlightPromoStoreElasticSearchDao, never())
        .savePromotionStoreDocument(any(PromotionStore.class));
    assertNull(result);
  }

  @Test
  void testSaveOfferSalesMetrics_JsonProcessingException() throws JsonProcessingException {
    OfferSalesPayloadDto offerSalesDto = testUtil.mockOfferSalesDto();
    String offerId = String.valueOf(offerSalesDto.offerId());

    PromotionStore existingPromotion = new PromotionStore();

    when(spotlightPromoStoreElasticSearchDao.getPromotionStoreDataById(offerId))
        .thenReturn(Optional.of(existingPromotion));

    doThrow(new JsonProcessingException("Exception Occurred") {
    })
        .when(salesDataMapperMock)
        .mapOfferSalesMetrics(eq(existingPromotion), eq(offerSalesDto));

    String result = offerSalesMatrixService.saveOfferSalesMetrics(offerSalesDto);

    verify(spotlightPromoStoreElasticSearchDao, never())
        .savePromotionStoreDocument(any(PromotionStore.class));
    assertNull(result);
  }

  @Test
  void testSaveOfferSalesMetrics_Exception() throws JsonProcessingException {
    OfferSalesPayloadDto offerSalesDto = testUtil.mockOfferSalesDto();
    String offerId = String.valueOf(offerSalesDto.offerId());

    PromotionStore existingPromotion = new PromotionStore();

    when(spotlightPromoStoreElasticSearchDao.getPromotionStoreDataById(offerId))
        .thenReturn(Optional.of(existingPromotion));
    doThrow(new RuntimeException("Exception Occurred"))
        .when(salesDataMapperMock)
        .mapOfferSalesMetrics(existingPromotion, offerSalesDto);

    String result = offerSalesMatrixService.saveOfferSalesMetrics(offerSalesDto);

    verify(spotlightPromoStoreElasticSearchDao, never())
        .savePromotionStoreDocument(any(PromotionStore.class));
    assertNull(result);
  }


}
