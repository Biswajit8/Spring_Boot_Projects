package service;

import com.lowes.model.generated.OfferProductDto;
import com.lowes.promotionstore.component.MicrometerEventRegister;
import com.lowes.promotionstore.component.OfferProductMapper;
import com.lowes.promotionstore.configuration.KafkaConsumerToggleConfig;
import com.lowes.promotionstore.entity.offerproductstore.OfferProductStore;
import com.lowes.promotionstore.exception.constants.ErrorEnums;
import com.lowes.promotionstore.exception.types.custom.SpotlightApplicationException;
import com.lowes.promotionstore.repository.dao.OfferProductStoreESDao;
import com.lowes.promotionstore.service.OfferProductStoreService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.header.internals.RecordHeader;
import org.apache.kafka.common.header.internals.RecordHeaders;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.lowes.promotionstore.model.record.micrometer.RegistryEvent;

import static com.lowes.promotionstore.constants.ApplicationConstants.FULL_LOAD_TYPE;
import static com.lowes.promotionstore.constants.ApplicationConstants.MESSAGE_TYPE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.ArgumentMatchers.anySet;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class OfferProductStoreServiceTest {

  private OfferProductStoreService offerProductStoreService;

  @Mock
  private MicrometerEventRegister registryService;

  @Mock
  private OfferProductStoreESDao offerProductStoreESDao;

  @Mock
  private OfferProductMapper offerProductMapper;

  @Mock
  private KafkaConsumerToggleConfig kafkaConsumerToggleConfig;

  @Captor
  private ArgumentCaptor<List<OfferProductStore>> entitiesCaptor;

  @Captor
  private ArgumentCaptor<Set<OfferProductDto>> dtoSetCaptor;

  @Captor
  private ArgumentCaptor<RegistryEvent> registryEventCaptor;

  private static final String TEST_TOPIC = "test-offer-product-topic";
  private static final int TEST_PARTITION = 0;

  @BeforeEach
  void setUp() {
    offerProductStoreService = new OfferProductStoreService(
        registryService,
        offerProductStoreESDao,
        offerProductMapper,
        kafkaConsumerToggleConfig
    );
  }

  @Test
  void testProcess_withDeltaRecords_shouldSaveToElasticsearch() {
    OfferProductDto dto = createOfferProductDto("item-123", "12345");
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecords(dto);

    OfferProductStore entity = new OfferProductStore();
    entity.setItemNumber("12345");

    when(offerProductMapper.createItemEntities(anySet())).thenReturn(List.of(entity));

    offerProductStoreService.process(consumerRecords, TEST_TOPIC);

    verify(offerProductMapper).createItemEntities(anySet());
    verify(offerProductStoreESDao).saveOfferProductStoreDetails(anyList());
  }

  @Test
  void testProcess_withFullLoadRecords_whenEnabled_shouldProcessFullLoad() {
    OfferProductDto dto = createOfferProductDto("item-full", "99999");
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecordsWithFullLoadHeader(dto);

    OfferProductStore deltaEntity = new OfferProductStore();
    deltaEntity.setItemNumber("delta-item");

    OfferProductStore fullLoadEntity = new OfferProductStore();
    fullLoadEntity.setItemNumber("99999");

    when(offerProductMapper.createItemEntities(anySet()))
        .thenReturn(List.of(deltaEntity))
        .thenReturn(List.of(fullLoadEntity));
    when(kafkaConsumerToggleConfig.isEnableOfferProductConsumer()).thenReturn(true);

    offerProductStoreService.process(consumerRecords, TEST_TOPIC);

    verify(kafkaConsumerToggleConfig).isEnableOfferProductConsumer();
    verify(offerProductStoreESDao).saveOfferProductStoreDetails(entitiesCaptor.capture());

    List<OfferProductStore> savedEntities = entitiesCaptor.getValue();
    assertEquals(2, savedEntities.size());
  }

  @Test
  void testProcess_withFullLoadRecords_whenDisabled_shouldNotProcessFullLoad() {
    OfferProductDto dto = createOfferProductDto("item-full", "99999");
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecordsWithFullLoadHeader(dto);

    OfferProductStore deltaEntity = new OfferProductStore();
    deltaEntity.setItemNumber("delta-item");

    when(offerProductMapper.createItemEntities(anySet())).thenReturn(List.of(deltaEntity));
    when(kafkaConsumerToggleConfig.isEnableOfferProductConsumer()).thenReturn(false);

    offerProductStoreService.process(consumerRecords, TEST_TOPIC);

    verify(kafkaConsumerToggleConfig).isEnableOfferProductConsumer();
    verify(offerProductStoreESDao).saveOfferProductStoreDetails(entitiesCaptor.capture());

    List<OfferProductStore> savedEntities = entitiesCaptor.getValue();
    assertEquals(1, savedEntities.size());
  }

  @Test
  void testProcess_withEmptyRecords_shouldNotFail() {
    ConsumerRecords<String, OfferProductDto> emptyRecords = new ConsumerRecords<>(Collections.emptyMap());

    when(offerProductMapper.createItemEntities(anySet())).thenReturn(List.of());

    offerProductStoreService.process(emptyRecords, TEST_TOPIC);

    verify(offerProductStoreESDao).saveOfferProductStoreDetails(anyList());
  }

  @Test
  void testProcess_whenSerializationError_shouldIncrementCounterWithParsingFailureMessage() {
    OfferProductDto dto = createOfferProductDto("item-123", "12345");
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecords(dto);

    SpotlightApplicationException serializationException = new SpotlightApplicationException(
        ErrorEnums.ErrorCodeEnum.SERIALIZATION_ERROR, new Throwable("Serialization failed"));

    when(offerProductMapper.createItemEntities(anySet())).thenThrow(serializationException);

    offerProductStoreService.process(consumerRecords, TEST_TOPIC);

    verify(registryService).incrementCounter(registryEventCaptor.capture());
    RegistryEvent capturedEvent = registryEventCaptor.getValue();
    
    assertEquals("kafka_offer_product_consumer_process_failure", capturedEvent.getEvent());
    assertEquals(TEST_TOPIC, capturedEvent.getSource());
    assertEquals(ErrorEnums.ErrorCodeEnum.PARSING_FAILURE.getMessage(), capturedEvent.getMessage());
  }

  @Test
  void testProcess_whenGeneralException_shouldIncrementCounterWithProcessingFailureMessage() {
    OfferProductDto dto = createOfferProductDto("item-123", "12345");
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecords(dto);

    when(offerProductMapper.createItemEntities(anySet()))
        .thenThrow(new RuntimeException("Unexpected error"));

    offerProductStoreService.process(consumerRecords, TEST_TOPIC);

    verify(registryService).incrementCounter(registryEventCaptor.capture());
    RegistryEvent capturedEvent = registryEventCaptor.getValue();
    
    assertEquals("kafka_offer_product_consumer_process_failure", capturedEvent.getEvent());
    assertEquals(TEST_TOPIC, capturedEvent.getSource());
    assertEquals(ErrorEnums.ErrorCodeEnum.PROCESSING_FAILURE.getMessage(), capturedEvent.getMessage());
  }

  @Test
  void testProcess_withMultipleDeltaRecords_shouldProcessAll() {
    OfferProductDto dto1 = createOfferProductDto("item-1", "11111");
    OfferProductDto dto2 = createOfferProductDto("item-2", "22222");

    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecordsWithMultiple(
        List.of(dto1, dto2));

    OfferProductStore entity1 = new OfferProductStore();
    entity1.setItemNumber("11111");
    OfferProductStore entity2 = new OfferProductStore();
    entity2.setItemNumber("22222");

    when(offerProductMapper.createItemEntities(anySet())).thenReturn(List.of(entity1, entity2));

    offerProductStoreService.process(consumerRecords, TEST_TOPIC);

    verify(offerProductMapper).createItemEntities(dtoSetCaptor.capture());
    Set<OfferProductDto> capturedDtos = dtoSetCaptor.getValue();
    assertEquals(2, capturedDtos.size());

    verify(offerProductStoreESDao).saveOfferProductStoreDetails(entitiesCaptor.capture());
    List<OfferProductStore> savedEntities = entitiesCaptor.getValue();
    assertEquals(2, savedEntities.size());
  }

  @Test
  void testProcess_withMixedDeltaAndFullLoadRecords_whenFullLoadEnabled() {
    OfferProductDto deltaDto = createOfferProductDto("delta-item", "11111");
    OfferProductDto fullLoadDto = createOfferProductDto("fullload-item", "22222");

    ConsumerRecords<String, OfferProductDto> consumerRecords = createMixedConsumerRecords(
        deltaDto, fullLoadDto);

    OfferProductStore deltaEntity = new OfferProductStore();
    deltaEntity.setItemNumber("11111");
    OfferProductStore fullLoadEntity = new OfferProductStore();
    fullLoadEntity.setItemNumber("22222");

    when(offerProductMapper.createItemEntities(anySet()))
        .thenReturn(List.of(deltaEntity))
        .thenReturn(List.of(fullLoadEntity));
    when(kafkaConsumerToggleConfig.isEnableOfferProductConsumer()).thenReturn(true);

    offerProductStoreService.process(consumerRecords, TEST_TOPIC);

    verify(offerProductStoreESDao).saveOfferProductStoreDetails(entitiesCaptor.capture());
    List<OfferProductStore> savedEntities = entitiesCaptor.getValue();
    assertEquals(2, savedEntities.size());
  }

  @Test
  void testProcess_whenElasticsearchDaoThrows_shouldIncrementCounterWithProcessingFailure() {
    OfferProductDto dto = createOfferProductDto("item-123", "12345");
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecords(dto);

    OfferProductStore entity = new OfferProductStore();
    entity.setItemNumber("12345");

    when(offerProductMapper.createItemEntities(anySet())).thenReturn(List.of(entity));
    doThrow(new RuntimeException("ES connection failed"))
        .when(offerProductStoreESDao).saveOfferProductStoreDetails(anyList());

    offerProductStoreService.process(consumerRecords, TEST_TOPIC);

    verify(registryService).incrementCounter(registryEventCaptor.capture());
    RegistryEvent capturedEvent = registryEventCaptor.getValue();
    
    assertEquals("kafka_offer_product_consumer_process_failure", capturedEvent.getEvent());
    assertEquals(TEST_TOPIC, capturedEvent.getSource());
    assertEquals(ErrorEnums.ErrorCodeEnum.PROCESSING_FAILURE.getMessage(), capturedEvent.getMessage());
  }

  @Test
  void testProcess_successfulProcessing_shouldNotIncrementCounter() {
    OfferProductDto dto = createOfferProductDto("item-123", "12345");
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecords(dto);

    OfferProductStore entity = new OfferProductStore();
    entity.setItemNumber("12345");

    when(offerProductMapper.createItemEntities(anySet())).thenReturn(List.of(entity));

    offerProductStoreService.process(consumerRecords, TEST_TOPIC);

    verify(registryService, never()).incrementCounter(any());
  }

  @Test
  void testProcess_whenNullPointerException_shouldIncrementCounterWithProcessingFailure() {
    OfferProductDto dto = createOfferProductDto("item-123", "12345");
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecords(dto);

    when(offerProductMapper.createItemEntities(anySet()))
        .thenThrow(new NullPointerException("Null value"));

    offerProductStoreService.process(consumerRecords, TEST_TOPIC);

    verify(registryService).incrementCounter(registryEventCaptor.capture());
    RegistryEvent capturedEvent = registryEventCaptor.getValue();
    
    assertEquals("kafka_offer_product_consumer_process_failure", capturedEvent.getEvent());
    assertEquals(TEST_TOPIC, capturedEvent.getSource());
    assertEquals(ErrorEnums.ErrorCodeEnum.PROCESSING_FAILURE.getMessage(), capturedEvent.getMessage());
  }

  @Test
  void testProcess_metricsContainCorrectTopicAsSource() {
    String customTopic = "custom-offer-product-topic";
    OfferProductDto dto = createOfferProductDto("item-123", "12345");
    ConsumerRecords<String, OfferProductDto> consumerRecords = createConsumerRecords(dto);

    when(offerProductMapper.createItemEntities(anySet()))
        .thenThrow(new RuntimeException("Test error"));

    offerProductStoreService.process(consumerRecords, customTopic);

    verify(registryService).incrementCounter(registryEventCaptor.capture());
    RegistryEvent capturedEvent = registryEventCaptor.getValue();
    
    assertEquals(customTopic, capturedEvent.getSource());
  }

  private OfferProductDto createOfferProductDto(String omniItemId, String itemNumber) {
    OfferProductDto dto = new OfferProductDto();
    dto.setOmniItemId(omniItemId);
    dto.setItemNumber(itemNumber);
    dto.setVendorNumber("vendor-001");
    dto.setModelId("model-001");
    dto.setProductType("ITEM");
    dto.setAssortmentId("assort-001");
    dto.setProductGroupId("pg-001");
    dto.setSubdivisionId("subdiv-001");
    dto.setDivisionId("div-001");
    dto.setBusinessAreaId("ba-001");
    dto.setBrandId("brand-001");
    dto.setProgramType("STOCK");
    dto.setIsPublished("true");
    dto.setIsBuyable("true");
    dto.setProductStatus(true);
    dto.setStatus("ACTIVE");
    dto.setMerchBucketIds(List.of("mb-001", "mb-002"));
    dto.setDigitalTaxonomyIds(List.of("dt-001", "dt-002"));
    dto.setChildItems(List.of());
    return dto;
  }

  private ConsumerRecords<String, OfferProductDto> createConsumerRecords(OfferProductDto dto) {
    TopicPartition topicPartition = new TopicPartition(TEST_TOPIC, TEST_PARTITION);
    ConsumerRecord<String, OfferProductDto> record = new ConsumerRecord<>(
        TEST_TOPIC, TEST_PARTITION, 0L, "key", dto);

    Map<TopicPartition, List<ConsumerRecord<String, OfferProductDto>>> recordsMap =
        Collections.singletonMap(topicPartition, Collections.singletonList(record));

    return new ConsumerRecords<>(recordsMap);
  }

  private ConsumerRecords<String, OfferProductDto> createConsumerRecordsWithMultiple(
      List<OfferProductDto> dtos) {
    TopicPartition topicPartition = new TopicPartition(TEST_TOPIC, TEST_PARTITION);

    List<ConsumerRecord<String, OfferProductDto>> records = dtos.stream()
        .map(dto -> new ConsumerRecord<String, OfferProductDto>(
            TEST_TOPIC, TEST_PARTITION, 0L, "key-" + dto.getOmniItemId(), dto))
        .toList();

    Map<TopicPartition, List<ConsumerRecord<String, OfferProductDto>>> recordsMap =
        Collections.singletonMap(topicPartition, records);

    return new ConsumerRecords<>(recordsMap);
  }

  private ConsumerRecords<String, OfferProductDto> createConsumerRecordsWithFullLoadHeader(
      OfferProductDto dto) {
    TopicPartition topicPartition = new TopicPartition(TEST_TOPIC, TEST_PARTITION);

    RecordHeaders headers = new RecordHeaders();
    headers.add(new RecordHeader(MESSAGE_TYPE, FULL_LOAD_TYPE.getBytes()));

    ConsumerRecord<String, OfferProductDto> record = new ConsumerRecord<>(
        TEST_TOPIC, TEST_PARTITION, 0L, 0L, null, 0, 0, "key", dto, headers, java.util.Optional.empty());

    Map<TopicPartition, List<ConsumerRecord<String, OfferProductDto>>> recordsMap =
        Collections.singletonMap(topicPartition, Collections.singletonList(record));

    return new ConsumerRecords<>(recordsMap);
  }

  private ConsumerRecords<String, OfferProductDto> createMixedConsumerRecords(
      OfferProductDto deltaDto, OfferProductDto fullLoadDto) {
    TopicPartition topicPartition = new TopicPartition(TEST_TOPIC, TEST_PARTITION);

    ConsumerRecord<String, OfferProductDto> deltaRecord = new ConsumerRecord<>(
        TEST_TOPIC, TEST_PARTITION, 0L, "delta-key", deltaDto);

    RecordHeaders fullLoadHeaders = new RecordHeaders();
    fullLoadHeaders.add(new RecordHeader(MESSAGE_TYPE, FULL_LOAD_TYPE.getBytes()));

    ConsumerRecord<String, OfferProductDto> fullLoadRecord = new ConsumerRecord<>(
        TEST_TOPIC, TEST_PARTITION, 1L, 0L, null, 0, 0, "fullload-key", fullLoadDto,
        fullLoadHeaders, java.util.Optional.empty());

    Map<TopicPartition, List<ConsumerRecord<String, OfferProductDto>>> recordsMap =
        Collections.singletonMap(topicPartition, List.of(deltaRecord, fullLoadRecord));

    return new ConsumerRecords<>(recordsMap);
  }
}
