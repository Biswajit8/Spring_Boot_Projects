package service;

import com.lowes.promotionstore.component.MessageMapper;
import com.lowes.promotionstore.component.MicrometerEventRegister;
import com.lowes.promotionstore.component.SpotlightPromoStoreEntityMapper;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.model.record.spotlight.SpotlightOfferPayloadDto;
import com.lowes.promotionstore.repository.dao.SpotlightPromoStoreElasticSearchDao;
import com.lowes.promotionstore.service.ForecastService;
import com.lowes.promotionstore.service.SpotlightPromotionStoreService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import util.TestUtil;

@ExtendWith(MockitoExtension.class)
class SpotlightPromotionStoreServiceTest {

  @Mock
  private SpotlightPromoStoreElasticSearchDao spotlightPromoStoreElasticSearchDao;

  @Mock
  private SpotlightPromoStoreEntityMapper spotlightPromoStoreEntityMapper;

  @Mock
  private MessageMapper mockMessageMapper;

  @Mock
  private MicrometerEventRegister registryService;

  @InjectMocks
  private SpotlightPromotionStoreService spotlightPromotionStoreService;

  @Mock
  private ForecastService forecastService;

  private TestUtil testUtil;

  private String topic;
  private SpotlightOfferPayloadDto spotlightOfferDTO;
  private PromotionStore promotionStore;

  @BeforeEach
  void setUp() {
    testUtil = new TestUtil();
    topic = "testTopic";
  }

//  @Test
//  void testCreatePromotion_ItemLevelOffer() throws Exception {
//    String message = testUtil.readFromFile("mocks/offertypeid_103/test1/spotlight.json");
//    SpotlightOfferPayloadDto dto = testUtil.parseStringToSpotlightOfferDto(message);
//    PromotionStore ps = new PromotionStore();
//    ps.setId("[REDACTED_DUTCH_BANK_ACCOUNT_NUMBER_1]");
//    when(spotlightPromoStoreEntityMapper.mapOfferToPromotionStoreEntity(any())).thenReturn(ps);
//
//    spotlightPromotionStoreService.process(List.of(dto), "testTopic");
//
//    // verify BULK called with exactly 1 doc
//    @SuppressWarnings("unchecked")
//    ArgumentCaptor<List<PromotionStore>> captor = ArgumentCaptor.forClass(List.class);
//    verify(spotlightPromoStoreElasticSearchDao, times(1)).savePromotionStoreDocuments(captor.capture());
//    assertEquals(1, captor.getValue().size());
//    assertEquals("[REDACTED_DUTCH_BANK_ACCOUNT_NUMBER_1]", captor.getValue().get(0).getId());
//
//    // ensure SINGLE-SAVE not called
//    verify(spotlightPromoStoreElasticSearchDao, never()).savePromotionStoreDocument(any());
//  }

//  @Test
//  void testCreatePromotion_CartLevelOffer() throws Exception {
//    String spotlightMockPromotion = testUtil.readFromFile(
//        "mocks/offertypeid_3/test1/spotlight.json");
//
//    SpotlightOffer spotlightOfferDto = testUtil.parseStringToSpotlightOfferDto(spotlightMockPromotion);
//    spotlightPromotionStoreService.process(List.of(spotlightOfferDto), "spotlight-promotion");
//    verify(mockMessageMapper).parseStringToObject(anyString(), eq(SpotlightOffer.class));
//    verify(spotlightPromoStoreEntityMapper, never()).mapOfferToPromotionStoreEntity(any());
//    verify(spotlightPromoStoreElasticSearchDao, never()).savePromotionStoreDocument(any());
//    verify(registryService).incrementCounter(any(RegistryEvent.class));
//  }

}
