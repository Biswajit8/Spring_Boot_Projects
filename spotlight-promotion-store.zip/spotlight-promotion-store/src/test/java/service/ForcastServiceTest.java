package service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.lowes.promotionstore.component.ForecastDataMapper;
import com.lowes.promotionstore.component.MicrometerEventRegister;
import com.lowes.promotionstore.component.PartialMapBuilders;
import com.lowes.promotionstore.configuration.ObjectMapperConfig;
import com.lowes.promotionstore.entity.spotlight.PromotionStore;
import com.lowes.promotionstore.entity.spotlight.SalesEnums.ForecastSearchEnum;
import com.lowes.promotionstore.model.record.spotlight.ForecastDataDto;
import com.lowes.promotionstore.repository.dao.SpotlightPromoStoreElasticSearchDao;
import com.lowes.promotionstore.service.ForecastService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import util.TestUtil;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class ForcastServiceTest {

  @Mock
  private ForecastDataMapper forecastDataMapper;

  private ForecastService forecastService;
  @Mock
  private SpotlightPromoStoreElasticSearchDao spotlightPromoStoreElasticSearchDao;

  @Mock
  private MicrometerEventRegister registryService;

  private PartialMapBuilders partialMapBuilders;
  private ObjectMapperConfig objectMapperConfig;

  private TestUtil testUtil;

  @BeforeEach
  void setUp() {
    objectMapperConfig = new ObjectMapperConfig();
    partialMapBuilders = new PartialMapBuilders(objectMapperConfig);
    registryService = mock(MicrometerEventRegister.class);
    forecastService = new ForecastService(forecastDataMapper, spotlightPromoStoreElasticSearchDao,
        partialMapBuilders, registryService);
    forecastDataMapper = mock(ForecastDataMapper.class);
    testUtil = new TestUtil();
  }

  @Test
  void testSaveOrUpdateForecastData_WhenDataExists() throws JsonProcessingException {
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();
    String promotionId = "100000057164";
    PromotionStore existingPromotion = new PromotionStore();
    PromotionStore updatedPromotion = new PromotionStore();

    when(forecastDataMapper.mapForecastData(existingPromotion, forecastDataDto)).thenReturn(
        updatedPromotion);
    forecastService.saveForecastData(forecastDataDto);

    Set<String> eligibleFields = Arrays.stream(ForecastSearchEnum.values())
        .map(ForecastSearchEnum::name).collect(
            Collectors.toSet());

    Map<String, Object> nonNullValues = partialMapBuilders.from(updatedPromotion).dropNulls()
        .include(eligibleFields).build();

  }

  @Test
  void testSaveOrUpdateForecastData_WhenDataDoesNotExist() {
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();
    PromotionStore updatedPromotion = new PromotionStore();

    forecastService.saveForecastData(forecastDataDto);
  }

  @Test
  void testSaveOrUpdateForecastData_JsonProcessingException() throws JsonProcessingException {
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();
    String promotionId = "100000057164";

    PromotionStore existingPromotion = new PromotionStore();
    PromotionStore updatedPromotion = new PromotionStore();

    when(forecastDataMapper.mapForecastData(eq(existingPromotion), eq(forecastDataDto))).thenThrow(
        new JsonProcessingException("Exception Occurred") {
        });

    forecastService.saveForecastData(forecastDataDto);

  }

  @Test
  void testSaveOrUpdateForecastData_Exception() throws JsonProcessingException {
    ForecastDataDto forecastDataDto = testUtil.mockForecastDataDto();
    String promotionId = "100000057164";
    PromotionStore existingPromotion = new PromotionStore();
    PromotionStore updatedPromotion = new PromotionStore();

    when(forecastDataMapper.mapForecastData(updatedPromotion, forecastDataDto)).thenThrow(
        new RuntimeException("Exception Occurred") {
        });

    forecastService.saveForecastData(forecastDataDto);

  }

}
