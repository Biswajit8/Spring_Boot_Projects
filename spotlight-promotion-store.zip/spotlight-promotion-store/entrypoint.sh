#!/bin/sh
set -e
set +x

echo "JAVA_HOME: " ${JAVA_HOME}

echo "1- Listing all files under /usr/local/share/ca-certificates/: "
ls -l /usr/local/share/ca-certificates/

echo "2- Listing all files under /usr/lib/jvm/default-jvm/lib/security/: "
ls -l /usr/lib/jvm/default-jvm/lib/security/

echo "About to start spotlight-promotion-store jar: java -jar /app/spotlight-promotion-store.jar"
java -jar /app/spotlight-promotion-store.jar