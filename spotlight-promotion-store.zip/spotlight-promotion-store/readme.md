# spotlight-promotion-store


## Requirements
For building and running the application you need:::
- [JDK 1.8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html)
- [Maven 3](https://maven.apache.org)
## Running the application locally
There are several ways to run a Spring Boot application on your local machine. One way is to execute the `main` method in the `com.lowes.Spotlightpromotionstore.Application` class from your IDE.
Alternatively you can use the [Spring Boot Maven plugin](https://docs.spring.io/spring-boot/docs/current/reference/html/build-tool-plugins-maven-plugin.html) like so:
```shell
mvn spring-boot:run
```
## Deploying the application to OnPrem.
https://tools.lowes.com/confluence/display/EA/Application+-+OnBoarding

## Logging
https://docs.telemetry.lowes.com/bestpractices/logging/application_best_practices/




    
## Instructions to Download and setup the Kafka Producer / Consumer Sample application in SpringBoot

Pre-requistie:
1. Raise New Topic Request and get it approved by Kafka Team. Instructions are documented here - https://docs.kite.lowes.com/self_service/createtopic/
2. Once the topic request is approved, you will get email with Kafka User name and Password.
3. Update the vault with Kafka user name and password for local testing update in application.yml
4. Download the trustrore certs and place it in anywhere in your local. Truststore Certs are documented here - https://docs.kite.lowes.com/ssl_troubleshooting/
5. Get the schema registry urls from https://docs.kite.lowes.com/schemaregistry_urls_details/ and have schema ready


Steps:
1. Download the application to your local as per instructions given by LEC (Select Kafka in other options section)
2. Update the application.yml file with the below correct details
   1. Bootstrap Servers
   2. Client Id
   3. Group-id (in case Consumer)
   4. Topic Name
   5. trust-store-location : Example ---> trust-store-location: file:/Users/sakhan/Downloads/certshare3/truststore-4.jks
   6. trust-store-password
   7. schema registry url
   8. jaas config with user name and password
3. Run the Application which will make the connectivity to the cluster and now application is ready to producer / consume the messages
5. After producing / consuming the messages successfully, build the JMX metrics to check the dashboard in the Grafana                

## Running the application on DEV region with Kafka and Postgres configurations
1. First we need to put all the certs and passwords to vault, please refer below link on how to push secrets to vault.

    https://tools.lowes.com/confluence/pages/viewpage.action?pageId=489381087


2. For Spring boot app configuration refer below code repo.

    http://go/kafkapostgres


3. For Spring Webflux app configuration refer below code repo
  
    https://tools.lowes.com/stash/projects/D-FRW/repos/postgreskafka/browse?at=feature-webflux-kafka-postgres



